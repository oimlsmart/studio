//#region \0rolldown/runtime.js
var e = (e, t) => () => (t || (e((t = { exports: {} }).exports, t), e = null), t.exports);
//#endregion
//#region src/ser-des/tokenize.ts
function t(e) {
	let t = [], n = 1, r = 1, i = 0, a = 0, o = (t) => {
		for (let o = 0; o < t; o++) e.charAt(i) === "\n" ? (n++, r = 1) : r++, i++, a++;
	};
	for (; a < e.length;) {
		let s = e.charAt(a);
		if (s === "#" || s === "/" && a + 1 < e.length && e.charAt(a + 1) === "/") {
			for (; a < e.length && e.charAt(a) !== "\n";) o(1);
			continue;
		}
		if (c(s)) {
			o(1);
			continue;
		}
		let l = n, u = r, d = i, f = "";
		if (s === "\"") for (f += s, o(1); a < e.length;) {
			let t = e.charAt(a);
			if (t === "\\" && a + 1 < e.length) {
				f += t + e.charAt(a + 1), o(2);
				continue;
			}
			if (f += t, o(1), t === "\"") break;
		}
		else if (s === "{") {
			let t = 1;
			for (f += s, o(1); a < e.length && t > 0;) {
				let n = e.charAt(a);
				if (n === "\"") {
					for (f += n, o(1); a < e.length;) {
						let t = e.charAt(a);
						if (t === "\\" && a + 1 < e.length) {
							f += t + e.charAt(a + 1), o(2);
							continue;
						}
						if (f += t, o(1), t === "\"") break;
					}
					continue;
				}
				n === "{" && t++, n === "}" && t--, f += n, o(1);
			}
		} else for (; a < e.length && !c(e.charAt(a));) f += e.charAt(a), o(1);
		t.push({
			value: f,
			start: {
				line: l,
				col: u,
				offset: d
			},
			end: {
				line: n,
				col: r,
				offset: i
			}
		});
	}
	return t;
}
function n(e) {
	return t(e).map((e) => e.value);
}
function r(e) {
	return n(i(e));
}
function i(e) {
	return e.length >= 2 ? e.substr(1, e.length - 2) : e;
}
function a(e) {
	if (e.length < 2) return e;
	let t = e.charAt(0), n = e.charAt(e.length - 1);
	return t === "\"" && n === "\"" ? o(e.substr(1, e.length - 2)) : t === "{" && n === "}" ? e.substr(1, e.length - 2) : e;
}
function o(e) {
	let t = "";
	for (let n = 0; n < e.length; n++) e.charAt(n) === "\\" && n + 1 < e.length ? (t += e.charAt(n + 1), n++) : t += e.charAt(n);
	return t;
}
function s(e) {
	return e.replace(/\\/g, "\\\\").replace(/"/g, "\\\"");
}
function c(e) {
	return /\s/.test(e);
}
//#endregion
//#region src/duplicate-id.ts
function l() {
	let e = /* @__PURE__ */ new Map();
	return { check(t, n, r, i) {
		let a = e.get(t);
		a || (a = /* @__PURE__ */ new Map(), e.set(t, a));
		let o = a.get(r);
		if (o) return {
			severity: "error",
			code: "duplicate-id",
			construct: String(t),
			id: r,
			message: `Duplicate ${n} id "${r}" (first declared at line ${o.line} col ${o.col}) — earlier declaration overwritten`,
			position: { ...i }
		};
		a.set(r, i);
	} };
}
//#endregion
//#region src/ser-des/parse.ts
function u(e, n, r = {}) {
	let i = t(e), a = l(), o = [], s = {
		root: "",
		metadata: null,
		packageManifest: null,
		approvals: {},
		roles: {},
		processes: {},
		processModels: {},
		pages: {},
		gateways: {},
		regs: {},
		references: {},
		provisions: {},
		dataclasses: {},
		events: {},
		enums: {},
		variables: {},
		notes: {},
		tables: {},
		figures: {},
		links: {},
		mapProfiles: {},
		viewProfiles: {},
		comments: {},
		terms: {},
		forms: {},
		subforms: {},
		symbols: {},
		formulaNotes: {},
		calculations: {},
		verdicts: {},
		referenceMaterials: {},
		testPointSets: {},
		commonTestConditions: {},
		competenceKinds: {},
		schemeActivityKinds: {},
		schemeTypes: {},
		predicates: {},
		constraints: {},
		discrepancyRecords: {},
		stateMachines: {},
		conformanceTests: {},
		conformanceClasses: {},
		requirements: {},
		requirementClasses: {},
		instruments: {},
		attributeDefinitions: {},
		capabilities: {},
		behaviors: {},
		conditionSets: {},
		subjects: {},
		identitySlots: {},
		aspects: {},
		promiseSets: {},
		applicationDeclarations: {},
		calculationContexts: {},
		evaluationDimensions: {},
		evaluationProfiles: {},
		certificateTemplates: {},
		workflowConfigs: {},
		workflowStages: {},
		verificationPathways: {},
		labSelectionCriteria: {},
		sampleSelectionRules: {},
		specimenGovernanceRules: {},
		testReportSkeletons: {},
		testReportChecklists: {},
		instances: {},
		artifactDefinitions: {},
		artifactInstances: {},
		quantityRegisters: {},
		duals: {},
		activityArchetypes: {},
		participantKinds: {},
		governanceOrgans: {},
		declarationKinds: {},
		declarationStatuses: {},
		declarationGates: {},
		schemeDefinitions: {},
		schemeLifecycles: {},
		frameworkDocuments: {},
		documentPrecedences: {},
		autoInclusions: {},
		decisionRules: {},
		documentModules: {},
		informativeAnnexes: {},
		partAnnexes: {},
		demoWorlds: {},
		storylines: {},
		connectorProfiles: {},
		monitors: {},
		passports: {},
		invariants: {},
		testSequences: {},
		formulasUsed: {},
		texts: {},
		dataspaces: {},
		policies: {},
		dimensions: {},
		issues: []
	}, c = 0;
	for (; c < i.length;) {
		let e = i[c++], t = e.value, l = n[t];
		if (!l) {
			if (r.strict) throw Error(`Unknown keyword "${t}" at line ${e.start.line} col ${e.start.col}. Use lenient mode (default) to skip unknown keywords.`);
			continue;
		}
		let u;
		if (l.takesID) {
			if (c + 1 > i.length) throw Error(`Keyword "${t}" at line ${e.start.line} col ${e.start.col} expects an ID and payload, but only ${i.length - c + 1} token(s) remain.`);
			let n = i[c++], d = i[c++];
			if (l.field) {
				let e = a.check(l.field, t, n.value, n.start);
				e && s.issues.push(e);
			}
			r.withProvenance && o.push({
				field: l.field ?? t,
				id: n.value,
				keyword: t,
				start: e.start,
				end: d.end
			}), u = l.parse(n.value, d.value);
		} else {
			if (c >= i.length) throw Error(`Keyword "${t}" at line ${e.start.line} col ${e.start.col} expects a payload, but no tokens remain.`);
			let n = i[c++];
			r.withProvenance && o.push({
				field: l.field ?? t,
				id: "",
				keyword: t,
				start: e.start,
				end: n.end
			}), u = l.parse(n.value);
		}
		let d = u(s);
		d !== s && (d.issues = s.issues), s = d;
	}
	return r.withProvenance && (s.constructs = o), s;
}
//#endregion
//#region src/ser-des/resolve.ts
var d = {
	schema: "",
	author: "",
	title: "",
	edition: "",
	namespace: "",
	shortname: ""
};
function f(e, t, n) {
	let r = e[t];
	if (r == null) return;
	let i = r[n];
	if (i !== void 0) {
		if (i._relations) {
			let e = { ...i };
			return delete e._relations, e;
		}
		return i;
	}
}
function p(e, t) {
	let n = {
		meta: e.metadata ?? d,
		packageManifest: e.packageManifest ?? null,
		root: null
	};
	for (let r of Object.keys(t)) {
		let i = t[r];
		if (!i) continue;
		let a = e[r];
		if (!a) continue;
		let o = [];
		for (let [, t] of Object.entries(a)) {
			let n = i.resolve(e, t);
			n !== void 0 && (delete n._relations, o.push(n));
		}
		n[r] = o;
	}
	return e.root && (n.root = e.pages[e.root] ?? null), n;
}
//#endregion
//#region src/ser-des/config/metadata.ts
var m = function(e) {
	let t = {
		schema: "",
		author: "",
		title: "",
		edition: "",
		namespace: "",
		shortname: ""
	};
	if (e !== "") {
		let n = r(e), i = 0;
		for (; i < n.length;) {
			let e = n[i++];
			if (i < n.length) {
				if (e === "title") t.title = a(n[i++]);
				else if (e === "schema") t.schema = a(n[i++]);
				else if (e === "edition") t.edition = a(n[i++]);
				else if (e === "author") t.author = a(n[i++]);
				else if (e === "namespace") t.namespace = a(n[i++]);
				else if (e === "shortname") t.shortname = a(n[i++]);
				else throw Error("Parsing error: metadata. Unknown keyword " + e);
			} else throw Error("Parsing error: metadata. Expecting value for " + e);
		}
	}
	return (e) => (e.metadata = t, e);
}, h = function(e) {
	let t = "metadata {\n";
	return t += "  title \"" + s(e.title) + "\"\n", t += "  schema \"" + s(e.schema) + "\"\n", t += "  edition \"" + s(e.edition) + "\"\n", t += "  author \"" + s(e.author) + "\"\n", t += "  namespace \"" + s(e.namespace) + "\"\n", t += "}\n", t;
}, g = /* @__PURE__ */ new Set([
	"aliases",
	"alt",
	"colloquial",
	"abbreviations",
	"deprecated"
]);
function _(e) {
	return g.has(e);
}
function v(e, t, n) {
	if (e === "") return;
	let i = r(e), a = 0;
	for (; a < i.length;) {
		let e = i[a++];
		if (a >= i.length) throw Error(`Parsing error: ${n.construct}. ID ${n.id}: Expecting value for ${e}`);
		t(e, () => i[a++], () => i[a]) || (e === "ref" || e === "corresponds" ? (a++, a++, a < i.length && i[a].startsWith("{") && a++) : e === "trust_ref" ? (a++, i[a] === "key" && (a++, a++)) : _(e) ? (a++, !i[a - 1].startsWith("{") && i[a]?.startsWith("{") && a++) : a++);
	}
}
function y(e, t, n) {
	return n === "ref" || n === "corresponds" ? (t++, t < e.length && t++, t < e.length && e[t].startsWith("{") && t++, t) : n === "trust_ref" ? (t < e.length && t++, e[t] === "key" && (t++, t < e.length && t++), t) : _(n) ? (t < e.length && t++, !e[t - 1]?.startsWith("{") && e[t]?.startsWith("{") && t++, t) : (t < e.length && t++, t);
}
function b(e, t, n) {
	if (e === "") return;
	let a = r(e), o = 0;
	for (; o < a.length;) {
		if (a[o] === "ref") {
			let e = [a[o++]];
			o < a.length && e.push(a[o++]), o < a.length && e.push(a[o++]);
			let n = "";
			o < a.length && a[o].charAt(0) === "{" && (n = i(a[o++])), t(e.join(" "), n);
			continue;
		}
		let e = [];
		for (; o < a.length && a[o].charAt(0) !== "{";) e.push(a[o++]);
		if (e.length === 0) throw Error(`Parsing error: ${n.construct}. ID ${n.id}: Attribute is missing its name`);
		if (o >= a.length) throw Error(`Parsing error: ${n.construct}. ID ${n.id}: Expecting { after ${e.join(" ")}`);
		let r = a[o++];
		t(e.join(" "), i(r));
	}
}
function x(e) {
	let t = e();
	return t.length >= 2 && t.charAt(0) === "\"" && t.charAt(t.length - 1) === "\"" ? o(t.substr(1, t.length - 2)) : i(t);
}
//#endregion
//#region src/ser-des/config/ref.ts
function S(e, t, n, r) {
	let i = {
		predicate: n(e[t++] ?? ""),
		target: n(e[t++] ?? "")
	};
	if (t < e.length && e[t].startsWith("{")) {
		let n = r(e[t++]), a = /note\s+"([^"]*)"/.exec(n) ?? /note\s+(\S+)/.exec(n);
		a && (i.note = a[1]);
	}
	return {
		ref: i,
		next: t
	};
}
function C(e, t, n, r) {
	let i = [e(), e()], a = t();
	return a && a.startsWith("{") && i.push(e()), S(i, 0, n, r).ref;
}
function w(e, t, n) {
	if (!e || e.length === 0) return "";
	let r = "";
	for (let i of e) r += `${t}ref ${i.predicate} "${n(i.target)}"`, r += i.note ? ` {\n${t}  note "${n(i.note)}"\n${t}}\n` : "\n";
	return r;
}
function ee(e) {
	let t = /^(urn:[^#]+)(?:#(.+))?$/.exec(e);
	if (!t) return null;
	let n = t[2];
	if (!n) return {
		doc: e,
		clause: ""
	};
	if (n.startsWith("clause-")) {
		let e = n.slice(7), r = e.indexOf("/");
		return r >= 0 ? {
			doc: t[1],
			clause: e.slice(0, r),
			fragment: e.slice(r + 1)
		} : {
			doc: t[1],
			clause: e
		};
	}
	return {
		doc: e,
		clause: ""
	};
}
function T(e, t) {
	if (t.predicate === "derives-from") {
		let n = e.fieldReferences ?? e.formReferences, r = "source" in e || "sourceRef" in e || e.sourceRefs !== void 0;
		if (n && !r) return n.push({
			urn: t.target,
			role: "source"
		}), !0;
		let i = ee(t.target);
		return i ? ((e.sourceRefs ??= []).push(i), "source" in e && !e.source && (e.source = i), "sourceRef" in e && !e.sourceRef && (e.sourceRef = i), "reference" in e && !e.reference && (e.reference = i.doc), !0) : !1;
	}
	if (t.predicate === "cites") return e.fieldReferences ? e.fieldReferences.push({
		urn: t.target,
		role: "reference"
	}) : e.formReferences ? e.formReferences.push({
		urn: t.target,
		role: "reference"
	}) : e.referenceIds && e.referenceIds.push(t.target), !0;
	if ([
		"requirement",
		"test-procedure",
		"calculation",
		"report-format",
		"method"
	].includes(t.predicate)) {
		let n = e.fieldReferences ?? e.formReferences;
		return n ? (n.push({
			urn: t.target,
			role: t.predicate
		}), !0) : !1;
	}
	return !1;
}
function E(e, t, n) {
	return e.doc && e.doc.startsWith("urn:") ? `${t}ref derives-from "${n(`${e.doc}${e.clause ? "#clause-" + e.clause : ""}${e.fragment ? "/" + e.fragment : ""}`)}"\n` : `${t}source { doc "${n(e.doc ?? "")}" clause "${n(String(e.clause ?? ""))}"` + (e.fragment ? ` fragment "${n(e.fragment)}"` : "") + " }\n";
}
//#endregion
//#region src/ser-des/config/correspondence.ts
function D(e, t, n) {
	if (e[t] === void 0) throw Error("Parsing error: corresponds: Expecting value for corresponds (the scheme and the concept)");
	let r = n(e[t++]);
	if (e[t] === void 0) throw Error("Parsing error: corresponds: Expecting value for corresponds (the concept)");
	let a = {
		scheme: r,
		concept: n(e[t++]),
		projections: []
	};
	return t < e.length && e[t].startsWith("{") && v(i(e[t++]), (e, t, r) => {
		if (e === "projection") {
			let e = n(t()), o = [], s = r();
			return s && s.startsWith("{") && v(i(t()), (e, t) => (o.push({
				key: e,
				value: n(t())
			}), !0), {
				construct: "corresponds.projection",
				id: e
			}), a.projections.push({
				codec: e,
				entries: o
			}), !0;
		}
		return !1;
	}, {
		construct: "corresponds",
		id: a.scheme
	}), {
		corr: a,
		next: t
	};
}
function O(e, t, n) {
	let r = [e(), e()], i = t();
	return i && i.startsWith("{") && r.push(e()), D(r, 0, n).corr;
}
function k(e, t, n, r) {
	if (!e || e.length === 0) return "";
	let i = "";
	for (let a of e) {
		if (i += `${t}corresponds ${r(a.scheme)} "${n(a.concept)}"`, a.projections.length === 0) {
			i += "\n";
			continue;
		}
		i += " {\n";
		for (let e of a.projections) {
			i += `${t}  projection ${r(e.codec)} {`;
			for (let t of e.entries) i += ` ${r(t.key)} ${r(t.value)}`;
			i += " }\n";
		}
		i += `${t}}\n`;
	}
	return i;
}
//#endregion
//#region src/ser-des/config/series.ts
function te(e) {
	let t = {
		axes: [],
		cellSymbol: "",
		cellUnit: ""
	}, r = n(e), o = 0;
	for (; o < r.length;) {
		let e = r[o++];
		if (e !== "axis" && e !== "cell") {
			o < r.length && i(r[o - 1]);
			continue;
		}
		if (e === "axis") {
			let e = {
				id: a(r[o++]),
				unit: "",
				type: "",
				role: ""
			};
			if (o < r.length && r[o].startsWith("{")) {
				let t = n(i(r[o++])), s = 0;
				for (; s < t.length;) {
					let n = t[s++];
					if (s >= t.length) break;
					n === "unit" ? e.unit = a(t[s++]) : n === "type" ? e.type = a(t[s++]) : n === "role" ? e.role = a(t[s++]) : i(t[s++]);
				}
			}
			t.axes.push(e);
		} else {
			let e = n(i(r[o++])), s = 0;
			for (; s < e.length;) {
				let n = e[s++];
				if (s >= e.length) break;
				n === "symbol" ? t.cellSymbol = a(e[s++]) : n === "unit" ? t.cellUnit = a(e[s++]) : i(e[s++]);
			}
		}
	}
	return t;
}
function ne(e) {
	let t = "series { ";
	for (let n of e.axes) t += "axis " + n.id + " { ", n.unit && (t += "unit \"" + s(n.unit) + "\" "), n.type && (t += "type " + n.type + " "), n.role && (t += "role " + n.role + " "), t += "} ";
	return t += "cell { ", e.cellSymbol && (t += "symbol " + e.cellSymbol + " "), e.cellUnit && (t += "unit \"" + s(e.cellUnit) + "\" "), t += "} }", t;
}
//#endregion
//#region src/ser-des/config/sourceDiscrepancy.ts
var re = ["follows_clause_x", "annotated_only"];
function A(e) {
	let t = {
		summary: "",
		sources: [],
		resolution: "",
		rationale: ""
	}, r = n(e), o = 0;
	for (; o < r.length;) {
		let e = r[o++];
		if (o >= r.length) break;
		if (e === "summary") t.summary = a(r[o++]);
		else if (e === "sources") t.sources = n(a(r[o++])).map(a).filter((e) => e.length > 0);
		else if (e === "resolution") {
			let e = a(r[o++]);
			if (!re.includes(e)) throw Error(`Parsing error: source_discrepancy: Unknown resolution ${e} (valid: ${re.join(", ")})`);
			t.resolution = e;
		} else e === "rationale" ? t.rationale = a(r[o++]) : i(r[o++]);
	}
	return t;
}
function j(e, t) {
	let n = t + "source_discrepancy { ";
	return n += "summary \"" + s(e.summary) + "\" ", n += "sources { " + e.sources.map((e) => "\"" + s(e) + "\"").join(" ") + " } ", n += "resolution " + e.resolution + " ", n += "rationale \"" + s(e.rationale) + "\" ", n += "}", n;
}
//#endregion
//#region src/ser-des/config/field-parser.ts
function M(e, t) {
	let n = e[t] ?? "";
	if (!n.startsWith("ocl{")) return {
		text: n,
		next: t + 1
	};
	let r = (e) => (e.match(/\{/g) || []).length - (e.match(/\}/g) || []).length, i = n, a = r(n), o = t + 1;
	for (; a > 0 && o < e.length;) {
		let t = e[o++];
		a += r(t), i += " " + t;
	}
	return {
		text: i,
		next: o
	};
}
function ie(e) {
	let t = r(e.trim().replace(/^[[{]/, "").replace(/[\]}]$/, "")), n = [], o = 0;
	for (; o < t.length;) {
		let e = a(t[o++].replace(/,$/, ""));
		if (e) {
			if (o < t.length && t[o].startsWith("{")) {
				let s = r(i(t[o++])), c = "";
				for (let e = 0; e + 1 < s.length; e += 2) s[e] === "label" && (c = a(s[e + 1]));
				n.push({
					value: e,
					label: c
				});
			} else n.push(e);
		}
	}
	return n;
}
function ae(e) {
	return typeof e == "string" ? e : e.value + " { label \"" + s(e.label) + "\" }";
}
function N(e) {
	return /[\s{}"]/.test(e) || e.endsWith(":") || e.startsWith("#") || e.startsWith("//") ? "\"" + s(e) + "\"" : e;
}
function P(e) {
	return e.endsWith(":") ? e.slice(0, -1) : e;
}
function oe(e, t) {
	let n = e[t] ?? "";
	if (!n.startsWith("[")) return {
		text: n,
		next: t + 1
	};
	let r = n, i = t + 1;
	for (; !r.includes("]") && i < e.length;) r += " " + e[i++];
	return {
		text: r,
		next: i
	};
}
function se(e) {
	return r(e).map((e) => e.replace(/^;+|;+$/g, "")).filter((e) => e.length > 0);
}
function F(e) {
	if (e.startsWith("{")) return se(i(e)).flatMap((e) => e.split(",")).map((e) => a(e.trim())).filter((e) => e.length > 0);
	let t = a(e);
	return t === "" ? [] : [t];
}
function I(e) {
	let t = {
		doc: "",
		clause: ""
	}, r = n(e), o = 0;
	for (; o < r.length;) {
		let e = r[o++];
		if (o >= r.length) break;
		e === "doc" ? t.doc = a(r[o++]) : e === "clause" ? t.clause = a(r[o++]) : e === "fragment" ? t.fragment = a(r[o++]) : i(r[o++]);
	}
	return t;
}
function ce(e, t) {
	let n = e[t++];
	if (n === void 0) return null;
	let r = "";
	e[t] === ":" && (t++, r = e[t++] ?? "", e[t] && e[t].startsWith("[") && e[t].endsWith("]") && t++);
	let a = e[t++];
	return a === void 0 || !a.startsWith("{") ? null : {
		name: n,
		type: r,
		block: i(a),
		next: t
	};
}
function le(e, t, o) {
	let s = {
		name: e,
		type: o || "string",
		typeDeclared: !!o,
		label: "",
		definition: "",
		unit: "",
		symbol: "",
		verdict: "",
		targets: [],
		dimension: "",
		enumRef: "",
		pattern: "",
		required: !1,
		requiredWhen: "",
		refs: [],
		measurementMethod: "",
		calculationId: null,
		calculationBindings: [],
		derivation: "",
		evaluation: null,
		values: [],
		trueLabel: "",
		falseLabel: "",
		enumValues: [],
		defaultValue: "",
		hasDefault: !1,
		referenceIds: [],
		fieldReferences: [],
		specificationReference: "",
		applicability: [],
		sourceDiscrepancy: null,
		fields: [],
		itemsType: "",
		subformRef: null
	};
	if (!t || !t.trim()) return s;
	let c = n(t), l = 0;
	for (; l < c.length;) {
		let e = c[l++];
		if (l >= c.length) break;
		if (e === "label") s.label = a(c[l++]);
		else if (e === "definition") s.definition = a(c[l++]);
		else if (e === "description") s.description = a(c[l++]);
		else if (e === "type") s.type = a(c[l++]), s.typeDeclared = !0;
		else if (e === "unit") s.unit = a(c[l++]);
		else if (e === "symbol") s.symbol = a(c[l++]);
		else if (e === "verdict") s.verdict = a(c[l++]);
		else if (e === "targets") s.targets = r(c[l++]).map(a);
		else if (e === "dimension") s.dimension = a(c[l++]);
		else if (e === "enum") s.enumRef = a(c[l++]);
		else if (e === "pattern") s.pattern = a(c[l++]);
		else if (e === "scope") s.scope = a(c[l++]);
		else if (e === "examples") s.examples = a(c[l++]);
		else if (e === "bind") s.bind = a(c[l++]);
		else if (e === "required") s.required = a(c[l++]) === "true";
		else if (e === "required_when") {
			let e = M(c, l);
			s.requiredWhen = a(e.text), l = e.next;
		} else if (e === "measurement_method") s.measurementMethod = a(c[l++]);
		else if (e === "calculation") {
			let e = M(c, l);
			s.calculationId = a(e.text), l = e.next;
		} else if (e === "calculation_bindings") s.calculationBindings = ue(i(c[l++]));
		else if (e === "derivation") s.derivation = a(c[l++]);
		else if (e === "evaluation") s.evaluation = de(i(c[l++]));
		else if (e === "values") {
			let e = oe(c, l);
			s.values = ie(e.text), l = e.next;
		} else if (e === "default") s.defaultValue = a(c[l++]), s.hasDefault = !0;
		else if (e === "true_label") s.trueLabel = a(c[l++]);
		else if (e === "false_label") s.falseLabel = a(c[l++]);
		else if (e === "enum_values") s.enumValues = ie(c[l++]);
		else if (e === "min_items") {
			let e = a(c[l++]), t = parseInt(e, 10);
			s.minItems = isNaN(t) ? e : t;
		} else if (e === "max_items") {
			let e = a(c[l++]), t = parseInt(e, 10);
			s.maxItems = isNaN(t) ? e : t;
		} else if (e === "items") {
			let e = n(i(c[l++])), t = [], r = 0;
			for (; r < e.length && e[r] !== "fields";) e[r] === "unit" && r + 1 < e.length ? (s.itemsUnit = a(e[r + 1]), r += 2) : t.push(e[r++]);
			s.itemsType = t.join(" "), e[r] === "fields" && (r++, r < e.length && (s.fields = fe(i(e[r]))));
		} else if (e === "series") s.series = te(i(c[l++]));
		else if (e === "fields") s.fields = fe(i(c[l++]));
		else if (e === "subform_ref") s.subformRef = pe(a(c[l++]), l < c.length ? i(c[l++]) : ""), (!s.type || s.type === "string") && (s.type = "array");
		else if (e === "reference") s.referenceIds = r(c[l++]).map(a);
		else if (e === "references") s.fieldReferences = he(i(c[l++]));
		else if (e === "ref") {
			let e = S(c, l, a, i);
			T(s, e.ref) || s.refs.push(e.ref), l = e.next;
		} else if (e === "corresponds") {
			let e = D(c, l, a);
			(s.correspondences ??= []).push(e.corr), l = e.next;
		} else e === "specification_reference" ? s.specificationReference = a(c[l++]) : e === "applicability" ? s.applicability = L(i(c[l++])) : e === "source_discrepancy" ? s.sourceDiscrepancy = A(i(c[l++])) : i(c[l++]);
	}
	return s;
}
function ue(e) {
	let t = [], r = n(e), i = 0;
	for (; i < r.length;) {
		let e = P(r[i++]);
		if (i >= r.length) break;
		r[i] === ":" && i++, i < r.length && t.push({
			inputName: e,
			pathExpr: a(r[i++])
		});
	}
	return t;
}
function de(e) {
	let t = {
		rule: "",
		condition: "",
		referenceId: null
	}, o = n(e), s = 0;
	for (; s < o.length;) {
		let e = o[s++];
		if (s >= o.length) break;
		e === "rule" ? t.rule = a(o[s++]) : e === "verdict" ? t.verdict = a(o[s++]) : e === "op" ? t.op = a(o[s++]) : e === "limit" ? t.limit = a(o[s++]) : e === "condition" ? t.condition = a(o[s++]) : e === "reference" ? t.referenceId = r(o[s++]).map(a)[0] ?? null : e === "specification_reference" ? t.specificationReference = a(o[s++]) : e === "source_discrepancy" ? t.sourceDiscrepancy = A(i(o[s++])) : i(o[s++]);
	}
	return t;
}
function fe(e) {
	let t = [], r = n(e), a = 0;
	for (; a < r.length;) {
		if (r[a++] !== "field") {
			a < r.length && i(r[a - 1]);
			continue;
		}
		let e = ce(r, a);
		if (!e) break;
		t.push(le(e.name, e.block, e.type || void 0)), a = e.next;
	}
	return t;
}
function L(e) {
	let t = [], r = n(e), i = 0;
	for (; i < r.length;) {
		let e = P(r[i++]);
		if (i >= r.length) break;
		if (r[i] === ":" && i++, i < r.length) {
			let n = oe(r, i);
			i = n.next;
			let o = n.text.trim(), s;
			if (o.startsWith("[")) s = {
				dimension: e,
				values: o.slice(1, o.lastIndexOf("]")).split(/[,\s]+/).filter((e) => e.length > 0),
				mapping: null,
				match: null
			};
			else if (o.startsWith("{")) {
				let t = o.slice(1, -1), n = {};
				for (let e of t.split(/[,\n]+/).map((e) => e.trim()).filter((e) => e)) {
					let t = e.match(/^(\w+)\s*:\s*(.+)$/);
					t && (n[t[1]] = t[2].trim());
				}
				s = {
					dimension: e,
					values: [],
					mapping: n,
					match: null
				};
			} else s = {
				dimension: e,
				values: [a(o)],
				mapping: null,
				match: null
			};
			if (!s.mapping && r[i] === "match") {
				i++;
				let e = a(r[i++] ?? "");
				if (e !== "any" && e !== "all" && e !== "exact") throw Error(`Parsing error: applicability: Unknown match ${e} (valid: any, all, exact)`);
				s.match = e;
			}
			t.push(s);
		}
	}
	return t;
}
function pe(e, t) {
	let r = {
		subformId: a(e),
		parameters: {},
		applicability: []
	};
	if (t && t.trim()) {
		let e = n(t), o = 0;
		for (; o < e.length;) {
			let t = e[o++];
			if (o < e.length) {
				if (t === "parameters") {
					let t = n(i(e[o++])), s = 0;
					for (; s < t.length;) {
						let e = P(t[s++]);
						s < t.length && (t[s] === ":" && s++, s < t.length && (r.parameters[e] = a(t[s++])));
					}
				} else t === "applicability" ? r.applicability = L(i(e[o++])) : i(e[o++]);
			}
		}
	}
	return r;
}
function me(e, t) {
	let n = "";
	if (e.subformRef && !e.name) {
		let r = e.subformRef;
		n += t + "subform_ref " + r.subformId + " { ";
		let i = Object.keys(r.parameters);
		if (i.length > 0) {
			n += "parameters { ";
			for (let e of i) n += e + ": " + r.parameters[e] + " ";
			n += "} ";
		}
		return r.applicability.length > 0 && (n += "applicability { " + R(r.applicability) + "} "), n += "}\n", n;
	}
	let r = [];
	if (e.subformRef) {
		let t = e.subformRef, n = "subform_ref " + t.subformId + " { ", i = Object.keys(t.parameters);
		if (i.length > 0) {
			n += "parameters { ";
			for (let e of i) n += e + ": " + t.parameters[e] + " ";
			n += "} ";
		}
		t.applicability.length > 0 && (n += "applicability { " + R(t.applicability) + "} "), r.push(n + "}");
	}
	if (e.label && r.push("label \"" + s(e.label) + "\""), e.definition && r.push("definition \"" + s(e.definition) + "\""), e.description && r.push("description \"" + s(e.description) + "\""), e.unit && r.push("unit \"" + s(e.unit) + "\""), e.symbol && r.push("symbol " + e.symbol), e.verdict && r.push("verdict " + e.verdict), e.dimension && r.push("dimension " + e.dimension), e.enumRef && r.push("enum " + e.enumRef), e.pattern && r.push("pattern \"" + s(e.pattern) + "\""), e.scope && r.push("scope " + e.scope), e.examples && r.push("examples \"" + s(e.examples) + "\""), e.bind && r.push("bind " + N(e.bind)), e.required && r.push("required true"), e.requiredWhen && r.push("required_when " + N(e.requiredWhen)), e.measurementMethod && r.push("measurement_method " + e.measurementMethod), e.calculationId && r.push("calculation " + N(e.calculationId)), e.calculationBindings.length > 0 && r.push("calculation_bindings { " + e.calculationBindings.map((e) => e.inputName + ": " + e.pathExpr).join(" ") + "}"), e.derivation && r.push("derivation \"" + s(e.derivation) + "\""), e.evaluation) {
		let t = "evaluation { rule \"" + s(e.evaluation.rule) + "\"";
		e.evaluation.verdict && (t += " verdict " + e.evaluation.verdict), e.evaluation.op && (t += " op " + e.evaluation.op), e.evaluation.limit && (t += " limit \"" + s(e.evaluation.limit) + "\""), e.evaluation.condition && (t += " condition \"" + s(e.evaluation.condition) + "\""), e.evaluation.referenceId && (t += " reference { " + e.evaluation.referenceId + " }"), e.evaluation.specificationReference && (t += " specification_reference \"" + s(e.evaluation.specificationReference) + "\""), e.evaluation.sourceDiscrepancy && (t += " " + j(e.evaluation.sourceDiscrepancy, "")), r.push(t + " }");
	}
	if (e.values.length > 0 && r.push("values { " + e.values.map(ae).join(" ") + " }"), e.hasDefault && r.push("default " + N(e.defaultValue)), e.trueLabel && r.push("true_label \"" + s(e.trueLabel) + "\""), e.falseLabel && r.push("false_label \"" + s(e.falseLabel) + "\""), e.enumValues.length > 0 && r.push("enum_values { " + e.enumValues.map(ae).join(" ") + " }"), e.itemsType) {
		let t = "items { " + e.itemsType;
		e.itemsUnit && (t += " unit \"" + s(e.itemsUnit) + "\""), r.push(t + " }");
	}
	if (e.minItems !== void 0 && e.minItems !== null && r.push("min_items " + N(String(e.minItems))), e.maxItems !== void 0 && e.maxItems !== null && r.push("max_items " + N(String(e.maxItems))), e.series && r.push(ne(e.series)), e.applicability.length > 0 && r.push("applicability { " + R(e.applicability) + "}"), e.targets.length > 0 && r.push("targets { " + e.targets.join(" ") + " }"), e.sourceRefs && e.sourceRefs.length > 0) for (let t of e.sourceRefs) r.push(E(t, "", s).trimEnd());
	if (e.fieldReferences.length > 0) for (let t of e.fieldReferences) r.push("ref " + ge(t.role) + " \"" + s(t.urn) + "\"");
	if (e.refs && e.refs.length > 0) for (let t of e.refs) r.push("ref " + t.predicate + " \"" + s(t.target) + "\"" + (t.note ? " { note \"" + s(t.note) + "\" }" : ""));
	e.correspondences && e.correspondences.length > 0 && r.push(k(e.correspondences, "", s, N).trimEnd()), e.specificationReference && r.push("specification_reference \"" + s(e.specificationReference) + "\""), e.sourceDiscrepancy && r.push(j(e.sourceDiscrepancy, "")), e.fields.length > 0 && r.push("fields {\n" + e.fields.map((e) => me(e, t + "    ")).join("") + t + "  }"), e.referenceIds.length > 0 && r.push("reference { " + e.referenceIds.join(" ") + " }");
	let i = e.type && (e.type !== "string" || e.typeDeclared) ? " : " + e.type : "";
	return r.length === 0 ? t + "field " + e.name + i + " { }\n" : r.every((e) => !e.includes("\n")) ? t + "field " + e.name + i + " { " + r.join(" ") + " }\n" : t + "field " + e.name + i + " {\n" + r.map((e) => t + "  " + e + "\n").join("") + t + "}\n";
}
function R(e) {
	let t = "";
	for (let n of e) if (n.mapping) {
		t += n.dimension + ": { ";
		let e = [];
		for (let [t, r] of Object.entries(n.mapping)) e.push(t + ": " + r);
		t += e.join(", ") + " ", t += "} ";
	} else t += n.dimension + ": [" + n.values.join(", ") + "] ", n.match && (t += "match " + n.match + " ");
	return t;
}
function he(e) {
	let t = [], r = n(e), o = 0;
	for (; o < r.length;) {
		let e = P(r[o++]);
		if (!e) break;
		if (o < r.length && r[o] === ":" && o++, o < r.length && r[o].startsWith("{")) {
			let s = n(i(r[o++])).map(a).filter((e) => e.length > 0);
			for (let n of s) t.push({
				urn: n,
				role: e
			});
		}
	}
	return t;
}
function ge(e) {
	return e === "source" ? "derives-from" : e === "reference" ? "cites" : e;
}
//#endregion
//#region src/ser-des/config/quantity.ts
var _e = /^-?\d+(\.\d+)?([eE][+-]?\d+)?$/;
function z(e) {
	return e.startsWith("\"") ? a(e) : _e.test(e) ? Number(e) : a(e);
}
function ve(e) {
	let t = { value: "" }, r = n(e), o = 0;
	for (; o < r.length;) {
		let e = r[o++];
		if (o >= r.length) break;
		e === "value" ? t.value = z(r[o++]) : e === "unit" ? t.unit = a(r[o++]) : e === "kind" || e === "quantity_kind" ? t.quantityKind = a(r[o++]) : e === "uncertainty" ? t.uncertainty = z(r[o++]) : e === "tolerance" ? t.tolerance = z(r[o++]) : i(r[o++]);
	}
	return t;
}
function ye(e) {
	return e.quantityKind !== void 0 || e.uncertainty !== void 0 || e.tolerance !== void 0;
}
function B(e) {
	return typeof e == "number" ? String(e) : e === "" ? "\"\"" : _e.test(e) || /[\s{}"]/.test(e) || e.endsWith(":") ? "\"" + s(e) + "\"" : e;
}
function be(e) {
	if (!ye(e)) {
		let t = B(e.value);
		return e.unit === void 0 ? t : t + " " + N(e.unit);
	}
	return xe(e);
}
function xe(e) {
	let t = ["value " + B(e.value)];
	return e.unit !== void 0 && t.push("unit \"" + s(e.unit) + "\""), e.quantityKind !== void 0 && t.push("kind " + N(e.quantityKind)), e.uncertainty !== void 0 && t.push("uncertainty " + B(e.uncertainty)), e.tolerance !== void 0 && t.push("tolerance " + B(e.tolerance)), "{ " + t.join(" ") + " }";
}
//#endregion
//#region src/ser-des/config/process.ts
function Se(e) {
	return e.trim() !== "" && !isNaN(Number(e)) ? Number(e) : e;
}
function Ce(e) {
	return !e.startsWith("\"") && e.endsWith(":") && e.length > 1;
}
function we(e, t = !1) {
	let r = [], o = n(e), s = 0;
	for (; s < o.length;) {
		let e = o[s++], n = P(e);
		if (!n) break;
		let c = e.endsWith(":");
		s < o.length && o[s] === ":" && (c = !0, s++);
		let l = "";
		c && s < o.length && (l = a(o[s++]));
		let u = {
			name: n,
			type: l
		};
		if (s < o.length && o[s] === "=") {
			if (!t) throw Error(`Parsing error: parameter "${n}" declares an initial value — initial values are a registers facet (signature parameters and call bindings take their values at the call)`);
			s++;
			let e = [];
			for (; s < o.length && o[s + 1] !== ":" && !Ce(o[s]);) e.push(o[s++]);
			if (e.length === 0) throw Error(`Parsing error: register "${n}" declares "=" with no value (shape: name : type = value [unit])`);
			if (e.length > 2) throw Error(`Parsing error: register "${n}" initial value has ${e.length} tokens (shape: name : type = value [unit]) — quote multi-word values`);
			if (e.length === 1 && e[0].startsWith("{")) u.initial = ve(i(e[0]));
			else {
				let [t, n] = e, r = z(t);
				u.initial = n === void 0 ? { value: r } : {
					value: r,
					unit: a(n)
				};
			}
		}
		r.push(u);
	}
	return r;
}
function Te(e) {
	let t = [], r = n(e), i = 0;
	for (; i < r.length;) {
		let e = M(r, i), n = a(e.text);
		i = e.next, n && t.push(n);
	}
	return t;
}
function Ee(e, t) {
	return t >= e.length ? t : e[t].startsWith("{") ? t + 1 : (t++, t < e.length && e[t].startsWith("{") && t++, t);
}
function De(e) {
	let t = [], r = n(e), o = 0;
	for (; o < r.length;) {
		if (r[o++] !== "precondition") {
			o = Ee(r, o);
			continue;
		}
		let e = {
			id: a(r[o++]),
			check: "",
			description: "",
			onViolation: "invalid"
		};
		if (o < r.length && r[o].startsWith("{")) {
			let t = n(i(r[o++])), s = 0;
			for (; s < t.length;) {
				let n = t[s++];
				if (s >= t.length) break;
				if (n === "check") {
					let n = M(t, s);
					e.check = a(n.text), s = n.next;
				} else n === "description" ? e.description = a(t[s++]) : n === "on_violation" ? e.onViolation = a(t[s++]) : i(t[s++]);
			}
		}
		t.push(e);
	}
	return t;
}
function Oe(e) {
	let t = [], r = n(e), o = 0;
	for (; o < r.length;) {
		if (r[o++] !== "constraint") {
			o = Ee(r, o);
			continue;
		}
		let e = {
			id: a(r[o++]),
			kind: "",
			clause: "",
			pair: [],
			period: "",
			barred: [],
			statement: ""
		};
		if (o < r.length && r[o].startsWith("{")) {
			let t = n(i(r[o++])), s = 0;
			for (; s < t.length;) {
				let r = t[s++];
				if (s >= t.length) break;
				r === "kind" ? e.kind = a(t[s++]) : r === "clause" ? e.clause = a(t[s++]) : r === "pair" ? e.pair.push(...n(a(t[s++])).map(P).map(a).filter((e) => e.length > 0)) : r === "period" ? e.period = a(t[s++]) : r === "barred" ? e.barred.push(...n(a(t[s++])).map(P).map(a).filter((e) => e.length > 0)) : r === "statement" ? e.statement = a(t[s++]) : i(t[s++]);
			}
		}
		t.push(e);
	}
	return t;
}
function ke(e) {
	let t = [], r = n(e), o = 0;
	for (; o < r.length;) {
		let e = a(r[o++]);
		if (!e) break;
		let n = {
			id: e,
			description: "",
			required: !1
		};
		o < r.length && r[o].startsWith("{") && v(i(r[o++]), (e, t) => {
			if (e === "description") n.description = a(t());
			else if (e === "required") n.required = a(t()) === "true";
			else return !1;
			return !0;
		}, {
			construct: "process evidence",
			id: e
		}), t.push(n);
	}
	return t;
}
function Ae(e) {
	let t = {
		rule: "",
		clause: ""
	};
	return v(e, (e, n) => {
		if (e === "rule") t.rule = a(n());
		else if (e === "clause") t.clause = a(n());
		else return !1;
		return !0;
	}, {
		construct: "process decision",
		id: ""
	}), t;
}
function je(e) {
	let t = {
		kind: "",
		action: ""
	};
	return v(e, (e, n) => {
		if (e === "kind") t.kind = a(n());
		else if (e === "action") t.action = a(n());
		else return !1;
		return !0;
	}, {
		construct: "process declaration",
		id: ""
	}), t;
}
function Me(e) {
	let t = [], o = n(e), s = 0;
	for (; s < o.length;) {
		if (o[s++] !== "window") {
			s = Ee(o, s);
			continue;
		}
		let e = a(o[s++]), n = {
			id: e,
			kind: "",
			clause: "",
			anchor: "",
			applies_to: "",
			windowYears: 0,
			windowMonths: 0,
			breach: "",
			description: ""
		};
		s < o.length && o[s].startsWith("{") && v(i(o[s++]), (e, t) => {
			if (e === "kind") n.kind = a(t());
			else if (e === "clause") n.clause = a(t());
			else if (e === "anchor") n.anchor = a(t());
			else if (e === "applies_to") n.applies_to = a(t());
			else if (e === "window") {
				let e = r(i(t()));
				for (let t = 0; t + 1 < e.length; t += 2) e[t] === "years" ? n.windowYears = parseInt(a(e[t + 1]), 10) || 0 : e[t] === "months" && (n.windowMonths = parseInt(a(e[t + 1]), 10) || 0);
			} else if (e === "breach") n.breach = a(t());
			else if (e === "description") n.description = a(t());
			else return !1;
			return !0;
		}, {
			construct: "process window",
			id: e
		}), t.push(n);
	}
	return t;
}
function Ne(e) {
	let t = {
		by: "",
		values: {}
	}, r = n(e), o = 0;
	for (; o < r.length;) {
		let e = r[o++];
		if (o >= r.length) break;
		if (e === "by") t.by = a(r[o++]);
		else if (e === "values") {
			let e = n(i(r[o++])), s = 0;
			for (; s < e.length;) {
				let r = P(e[s++]);
				if (s >= e.length) break;
				if (e[s] === ":" && s++, s < e.length && e[s].startsWith("{")) {
					let o = n(i(e[s++])), c = {}, l = 0;
					for (; l < o.length;) {
						let e = P(o[l++]);
						if (l >= o.length) break;
						o[l] === ":" && l++, l < o.length && (c[e] = Se(a(o[l++])));
					}
					t.values[r] = c;
				}
			}
		} else o = y(r, o, e);
	}
	return t;
}
var Pe = /* @__PURE__ */ new Set([
	"action",
	"approval",
	"gateway",
	"parallel_gateway",
	"start_event",
	"end_event",
	"timer_event",
	"signal_event"
]);
function Fe(e, t, r) {
	let o = {
		id: e,
		kind: t,
		executor: "",
		role: "",
		capture: "",
		reads: [],
		writes: [],
		wait: "",
		period: "",
		signal: "",
		fires: "",
		calls: "",
		callIn: [],
		callOut: [],
		description: ""
	}, s = n(r), c = 0;
	for (; c < s.length;) {
		let t = s[c++];
		if (c >= s.length) break;
		if (t === "executor") {
			let t = a(s[c++]);
			if (t !== "machine" && t !== "actor") throw Error(`Parsing error: process step. ID ${e}: Unknown executor ${t} (valid: machine, actor)`);
			o.executor = t;
		} else if (t === "role") o.role = a(s[c++]);
		else if (t === "capture") o.capture = a(s[c++]);
		else if (t === "read") o.reads.push(...n(a(s[c++])).map(P).map(a).filter((e) => e.length > 0));
		else if (t === "write") o.writes.push(...n(a(s[c++])).map(P).map(a).filter((e) => e.length > 0));
		else if (t === "wait") o.wait = a(s[c++]);
		else if (t === "period") o.period = a(s[c++]);
		else if (t === "signal") o.signal = a(s[c++]);
		else if (t === "fires") o.fires = a(s[c++]);
		else if (t === "calls") {
			if (o.calls = a(s[c++]), c < s.length && s[c].startsWith("{")) {
				let e = (e) => we(i(e)).map((e) => ({
					param: e.name,
					bind: e.type
				})), t = n(i(s[c++])), r = 0;
				for (; r < t.length;) {
					let a = t[r++];
					if (r >= t.length) break;
					if (a === "with") {
						let a = n(i(t[r++])), s = 0;
						for (; s < a.length;) {
							let t = a[s++];
							if (s >= a.length) break;
							t === "in" ? o.callIn.push(...e(a[s++])) : t === "out" ? o.callOut.push(...e(a[s++])) : i(a[s++]);
						}
					} else r = Ee(t, r);
				}
			}
		} else t === "description" ? o.description = a(s[c++]) : c = Ee(s, c);
	}
	return o;
}
function Ie(e) {
	let t = [], r = n(e);
	for (let e of r) if (!e.startsWith("{") && !e.startsWith("\"") && e !== "->" && e !== "→" && (e.includes("->") || e.includes("→"))) throw Error(`Parsing error: process flow edge "${e}" contains a fused arrow — separate steps and "->" with whitespace`);
	let o = 0;
	for (; o < r.length;) {
		let e = a(r[o++]);
		if (!e) break;
		for (; o < r.length && (r[o] === "->" || r[o] === "→") && (o++, !(o >= r.length));) {
			let s = a(r[o++]), c = "";
			if (o < r.length && r[o].startsWith("{")) {
				let e = n(i(r[o++])), t = 0;
				for (; t < e.length;) {
					let n = e[t++];
					if (t >= e.length) break;
					if (n === "when" || n === "condition") {
						let n = M(e, t);
						c = a(n.text), t = n.next;
					} else i(e[t++]);
				}
			}
			t.push({
				from: e,
				to: s,
				condition: c
			}), e = s;
		}
	}
	return t;
}
function Le(e) {
	let t = {
		steps: [],
		edges: []
	}, r = n(e), o = 0;
	for (; o < r.length;) {
		let e = r[o++];
		if (o >= r.length) break;
		if (e === "flow") t.edges.push(...Ie(i(r[o++])));
		else if (Pe.has(e)) {
			let n = a(r[o++]), s = "";
			o < r.length && r[o].startsWith("{") && (s = i(r[o++])), t.steps.push(Fe(n, e, s));
		} else {
			let e = r[o++];
			e !== void 0 && !e.startsWith("{") && o < r.length && r[o].startsWith("{") && o++;
		}
	}
	return t;
}
var Re = function(e, t) {
	let o = {
		id: e,
		name: "",
		modality: "",
		phase: "",
		guards: [],
		machineSteps: [],
		actor: null,
		output: [],
		input: [],
		provision: [],
		page: null,
		measure: [],
		parent: "",
		children: [],
		signature: null,
		invariants: [],
		activityKinds: [],
		segregation: [],
		preconditions: [],
		executor: "",
		registers: [],
		state: "",
		instances: null,
		childComposition: "all",
		does: null,
		summary: "",
		roles: [],
		organs: [],
		participantKinds: [],
		evidence: [],
		decision: null,
		declaration: null,
		dischargesGate: "",
		realizedBy: [],
		approvedBy: [],
		windows: [],
		source: null,
		provisionRefs: [],
		outputRefs: [],
		inputRefs: [],
		actorRef: "",
		_relations: {
			actor: "",
			output: [],
			input: [],
			provision: [],
			page: ""
		}
	}, s = [];
	if (t.trim() !== "") {
		let n = r(t), i = [], a = 0;
		for (; a < n.length;) if (n[a] === "process" && a + 2 < n.length && n[a + 2].startsWith("{")) {
			let t = n[a + 1], r = n[a + 2], i = Re(t, r);
			s.push((n) => {
				n = i(n);
				let r = n.processes[t];
				return r && (r.parent = e), n;
			}), o.children.push(t), a += 3;
		} else i.push(n[a]), a++;
		t = "{ " + i.join(" ") + " }";
	}
	return v(t, (t, s, c) => {
		if (t === "modality") o.modality = s();
		else if (t === "phase") o.phase = a(s());
		else if (t === "guard") o.guards.push(x(s));
		else if (t === "machine_steps") o.machineSteps = n(a(s())).map(P).map(a).filter((e) => e.length > 0);
		else if (t === "name") o.name = x(s);
		else if (t === "actor") o._relations.actor = s();
		else if (t === "parent") o.parent = s();
		else if (t === "canvas" || t === "subprocess") o._relations.page = s();
		else if (t === "validate_provision") o._relations.provision = r(s());
		else if (t === "validate_measurement") o.measure = r(s()).map((e) => i(e));
		else if (t === "output") o._relations.output = r(s()).map((e) => a(e));
		else if (t === "reference_data_registry") o._relations.input = r(s()).map((e) => a(e));
		else if (t === "signature") {
			let e = {
				inputs: [],
				outputs: []
			}, t = n(i(s())), r = 0;
			for (; r < t.length;) {
				let n = t[r++];
				if (r >= t.length) break;
				n === "in" ? e.inputs.push(...we(i(t[r++]))) : n === "out" ? e.outputs.push(...we(i(t[r++]))) : i(t[r++]);
			}
			o.signature = e;
		} else if (t === "invariants") o.invariants = Te(i(s()));
		else if (t === "activity_kind") o.activityKinds = n(a(s())).map(P).map(a).filter((e) => e.length > 0);
		else if (t === "summary") o.summary = x(s);
		else if (t === "roles") o.roles = n(a(s())).map(P).map(a).filter((e) => e.length > 0);
		else if (t === "organs") o.organs = n(a(s())).map(P).map(a).filter((e) => e.length > 0);
		else if (t === "participant_kinds") o.participantKinds = n(a(s())).map(P).map(a).filter((e) => e.length > 0);
		else if (t === "evidence") o.evidence = ke(i(s()));
		else if (t === "decision") o.decision = Ae(i(s()));
		else if (t === "declaration") o.declaration = je(i(s()));
		else if (t === "discharges_gate") o.dischargesGate = a(s());
		else if (t === "realized_by") o.realizedBy = n(a(s())).map(P).map(a).filter((e) => e.length > 0);
		else if (t === "approved_by") o.approvedBy = n(a(s())).map(P).map(a).filter((e) => e.length > 0);
		else if (t === "windows") o.windows = Me(i(s()));
		else if (t === "segregation") o.segregation = Oe(i(s()));
		else if (t === "preconditions") o.preconditions = De(i(s()));
		else if (t === "executor") o.executor = a(s());
		else if (t === "registers") o.registers = we(i(s()), !0);
		else if (t === "state") o.state = a(s());
		else if (t === "instances") o.instances = Ne(i(s()));
		else if (t === "child_composition") {
			let t = a(s());
			if (t !== "all" && t !== "gateway") throw Error(`Parsing error: process. ID ${e}: Unknown child_composition "${t}" (valid: all, gateway)`);
			o.childComposition = t;
		} else if (t === "does") o.does = Le(i(s()));
		else if (t === "source") {
			let e = I(i(s()));
			o.source ||= e, (o.sourceRefs ??= []).push(e);
		} else if (t === "ref") {
			let e = C(s, c, a, i);
			T(o, e) || (o.refs ??= []).push(e);
		} else if (t === "corresponds") (o.correspondences ??= []).push(O(s, c, a));
		else return !1;
		return !0;
	}, {
		construct: "process",
		id: e
	}), (t) => {
		t.processes[e] = o;
		for (let e of s) t = e(t);
		return t;
	};
}, ze = function(e, t) {
	let { _relations: n, ...r } = t, i = {
		...r,
		output: [],
		input: [],
		provision: [],
		provisionRefs: [...n.provision],
		outputRefs: [...n.output],
		inputRefs: [...n.input],
		actorRef: n.actor,
		actor: null,
		page: null
	};
	for (let t of n.output) {
		let n = f(e, "regs", t);
		n !== void 0 && i.output.push(n);
	}
	for (let t of n.input) {
		let n = f(e, "regs", t);
		n !== void 0 && i.input.push(n);
	}
	for (let t of n.provision) {
		let n = f(e, "provisions", t);
		n !== void 0 && i.provision.push(n);
	}
	return n.actor !== "" && (i.actor = f(e, "roles", n.actor) ?? null), n.page !== "" && (i.page = f(e, "pages", n.page) ?? null), i;
};
function Be(e) {
	return e.split("\n").map((e) => e && "  " + e).join("\n");
}
function Ve(e, t, n = !1) {
	let r = Ke(e, { nested: n });
	if (e.children.length > 0) {
		let n = [];
		for (let r of e.children) {
			let e = t.get(r);
			e && n.push(Be(Ve(e, t, !0)));
		}
		n.length > 0 && (r = r.replace(/\n}\n$/, "\n" + n.join("\n") + "}\n"));
	}
	return r;
}
function He(e) {
	return e.map((e) => e.name + (e.type ? " : " + e.type : "") + (e.initial === void 0 ? "" : " = " + be(e.initial))).join(" ");
}
function Ue(e) {
	let t = "  signature {\n";
	return e.inputs.length > 0 && (t += "    in { " + He(e.inputs) + " }\n"), e.outputs.length > 0 && (t += "    out { " + He(e.outputs) + " }\n"), t += "  }\n", t;
}
function We(e) {
	let t = [];
	if (e.executor && t.push("executor " + e.executor), e.role && t.push("role " + N(e.role)), e.capture && t.push("capture " + N(e.capture)), e.reads.length > 0 && t.push("read { " + e.reads.map(N).join(" ") + " }"), e.writes.length > 0 && t.push("write { " + e.writes.map(N).join(" ") + " }"), e.wait && t.push("wait " + N(e.wait)), e.period && t.push("period " + N(e.period)), e.signal && t.push("signal " + N(e.signal)), e.fires && t.push("fires " + N(e.fires)), e.calls) {
		let n = "calls " + N(e.calls);
		if (e.callIn.length > 0 || e.callOut.length > 0) {
			let t = (e) => e.map((e) => N(e.param) + " : " + N(e.bind)).join(" ");
			n += " { with {", e.callIn.length > 0 && (n += " in { " + t(e.callIn) + " }"), e.callOut.length > 0 && (n += " out { " + t(e.callOut) + " }"), n += " } }";
		}
		t.push(n);
	}
	return e.description && t.push("description \"" + s(e.description) + "\""), t.length === 0 ? "    " + e.kind + " " + e.id + "\n" : "    " + e.kind + " " + e.id + " { " + t.join(" ") + " }\n";
}
function Ge(e) {
	let t = "  does {\n";
	for (let n of e.steps) t += We(n);
	if (e.edges.length > 0) {
		t += "    flow {\n";
		for (let n of e.edges) t += "      " + n.from + " -> " + n.to, n.condition && (t += " { when \"" + s(n.condition) + "\" }"), t += "\n";
		t += "    }\n";
	}
	return t += "  }\n", t;
}
var Ke = function(e, t) {
	let n = "process " + e.id + " {\n";
	n += "  name \"" + s(e.name) + "\"\n", e.summary && (n += "  summary \"" + s(e.summary) + "\"\n");
	let r = e.actorRef || e.actor?.id || "";
	if (r !== "" && (n += "  actor " + N(r) + "\n"), e.modality !== "" && (n += "  modality " + e.modality + "\n"), e.phase && (n += "  phase " + N(e.phase) + "\n"), e.guards && e.guards.length > 0) for (let t of e.guards) n += "  guard \"" + s(t) + "\"\n";
	e.machineSteps && e.machineSteps.length > 0 && (n += "  machine_steps { " + e.machineSteps.map(N).join(" ") + " }\n");
	let i = e.inputRefs && e.inputRefs.length > 0 ? e.inputRefs : e.input.map((e) => e.id);
	if (i.length > 0) {
		n += "  reference_data_registry {\n";
		for (let e of i) n += "    " + N(e) + "\n";
		n += "  }\n";
	}
	if (e.provisionRefs.length > 0) {
		n += "  validate_provision {\n";
		for (let t of e.provisionRefs) n += "    " + t + "\n";
		n += "  }\n";
	}
	if (e.measure.length > 0) {
		n += "  validate_measurement {\n";
		for (let t of e.measure) n += "    \"" + t + "\"\n";
		n += "  }\n";
	}
	let a = e.outputRefs && e.outputRefs.length > 0 ? e.outputRefs : e.output.map((e) => e.id);
	if (a.length > 0) {
		n += "  output {\n";
		for (let e of a) n += "    " + N(e) + "\n";
		n += "  }\n";
	}
	if (e.page !== null && (n += "  canvas " + e.page.id + "\n"), e.signature !== null && e.signature !== void 0 && (n += Ue(e.signature)), e.invariants && e.invariants.length > 0) {
		n += "  invariants {\n";
		for (let t of e.invariants) n += "    \"" + s(t) + "\"\n";
		n += "  }\n";
	}
	if (e.activityKinds && e.activityKinds.length > 0 && (n += "  activity_kind { " + e.activityKinds.map(N).join(" ") + " }\n"), e.roles && e.roles.length > 0 && (n += "  roles { " + e.roles.map(N).join(" ") + " }\n"), e.organs && e.organs.length > 0 && (n += "  organs { " + e.organs.map(N).join(" ") + " }\n"), e.participantKinds && e.participantKinds.length > 0 && (n += "  participant_kinds { " + e.participantKinds.map(N).join(" ") + " }\n"), e.evidence && e.evidence.length > 0) {
		n += "  evidence {\n";
		for (let t of e.evidence) n += "    " + N(t.id) + " {", t.description && (n += " description \"" + s(t.description) + "\""), t.required && (n += " required true"), n += " }\n";
		n += "  }\n";
	}
	if (e.decision && (n += "  decision {", e.decision.rule && (n += " rule " + N(e.decision.rule)), e.decision.clause && (n += " clause \"" + s(e.decision.clause) + "\""), n += " }\n"), e.declaration && (n += "  declaration {", e.declaration.kind && (n += " kind " + N(e.declaration.kind)), e.declaration.action && (n += " action " + N(e.declaration.action)), n += " }\n"), e.dischargesGate && (n += "  discharges_gate " + N(e.dischargesGate) + "\n"), e.realizedBy && e.realizedBy.length > 0 && (n += "  realized_by { " + e.realizedBy.map(N).join(" ") + " }\n"), e.approvedBy && e.approvedBy.length > 0 && (n += "  approved_by { " + e.approvedBy.map(N).join(" ") + " }\n"), e.windows && e.windows.length > 0) {
		n += "  windows {\n";
		for (let t of e.windows) n += "    window " + N(t.id) + " {\n", t.kind && (n += "      kind " + N(t.kind) + "\n"), t.clause && (n += "      clause \"" + s(t.clause) + "\"\n"), t.anchor && (n += "      anchor " + N(t.anchor) + "\n"), t.applies_to && (n += "      applies_to " + N(t.applies_to) + "\n"), (t.windowYears > 0 || t.windowMonths > 0) && (n += "      window {", t.windowYears > 0 && (n += " years " + t.windowYears), t.windowMonths > 0 && (n += " months " + t.windowMonths), n += " }\n"), t.breach && (n += "      breach " + N(t.breach) + "\n"), t.description && (n += "      description \"" + s(t.description) + "\"\n"), n += "    }\n";
		n += "  }\n";
	}
	if (e.segregation && e.segregation.length > 0) {
		n += "  segregation {\n";
		for (let t of e.segregation) n += "    constraint " + t.id + " {\n", t.kind && (n += "      kind " + N(t.kind) + "\n"), t.clause && (n += "      clause \"" + s(t.clause) + "\"\n"), t.pair.length > 0 && (n += "      pair { " + t.pair.map(N).join(" ") + " }\n"), t.period && (n += "      period " + N(t.period) + "\n"), t.barred.length > 0 && (n += "      barred { " + t.barred.map(N).join(" ") + " }\n"), t.statement && (n += "      statement \"" + s(t.statement) + "\"\n"), n += "    }\n";
		n += "  }\n";
	}
	if (e.preconditions && e.preconditions.length > 0) {
		n += "  preconditions {\n";
		for (let t of e.preconditions) {
			let e = "    precondition " + t.id + " { ";
			t.check && (e += "check \"" + s(t.check) + "\" "), t.description && (e += "description \"" + s(t.description) + "\" "), e += "on_violation " + t.onViolation + " ", n += e + "}\n";
		}
		n += "  }\n";
	}
	if (e.executor && (n += "  executor " + N(e.executor) + "\n"), e.registers && e.registers.length > 0 && (n += "  registers { " + He(e.registers) + " }\n"), e.state && (n += "  state " + N(e.state) + "\n"), e.instances) {
		let t = "  instances { by " + e.instances.by + " values { ";
		for (let [n, r] of Object.entries(e.instances.values)) {
			t += n + " { ";
			for (let [e, n] of Object.entries(r)) t += e + ": " + N(String(n)) + " ";
			t += "} ";
		}
		n += t + "} }\n";
	}
	e.childComposition === "gateway" && (n += "  child_composition gateway\n"), e.does && (n += Ge(e.does));
	for (let t of e.sourceRefs ?? (e.source && (e.source.doc || e.source.clause) ? [e.source] : [])) n += E(t, "  ", s);
	return n += w(e.refs, "  ", s), n += k(e.correspondences, "  ", s, N), e.parent && (e.children.length === 0 || !t?.nested) && (n += "  parent " + e.parent + "\n"), n += "}\n", n;
};
//#endregion
//#region src/ser-des/dump.ts
function qe(e, t) {
	let n = "";
	e.root !== null && (n += "root " + e.root.id + "\n\n"), n += h(e.meta) + "\n";
	let r = /* @__PURE__ */ new Set();
	for (let t of e.processes) for (let e of t.children) r.add(e);
	let i = new Map(e.processes.map((e) => [e.id, e]));
	return Object.keys(t).forEach((a) => {
		if (a === "processes") {
			for (let t of e.processes) r.has(t.id) || (n += Ve(t, i));
			return;
		}
		let o = e[a], s = t[a];
		for (let e of o) n += s(e);
	}), n;
}
//#endregion
//#region src/ser-des/config/approval.ts
var Je = function(e, t) {
	let n = {
		id: e,
		name: "",
		modality: "",
		actorRef: "",
		approverRef: "",
		recordRefs: [],
		actor: null,
		approver: null,
		records: [],
		ref: [],
		source: null,
		_relations: {
			actor: "",
			approver: "",
			records: [],
			ref: []
		}
	};
	return v(t, (e, t) => {
		if (e === "modality") n.modality = t();
		else if (e === "name") n.name = x(t);
		else if (e === "actor") n._relations.actor = t();
		else if (e === "approve_by") n._relations.approver = t();
		else if (e === "approval_record") n._relations.records = r(t());
		else if (e === "reference") n._relations.ref = r(t());
		else if (e === "source") n.source = I(i(t()));
		else return !1;
		return !0;
	}, {
		construct: "approval",
		id: e
	}), (t) => (t.approvals[e] = n, t);
}, Ye = function(e, t) {
	let { _relations: n, ...r } = t, i = {
		...r,
		actorRef: n.actor,
		approverRef: n.approver,
		recordRefs: [...n.records],
		records: [],
		ref: []
	};
	n.actor !== "" && (i.actor = f(e, "roles", n.actor) ?? null), n.approver !== "" && (i.approver = f(e, "roles", n.approver) ?? null);
	for (let t of n.records) {
		let n = f(e, "regs", t);
		n !== void 0 && i.records.push(n);
	}
	for (let t of n.ref) {
		let n = f(e, "references", t);
		n !== void 0 && i.ref.push(n);
	}
	return i;
}, Xe = function(e) {
	let t = "approval " + e.id + " {\n";
	if (t += "  name \"" + s(e.name) + "\"\n", e.actorRef && (t += "  actor " + e.actorRef + "\n"), e.modality !== "" && (t += "  modality " + e.modality + "\n"), e.approverRef && (t += "  approve_by " + e.approverRef + "\n"), e.recordRefs.length > 0) {
		t += "  approval_record {\n";
		for (let n of e.recordRefs) t += "    " + n + "\n";
		t += "  }\n";
	}
	if (e.ref.length > 0) {
		t += "  reference {\n";
		for (let n of e.ref) t += "    " + n.id + "\n";
		t += "  }\n";
	}
	return e.source && (e.source.doc || e.source.clause) && (t += "  source {\n", e.source.doc && (t += "    doc \"" + s(e.source.doc) + "\"\n"), e.source.clause && (t += "    clause \"" + s(e.source.clause) + "\"\n"), t += "  }\n"), t += "}\n", t;
}, Ze = (e, t) => {
	let n = {
		id: e,
		values: []
	};
	return v(t, (e, t) => (n.values.push(Qe(e, t())), !0), {
		construct: "enum",
		id: e
	}), (t) => (t.enums[e] = n, t);
}, Qe = (e, t) => {
	let n = {
		id: e,
		value: ""
	};
	return v(t, (e, t) => {
		if (e === "definition") n.value = x(t);
		else return !1;
		return !0;
	}, {
		construct: "enum value",
		id: e
	}), n;
}, $e = function(e, t) {
	let n = {
		id: e,
		title: "",
		data: null,
		_relations: { data: "" }
	};
	return v(t, (e, t) => {
		if (e === "title") n.title = x(t);
		else if (e === "data_class") n._relations.data = t();
		else return !1;
		return !0;
	}, {
		construct: "registry",
		id: e
	}), (t) => (t.regs[e] = n, t);
}, et = function(e, t) {
	let n = {
		id: e,
		attributes: []
	};
	return b(t, (e, t) => {
		if (e.startsWith("ref ")) {
			let r = e.match(/^ref\s+(\S+)\s+"([^"]*)"$/);
			if (r) {
				let e = {
					predicate: r[1],
					target: r[2]
				};
				if (t) {
					let n = /note\s+"([^"]*)"/.exec(t) ?? /note\s+(\S+)/.exec(t);
					n && (e.note = n[1]);
				}
				n.ref ??= [], n.ref.push(e);
				return;
			}
		}
		let r = e.trim();
		if (r === "store") {
			n.store = t.trim();
			return;
		}
		if (r === "description") {
			n.description = a(t.trim());
			return;
		}
		if (r === "indexes") {
			n.indexes = t.split(/\s+/).filter((e) => e.length > 0);
			return;
		}
		if (r === "helper") {
			n.helper = t.trim() === "true";
			return;
		}
		if (r === "extends") {
			n.extends = t.trim();
			return;
		}
		n.attributes.push(tt(r, t));
	}, {
		construct: "class",
		id: e
	}), (t) => (t.dataclasses[e] = n, t);
}, tt = (e, t) => {
	let n = {
		id: "",
		type: "",
		modality: "",
		cardinality: "",
		definition: "",
		ref: [],
		satisfy: [],
		_relations: { ref: [] }
	}, i = e.match(/^(.*?)\s*\[([\d*][^\]]*)\]\s*$/);
	i && (n.cardinality = i[2].trim(), e = i[1]);
	let a = e.indexOf(":");
	return a !== -1 && (n.type = e.substr(a + 1, e.length - a - 1).trim(), e = e.substr(0, a)), n.id = e.trim(), v(t, (e, t) => {
		if (e === "modality") n.modality = t();
		else if (e === "definition") n.definition = x(t);
		else if (e === "reference") n._relations.ref = r(t());
		else if (e === "satisfy") n.satisfy = r(t());
		else if (e === "on_delete") n.onDelete = t();
		else if (e === "deprecated") n.deprecated = t() === "true";
		else if (e === "enum_values") n.enumValues = r(t());
		else if (e === "required") n.required = t() === "true";
		else if (e === "unit") n.unit = x(t);
		else if (e === "default") n.defaultValue = x(t);
		else return !1;
		return !0;
	}, {
		construct: "data attribute",
		id: n.id
	}), n;
}, nt = function(e, t) {
	let n = t.attributes.map((t) => {
		let n = {
			...t,
			ref: []
		};
		for (let r of t._relations.ref) {
			let t = f(e, "references", r);
			t !== void 0 && n.ref.push(t);
		}
		return n;
	});
	return {
		id: t.id,
		attributes: n,
		...t.store === void 0 ? {} : { store: t.store },
		...t.indexes === void 0 ? {} : { indexes: t.indexes },
		...t.helper === void 0 ? {} : { helper: t.helper },
		...t.extends === void 0 ? {} : { extends: t.extends },
		...t.description === void 0 ? {} : { description: t.description },
		...t.ref === void 0 ? {} : { ref: t.ref }
	};
}, rt = function(e, t) {
	let { _relations: n, ...r } = t, i = {
		...r,
		data: null
	};
	if (n.data !== "") {
		let t = f(e, "dataclasses", n.data);
		t !== void 0 && (i.data = t);
	}
	return i;
}, it = function(e) {
	let t = "class " + e.id + " {\n";
	if (e.store && (t += "  store { " + e.store + " }\n"), e.description && (t += "  description { \"" + s(e.description) + "\" }\n"), e.indexes && e.indexes.length > 0 && (t += "  indexes { " + e.indexes.join(" ") + " }\n"), e.helper !== void 0 && (t += "  helper { " + e.helper + " }\n"), e.extends && (t += "  extends { " + e.extends + " }\n"), e.ref && e.ref.length > 0) for (let n of e.ref) t += "  ref " + n.predicate + " \"" + s(n.target) + "\"", n.note && (t += " { note \"" + s(n.note) + "\" }"), t += "\n";
	for (let n of e.attributes) t += at(n);
	return t += "}\n", t;
}, at = (e) => {
	let t = "  " + e.id;
	if (e.type !== "" && (t += ": " + e.type), e.cardinality !== "" && (t += "[" + e.cardinality + "]"), t += " {\n", t += "    definition \"" + s(e.definition) + "\"\n", e.modality !== "" && (t += "    modality " + e.modality + "\n"), e.onDelete && (t += "    on_delete " + e.onDelete + "\n"), e.deprecated && (t += "    deprecated true\n"), e.enumValues && e.enumValues.length > 0 && (t += "    enum_values { " + e.enumValues.join(" ") + " }\n"), e.required !== void 0 && (t += "    required " + (e.required ? "true" : "false") + "\n"), e.unit && (t += "    unit \"" + s(e.unit) + "\"\n"), e.defaultValue !== void 0 && (t += "    default \"" + s(e.defaultValue) + "\"\n"), e.satisfy.length > 0) {
		t += "    satisfy {\n";
		for (let n of e.satisfy) t += "      " + n + "\n";
		t += "    }\n";
	}
	if (e.ref.length > 0) {
		t += "    reference {\n";
		for (let n of e.ref) t += "      " + n.id + "\n";
		t += "    }\n";
	}
	return t += "  }\n", t;
}, ot = (e) => {
	let t = "  " + e.id + " {\n";
	return t += "    definition \"" + s(e.value) + "\"\n", t += "  }\n", t;
}, st = function(e) {
	let t = "enum " + e.id + " {\n";
	for (let n of e.values) t += ot(n);
	return t += "}\n", t;
}, ct = function(e) {
	let t = "data_registry " + e.id + " {\n";
	return t += "  title \"" + s(e.title) + "\"\n", e.data !== null && (t += "  data_class " + e.data.id + "\n"), t += "}\n", t;
}, lt = function(e, t) {
	let n = {
		id: e,
		type: "",
		definition: "",
		description: ""
	};
	return v(t, (e, t) => {
		if (e === "type") n.type = t();
		else if (e === "definition") n.definition = x(t);
		else if (e === "description") n.description = x(t);
		else return !1;
		return !0;
	}, {
		construct: "variable",
		id: e
	}), (t) => (t.variables[e] = n, t);
}, ut = function(e) {
	let t = "variable " + e.id + " {\n";
	return e.type !== "" && (t += "  type " + e.type + "\n"), e.definition !== "" && (t += "  definition \"" + s(e.definition) + "\"\n"), e.description !== "" && (t += "  description \"" + s(e.description) + "\"\n"), t += "}\n", t;
}, dt = function(e, t) {
	let n = {
		id: e,
		eventType: "end"
	};
	if (t !== "" && r(t).length > 0) throw Error(`Parsing error: end_event. ID ${e}: Expecting empty body`);
	return (t) => (t.events[e] = n, t);
}, ft = function(e, t) {
	let n = {
		id: e,
		eventType: "signalcatch",
		signal: ""
	};
	if (t !== "") {
		let a = r(t), o = 0;
		for (; o < a.length;) {
			let t = a[o++];
			if (o < a.length) t === "catch" ? n.signal = i(a[o++]) : o++;
			else throw Error(`Parsing error: Signal Catch Event. ID ${e}: Expecting value for ${t}`);
		}
	}
	return (t) => (t.events[e] = n, t);
}, pt = function(e, t) {
	let n = {
		id: e,
		eventType: "start"
	};
	if (t !== "" && r(t).length > 0) throw Error(`Parsing error: end_event. ID ${e}: Expecting empty body`);
	return (t) => (t.events[e] = n, t);
}, mt = function(e, t) {
	let n = {
		id: e,
		eventType: "timer",
		type: "",
		para: ""
	};
	if (t !== "") {
		let a = r(t), o = 0;
		for (; o < a.length;) {
			let t = a[o++];
			if (o < a.length) t === "type" ? n.type = a[o++] : t === "para" ? n.para = i(a[o++]) : o++;
			else throw Error(`Parsing error: Timer Event. ID ${e}: Expecting value for ${t}`);
		}
	}
	return (t) => (t.events[e] = n, t);
}, ht = function(e) {
	return e.eventType === "start" ? vt(e) : e.eventType === "end" ? gt(e) : e.eventType === "signalcatch" ? _t(e) : e.eventType === "timer" ? yt(e) : "";
};
function gt(e) {
	return "end_event " + e.id + " {\n}\n";
}
function _t(e) {
	let t = "signal_catch_event " + e.id + " {\n";
	return e.signal !== "" && (t += "  catch \"" + s(e.signal) + "\"\n"), t += "}\n", t;
}
function vt(e) {
	return "start_event " + e.id + " {\n}\n";
}
function yt(e) {
	let t = "timer_event " + e.id + " {\n";
	return e.type !== "" && (t += "  type " + e.type + "\n"), e.para !== "" && (t += "  para \"" + s(e.para) + "\"\n"), t += "}\n", t;
}
//#endregion
//#region src/ser-des/config/gateway.ts
var bt = function(e, t) {
	let r = {
		id: e,
		gatewayType: "exclusive_gateway",
		label: "",
		edges: []
	};
	return v(t, (e, t) => {
		if (e === "label") r.label = x(t);
		else if (e === "edge") {
			let e = {
				target: a(t()),
				condition: "",
				label: ""
			}, o = n(i(t()));
			for (let t = 0; t + 1 < o.length; t += 2) o[t] === "condition" ? e.condition = a(o[t + 1]) : o[t] === "label" && (e.label = a(o[t + 1]));
			r.edges.push(e);
		} else return !1;
		return !0;
	}, {
		construct: "Exclusive gateway",
		id: e
	}), (t) => (t.gateways[e] = r, t);
}, xt = function(e) {
	return e.gatewayType === "exclusive_gateway" ? St(e) : "";
};
function St(e) {
	let t = "exclusive_gateway " + e.id + " {\n";
	e.label !== "" && (t += "  label \"" + s(e.label) + "\"\n");
	for (let n of e.edges ?? []) t += "  edge " + N(n.target) + " {", n.condition === "default" ? t += " condition default" : n.condition !== "" && (t += " condition \"" + s(n.condition) + "\""), n.label !== "" && (t += " label \"" + s(n.label) + "\""), t += " }\n";
	return t += "}\n", t;
}
//#endregion
//#region src/ser-des/config/processModel.ts
function Ct(e) {
	return r(e).map(P).map(a).filter((e) => e.length > 0);
}
function wt(e, t) {
	let n = {
		id: e,
		label: "",
		clause: "",
		maintainer: "",
		published: "",
		entries: ""
	};
	return v(t, (e, t) => {
		if (e === "label") n.label = a(t());
		else if (e === "clause") n.clause = a(t());
		else if (e === "maintainer") n.maintainer = a(t());
		else if (e === "published") n.published = a(t());
		else if (e === "entries") n.entries = a(t());
		else return !1;
		return !0;
	}, {
		construct: "process_model register",
		id: e
	}), n;
}
var Tt = (e, t) => {
	let n = {
		id: e,
		sequence: [],
		registers: [],
		source: {
			doc: "",
			clause: ""
		}
	};
	return v(t, (t, r, o) => {
		if (t === "sequence") n.sequence = Ct(i(r()));
		else if (t === "register") {
			let t = a(r()), s = o();
			if (s === void 0 || !s.startsWith("{")) throw Error(`Parsing error: process_model. ID ${e}: register ${t} is missing its block`);
			n.registers.push(wt(t, i(r())));
		} else if (t === "source") n.source = I(i(r()));
		else return !1;
		return !0;
	}, {
		construct: "process_model",
		id: e
	}), (t) => (t.processModels[e] = n, t);
};
function Et(e) {
	return e.length === 0 ? "" : "sequence { " + e.map(N).join(" ") + " }";
}
function Dt(e, t) {
	let n = t + "register " + N(e.id) + " {\n";
	return e.label && (n += t + "  label \"" + s(e.label) + "\"\n"), e.clause && (n += t + "  clause \"" + s(e.clause) + "\"\n"), e.maintainer && (n += t + "  maintainer " + N(e.maintainer) + "\n"), e.published && (n += t + "  published \"" + s(e.published) + "\"\n"), e.entries && (n += t + "  entries \"" + s(e.entries) + "\"\n"), n += t + "}\n", n;
}
var Ot = function(e) {
	let t = "process_model " + e.id + " {\n", n = Et(e.sequence);
	n && (t += "  " + n + "\n");
	for (let n of e.registers) t += Dt(n, "  ");
	return (e.source.doc || e.source.clause) && (t += "  source {\n", e.source.doc && (t += "    doc \"" + s(e.source.doc) + "\"\n"), e.source.clause && (t += "    clause \"" + s(e.source.clause) + "\"\n"), t += "  }\n"), t += "}\n", t;
}, kt = [
	"intake",
	"dispatch",
	"testing",
	"evaluation",
	"issuance"
];
function At(e) {
	return n(a(e)).map(P).map(a).filter((e) => e.length > 0);
}
function jt(e, t, n) {
	return t.length === 0 ? "" : n + e + " { " + t.map(N).join(" ") + " }\n";
}
var Mt = (e, t) => {
	let n = {
		id: e,
		overlay: !1,
		steps: []
	};
	return v(t, (t, r) => {
		if (t === "overlay") n.overlay = r() === "true";
		else if (t === "step") {
			let t = {
				id: a(P(r())),
				phase: null,
				actor: null,
				label: null,
				description: null,
				inputs: [],
				outputs: [],
				gates: []
			};
			v(i(r()), (n, r) => {
				if (n === "phase") {
					let n = a(r());
					if (!kt.includes(n)) throw Error(`Parsing error: workflow_config. ID ${e}: Unknown phase "${n}" (valid: ${kt.join(", ")})`);
					t.phase = n;
				} else if (n === "actor") t.actor = a(r());
				else if (n === "label") t.label = a(r());
				else if (n === "description") t.description = a(r());
				else if (n === "inputs") t.inputs = At(r());
				else if (n === "outputs") t.outputs = At(r());
				else if (n === "gates") t.gates = At(r());
				else return !1;
				return !0;
			}, {
				construct: "workflow_config",
				id: e
			}), n.steps.push(t);
		} else return !1;
		return !0;
	}, {
		construct: "workflow_config",
		id: e
	}), (t) => (t.workflowConfigs[e] = n, t);
}, Nt = function(e) {
	let t = "workflow_config " + N(e.id) + " {\n";
	e.overlay && (t += "  overlay true\n");
	for (let n of e.steps) t += "  step " + N(n.id) + " {\n", n.phase && (t += "    phase " + n.phase + "\n"), n.actor && (t += "    actor " + N(n.actor) + "\n"), n.label && (t += "    label \"" + s(n.label) + "\"\n"), n.description && (t += "    description \"" + s(n.description) + "\"\n"), t += jt("inputs", n.inputs, "    "), t += jt("outputs", n.outputs, "    "), n.gates.length > 0 && (t += "    gates { " + n.gates.map((e) => "\"" + s(e) + "\"").join(" ") + " }\n"), t += "  }\n";
	return t += "}\n", t;
};
//#endregion
//#region src/ser-des/config/workflowStage.ts
function Pt(e) {
	return n(a(e)).map(P).map(a).filter((e) => e.length > 0);
}
function Ft(e, t) {
	return t.length === 0 ? "" : "  " + e + " { " + t.map(N).join(" ") + " }\n";
}
var It = (e, t) => {
	let n = {
		id: e,
		label: "",
		description: "",
		elements: [],
		startEvent: "",
		endEvents: [],
		approvals: [],
		gateways: []
	};
	return v(t, (e, t) => {
		if (e === "label") n.label = a(t());
		else if (e === "description") n.description = a(t());
		else if (e === "elements") n.elements = Pt(t());
		else if (e === "start_event") n.startEvent = a(t());
		else if (e === "end_events") n.endEvents = Pt(t());
		else if (e === "approvals") n.approvals = Pt(t());
		else if (e === "gateways") n.gateways = Pt(t());
		else return !1;
		return !0;
	}, {
		construct: "workflow_stage",
		id: e
	}), (t) => (t.workflowStages[e] = n, t);
}, Lt = function(e) {
	let t = "workflow_stage " + N(e.id) + " {\n";
	return e.label && (t += "  label \"" + s(e.label) + "\"\n"), e.description && (t += "  description \"" + s(e.description) + "\"\n"), t += Ft("elements", e.elements), e.startEvent && (t += "  start_event " + N(e.startEvent) + "\n"), t += Ft("end_events", e.endEvents), t += Ft("approvals", e.approvals), t += Ft("gateways", e.gateways), t += "}\n", t;
}, Rt = [
	"initial",
	"subsequent",
	"periodic",
	"in-service"
], zt = ["timer", "signal"], Bt = ["same-as-type-evaluation", "override"];
function Vt(e) {
	return n(a(e)).map(P).map(a).filter((e) => e.length > 0);
}
function Ht(e) {
	let t = {
		years: 0,
		months: 0
	}, r = n(i(e));
	for (let e = 0; e + 1 < r.length; e += 2) r[e] === "years" ? t.years = parseInt(a(r[e + 1]), 10) || 0 : r[e] === "months" && (t.months = parseInt(a(r[e + 1]), 10) || 0);
	return t;
}
function Ut(e, t) {
	let n = t + "window {";
	return e.years > 0 && (n += " years " + e.years), e.months > 0 && (n += " months " + e.months), n + " }\n";
}
function Wt(e, t) {
	if (!e.doc && !e.clause) return "";
	let n = t + "source {\n";
	return e.doc && (n += t + "  doc \"" + s(e.doc) + "\"\n"), e.clause && (n += t + "  clause \"" + s(e.clause) + "\"\n"), n + t + "}\n";
}
var Gt = (e, t) => {
	let n = {
		id: e,
		kind: "",
		label: "",
		description: "",
		visualInspection: "",
		tests: [],
		assessment: null,
		limits: null,
		marking: null,
		validity: null,
		source: null
	};
	return v(t, (t, r) => {
		if (t === "kind") {
			let t = a(r());
			if (!Rt.includes(t)) throw Error(`Parsing error: verification_pathway. ID ${e}: Unknown kind "${t}" (valid: ${Rt.join(", ")})`);
			n.kind = t;
		} else if (t === "label") n.label = a(r());
		else if (t === "description") n.description = a(r());
		else if (t === "visual_inspection") n.visualInspection = a(r());
		else if (t === "tests") n.tests = Vt(r());
		else if (t === "assessment") {
			let t = {
				covers: [],
				description: ""
			};
			v(i(r()), (e, n) => {
				if (e === "covers") t.covers = Vt(n());
				else if (e === "description") t.description = a(n());
				else return !1;
				return !0;
			}, {
				construct: "verification_pathway assessment",
				id: e
			}), n.assessment = t;
		} else if (t === "limits") {
			let t = {
				mode: "",
				description: "",
				source: null
			};
			v(i(r()), (n, r) => {
				if (n === "mode") {
					let n = a(r());
					if (!Bt.includes(n)) throw Error(`Parsing error: verification_pathway. ID ${e}: Unknown limits mode "${n}" (valid: ${Bt.join(", ")})`);
					t.mode = n;
				} else if (n === "description") t.description = a(r());
				else if (n === "source") t.source = I(i(r()));
				else return !1;
				return !0;
			}, {
				construct: "verification_pathway limits",
				id: e
			}), n.limits = t;
		} else if (t === "marking") {
			let t = {
				marks: [],
				securing: []
			};
			v(i(r()), (n, r) => {
				if (n === "mark") {
					let n = {
						id: a(P(r())),
						mark: "",
						location: "",
						clause: ""
					};
					v(i(r()), (e, t) => {
						if (e === "mark") n.mark = a(t());
						else if (e === "location") n.location = a(t());
						else if (e === "clause") n.clause = a(t());
						else return !1;
						return !0;
					}, {
						construct: "verification_pathway marking mark",
						id: e
					}), t.marks.push(n);
				} else if (n === "securing") t.securing = Vt(r());
				else return !1;
				return !0;
			}, {
				construct: "verification_pathway marking",
				id: e
			}), n.marking = t;
		} else if (t === "validity") {
			let t = {
				window: null,
				triggers: []
			};
			v(i(r()), (n, r) => {
				if (n === "window") t.window = Ht(r());
				else if (n === "trigger") {
					let n = {
						id: a(P(r())),
						kind: "",
						event: "",
						action: "",
						applicability: [],
						description: "",
						source: null
					};
					v(i(r()), (t, r) => {
						if (t === "kind") {
							let t = a(r());
							if (!zt.includes(t)) throw Error(`Parsing error: verification_pathway. ID ${e}: Unknown trigger kind "${t}" (valid: ${zt.join(", ")})`);
							n.kind = t;
						} else if (t === "event") n.event = a(r());
						else if (t === "action") n.action = a(r());
						else if (t === "applicability") n.applicability = L(i(r()));
						else if (t === "description") n.description = a(r());
						else if (t === "source") n.source = I(i(r()));
						else return !1;
						return !0;
					}, {
						construct: "verification_pathway validity trigger",
						id: e
					}), t.triggers.push(n);
				} else return !1;
				return !0;
			}, {
				construct: "verification_pathway validity",
				id: e
			}), n.validity = t;
		} else if (t === "source") n.source = I(i(r()));
		else return !1;
		return !0;
	}, {
		construct: "verification_pathway",
		id: e
	}), (t) => (t.verificationPathways[e] = n, t);
}, Kt = function(e) {
	let t = "verification_pathway " + N(e.id) + " {\n";
	if (e.kind && (t += "  kind " + e.kind + "\n"), e.label && (t += "  label \"" + s(e.label) + "\"\n"), e.description && (t += "  description \"" + s(e.description) + "\"\n"), e.visualInspection && (t += "  visual_inspection \"" + s(e.visualInspection) + "\"\n"), e.tests.length > 0 && (t += "  tests { " + e.tests.map(N).join(" ") + " }\n"), e.assessment && (t += "  assessment {\n", e.assessment.covers.length > 0 && (t += "    covers { " + e.assessment.covers.map(N).join(" ") + " }\n"), e.assessment.description && (t += "    description \"" + s(e.assessment.description) + "\"\n"), t += "  }\n"), e.limits && (t += "  limits {\n", e.limits.mode && (t += "    mode " + e.limits.mode + "\n"), e.limits.description && (t += "    description \"" + s(e.limits.description) + "\"\n"), e.limits.source && (t += Wt(e.limits.source, "    ")), t += "  }\n"), e.marking) {
		t += "  marking {\n";
		for (let n of e.marking.marks) {
			let e = "    mark " + N(n.id) + " { mark \"" + s(n.mark) + "\"";
			n.location && (e += " location \"" + s(n.location) + "\""), n.clause && (e += " clause \"" + s(n.clause) + "\""), t += e + " }\n";
		}
		e.marking.securing.length > 0 && (t += "    securing { " + e.marking.securing.map((e) => "\"" + s(e) + "\"").join(" ") + " }\n"), t += "  }\n";
	}
	if (e.validity) {
		t += "  validity {\n", e.validity.window && (t += Ut(e.validity.window, "    "));
		for (let n of e.validity.triggers) t += "    trigger " + N(n.id) + " {\n", n.kind && (t += "      kind " + n.kind + "\n"), n.event && (t += "      event " + N(n.event) + "\n"), n.action && (t += "      action " + N(n.action) + "\n"), n.applicability.length > 0 && (t += "      applicability { " + R(n.applicability).trimEnd() + " }\n"), n.description && (t += "      description \"" + s(n.description) + "\"\n"), n.source && (t += Wt(n.source, "      ")), t += "    }\n";
		t += "  }\n";
	}
	return e.source && (t += Wt(e.source, "  ")), t += "}\n", t;
}, qt = ["required", "preferred"], Jt = [
	"dimension",
	"parameter",
	"operational"
], Yt = [
	"has_capability",
	"capability_from_field",
	"capability_covers_value",
	"capability_prefix_match",
	"always_pass"
], Xt = [
	"full_evaluation",
	"partial_evaluation",
	"deduplicate",
	"humidity",
	"digital_additional"
];
function Zt(e) {
	let t = {}, r = n(i(e));
	for (let e = 0; e + 1 < r.length; e += 2) {
		let n = a(P(r[e]));
		n && (t[n] = a(r[e + 1]));
	}
	return t;
}
var Qt = (e, t) => {
	let r = {
		id: e,
		weight: "",
		parameterType: "",
		label: "",
		description: "",
		appliesWhen: null,
		match: null
	};
	return v(t, (t, o) => {
		if (t === "weight") {
			let t = a(o());
			if (!qt.includes(t)) throw Error(`Parsing error: lab_selection_criterion. ID ${e}: Unknown weight "${t}" (valid: ${qt.join(", ")})`);
			r.weight = t;
		} else if (t === "parameter_type") {
			let t = a(o());
			if (!Jt.includes(t)) throw Error(`Parsing error: lab_selection_criterion. ID ${e}: Unknown parameter_type "${t}" (valid: ${Jt.join(", ")})`);
			r.parameterType = t;
		} else if (t === "label") r.label = a(o());
		else if (t === "description") r.description = a(o());
		else if (t === "applies_when") {
			let t = {
				modelField: "",
				in: [],
				equals: "",
				notNull: null
			};
			v(i(o()), (e, r) => {
				if (e === "model_field") t.modelField = a(r());
				else if (e === "in") t.in = n(a(r())).map(P).map(a).filter((e) => e.length > 0);
				else if (e === "equals") t.equals = a(r());
				else if (e === "not_null") t.notNull = r() === "true";
				else return !1;
				return !0;
			}, {
				construct: "lab_selection_criterion applies_when",
				id: e
			}), r.appliesWhen = t;
		} else if (t === "match") {
			let t = {
				operator: "",
				requiredCapability: "",
				requiredCapabilityPrefix: "",
				modelField: "",
				labCapabilityPrefix: ""
			};
			v(i(o()), (n, r) => {
				if (n === "operator") {
					let n = a(r());
					if (!Yt.includes(n)) throw Error(`Parsing error: lab_selection_criterion. ID ${e}: Unknown match operator "${n}" (valid: ${Yt.join(", ")})`);
					t.operator = n;
				} else if (n === "required_capability") t.requiredCapability = a(r());
				else if (n === "required_capability_prefix") t.requiredCapabilityPrefix = a(r());
				else if (n === "model_field") t.modelField = a(r());
				else if (n === "lab_capability_prefix") t.labCapabilityPrefix = a(r());
				else return !1;
				return !0;
			}, {
				construct: "lab_selection_criterion match",
				id: e
			}), r.match = t;
		} else return !1;
		return !0;
	}, {
		construct: "lab_selection_criterion",
		id: e
	}), (t) => (t.labSelectionCriteria[e] = r, t);
}, $t = function(e) {
	let t = "lab_selection_criterion " + N(e.id) + " {\n";
	if (e.weight && (t += "  weight " + e.weight + "\n"), e.parameterType && (t += "  parameter_type " + e.parameterType + "\n"), e.label && (t += "  label \"" + s(e.label) + "\"\n"), e.description && (t += "  description \"" + s(e.description) + "\"\n"), e.appliesWhen) {
		let n = "  applies_when { model_field " + N(e.appliesWhen.modelField);
		e.appliesWhen.in.length > 0 && (n += " in { " + e.appliesWhen.in.map(N).join(" ") + " }"), e.appliesWhen.equals && (n += " equals " + N(e.appliesWhen.equals)), e.appliesWhen.notNull !== null && (n += " not_null " + (e.appliesWhen.notNull ? "true" : "false")), t += n + " }\n";
	}
	return e.match && (t += "  match {\n", e.match.operator && (t += "    operator " + e.match.operator + "\n"), e.match.requiredCapability && (t += "    required_capability \"" + s(e.match.requiredCapability) + "\"\n"), e.match.requiredCapabilityPrefix && (t += "    required_capability_prefix \"" + s(e.match.requiredCapabilityPrefix) + "\"\n"), e.match.modelField && (t += "    model_field " + N(e.match.modelField) + "\n"), e.match.labCapabilityPrefix && (t += "    lab_capability_prefix \"" + s(e.match.labCapabilityPrefix) + "\"\n"), t += "  }\n"), t += "}\n", t;
}, en = (e, t) => {
	let n = {
		id: e,
		step: "",
		rule: "",
		rationale: "",
		applicability: "",
		selector: "",
		testKind: "",
		singleSample: null,
		additionalTests: {},
		post: ""
	};
	return v(t, (t, r) => {
		if (t === "step") n.step = a(r());
		else if (t === "rule") n.rule = a(r());
		else if (t === "rationale") n.rationale = a(r());
		else if (t === "applicability") n.applicability = a(r());
		else if (t === "selector") n.selector = a(r());
		else if (t === "test_kind") {
			let t = a(r());
			if (!Xt.includes(t)) throw Error(`Parsing error: sample_selection_rule. ID ${e}: Unknown test_kind "${t}" (valid: ${Xt.join(", ")})`);
			n.testKind = t;
		} else if (t === "single_sample") n.singleSample = r() === "true";
		else if (t === "additional_tests") n.additionalTests = Zt(r());
		else if (t === "post") n.post = a(r());
		else return !1;
		return !0;
	}, {
		construct: "sample_selection_rule",
		id: e
	}), (t) => (t.sampleSelectionRules[e] = n, t);
}, tn = function(e) {
	let t = "sample_selection_rule " + N(e.id) + " {\n";
	e.step && (t += "  step \"" + s(e.step) + "\"\n"), e.rule && (t += "  rule \"" + s(e.rule) + "\"\n"), e.rationale && (t += "  rationale \"" + s(e.rationale) + "\"\n"), e.applicability && (t += "  applicability \"" + s(e.applicability) + "\"\n"), e.selector && (t += "  selector \"" + s(e.selector) + "\"\n"), e.testKind && (t += "  test_kind " + e.testKind + "\n"), e.singleSample !== null && (t += "  single_sample " + (e.singleSample ? "true" : "false") + "\n");
	let n = Object.keys(e.additionalTests);
	return n.length > 0 && (t += "  additional_tests { " + n.map((t) => N(t) + " \"" + s(e.additionalTests[t]) + "\"").join(" ") + " }\n"), e.post && (t += "  post \"" + s(e.post) + "\"\n"), t += "}\n", t;
}, nn = (e, t) => {
	let n = {
		id: e,
		rule: "",
		rationale: "",
		applicability: "",
		constraint: "",
		post: ""
	};
	return v(t, (e, t) => {
		if (e === "rule") n.rule = a(t());
		else if (e === "rationale") n.rationale = a(t());
		else if (e === "applicability") n.applicability = a(t());
		else if (e === "constraint") n.constraint = a(t());
		else if (e === "post") n.post = a(t());
		else return !1;
		return !0;
	}, {
		construct: "specimen_governance_rule",
		id: e
	}), (t) => (t.specimenGovernanceRules[e] = n, t);
}, rn = function(e) {
	let t = "specimen_governance_rule " + N(e.id) + " {\n";
	return e.rule && (t += "  rule \"" + s(e.rule) + "\"\n"), e.rationale && (t += "  rationale \"" + s(e.rationale) + "\"\n"), e.applicability && (t += "  applicability \"" + s(e.applicability) + "\"\n"), e.constraint && (t += "  constraint \"" + s(e.constraint) + "\"\n"), e.post && (t += "  post \"" + s(e.post) + "\"\n"), t += "}\n", t;
}, an = ["always", "conditional"], on = ["shall", "may"];
function sn(e, t, n) {
	let r = {
		id: e,
		file: "",
		title: "",
		conformanceTest: "",
		requirements: [],
		required: "",
		applicability: [],
		notes: ""
	};
	return v(t, (e, t) => {
		if (e === "file") r.file = a(t());
		else if (e === "title") r.title = a(t());
		else if (e === "conformance_test") r.conformanceTest = a(t());
		else if (e === "requirements") r.requirements = cn(t());
		else if (e === "required") {
			let e = a(t());
			if (!an.includes(e)) throw Error(`Parsing error: test_report_skeleton. ID ${n}: Unknown required "${e}" (valid: ${an.join(", ")})`);
			r.required = e;
		} else if (e === "applicability") r.applicability = L(i(t()));
		else if (e === "notes") r.notes = a(t());
		else return !1;
		return !0;
	}, {
		construct: "test_report_skeleton form",
		id: n
	}), r;
}
function cn(e) {
	return n(a(e)).map(P).map(a).filter((e) => e.length > 0);
}
function ln(e, t) {
	let n = t + "form " + N(e.id) + " {\n";
	return e.file && (n += t + "  file \"" + s(e.file) + "\"\n"), e.title && (n += t + "  title \"" + s(e.title) + "\"\n"), e.conformanceTest && (n += t + "  conformance_test " + N(e.conformanceTest) + "\n"), e.requirements.length > 0 && (n += t + "  requirements { " + e.requirements.map(N).join(" ") + " }\n"), e.required && (n += t + "  required " + e.required + "\n"), e.applicability.length > 0 && (n += t + "  applicability { " + R(e.applicability).trimEnd() + " }\n"), e.notes && (n += t + "  notes \"" + s(e.notes) + "\"\n"), n += t + "}\n", n;
}
var un = (e, t) => {
	let n = {
		id: e,
		title: "",
		description: "",
		note: "",
		sections: []
	};
	return v(t, (t, r) => {
		if (t === "title") n.title = a(r());
		else if (t === "description") n.description = a(r());
		else if (t === "note") n.note = a(r());
		else if (t === "section") {
			let t = {
				id: a(P(r())),
				title: "",
				description: "",
				forms: [],
				subsections: []
			};
			v(i(r()), (n, r) => {
				if (n === "title") t.title = a(r());
				else if (n === "description") t.description = a(r());
				else if (n === "form") t.forms.push(sn(a(P(r())), i(r()), e));
				else if (n === "subsection") {
					let n = {
						title: a(r()),
						description: "",
						applicability: [],
						forms: []
					};
					v(i(r()), (t, r) => {
						if (t === "description") n.description = a(r());
						else if (t === "applicability") n.applicability = L(i(r()));
						else if (t === "form") n.forms.push(sn(a(P(r())), i(r()), e));
						else return !1;
						return !0;
					}, {
						construct: "test_report_skeleton subsection",
						id: e
					}), t.subsections.push(n);
				} else return !1;
				return !0;
			}, {
				construct: "test_report_skeleton section",
				id: e
			}), n.sections.push(t);
		} else return !1;
		return !0;
	}, {
		construct: "test_report_skeleton",
		id: e
	}), (t) => (t.testReportSkeletons[e] = n, t);
}, dn = function(e) {
	let t = "test_report_skeleton " + N(e.id) + " {\n";
	e.title && (t += "  title \"" + s(e.title) + "\"\n"), e.description && (t += "  description \"" + s(e.description) + "\"\n"), e.note && (t += "  note \"" + s(e.note) + "\"\n");
	for (let n of e.sections) {
		t += "  section " + N(n.id) + " {\n", n.title && (t += "    title \"" + s(n.title) + "\"\n"), n.description && (t += "    description \"" + s(n.description) + "\"\n");
		for (let e of n.forms) t += ln(e, "    ");
		for (let e of n.subsections) {
			t += "    subsection \"" + s(e.title) + "\" {\n", e.description && (t += "      description \"" + s(e.description) + "\"\n"), e.applicability.length > 0 && (t += "      applicability { " + R(e.applicability).trimEnd() + " }\n");
			for (let n of e.forms) t += ln(n, "      ");
			t += "    }\n";
		}
		t += "  }\n";
	}
	return t += "}\n", t;
}, fn = (e, t) => {
	let n = {
		id: e,
		overlay: !1,
		entries: []
	};
	return v(t, (t, r) => {
		if (t === "overlay") n.overlay = r() === "true";
		else if (t === "entry") {
			let t = {
				id: a(P(r())),
				element: null,
				description: null,
				obligation: null,
				descriptionNote: null,
				source: null,
				validation: null
			};
			v(i(r()), (n, r) => {
				if (n === "element") t.element = a(r());
				else if (n === "description") t.description = a(r());
				else if (n === "obligation") {
					let n = a(r());
					if (!on.includes(n)) throw Error(`Parsing error: test_report_checklist. ID ${e}: Unknown obligation "${n}" (valid: ${on.join(", ")})`);
					t.obligation = n;
				} else if (n === "description_note") t.descriptionNote = a(r());
				else if (n === "source") t.source = a(r());
				else if (n === "validation") t.validation = a(r());
				else return !1;
				return !0;
			}, {
				construct: "test_report_checklist entry",
				id: e
			}), n.entries.push(t);
		} else return !1;
		return !0;
	}, {
		construct: "test_report_checklist",
		id: e
	}), (t) => (t.testReportChecklists[e] = n, t);
}, pn = function(e) {
	let t = "test_report_checklist " + N(e.id) + " {\n";
	e.overlay && (t += "  overlay true\n");
	for (let n of e.entries) t += "  entry " + N(n.id) + " {\n", n.element !== null && (t += "    element \"" + s(n.element) + "\"\n"), n.description !== null && (t += "    description \"" + s(n.description) + "\"\n"), n.obligation !== null && (t += "    obligation " + n.obligation + "\n"), n.descriptionNote !== null && (t += "    description_note \"" + s(n.descriptionNote) + "\"\n"), n.source !== null && (t += "    source \"" + s(n.source) + "\"\n"), n.validation !== null && (t += "    validation \"" + s(n.validation) + "\"\n"), t += "  }\n";
	return t += "}\n", t;
}, mn = function(e, t) {
	let n = {
		subject: /* @__PURE__ */ new Map(),
		id: e,
		modality: "",
		condition: "",
		ref: [],
		_relations: { ref: [] }
	};
	return v(t, (e, t) => (e === "modality" ? n.modality = t() : e === "condition" ? n.condition = x(t) : e === "reference" ? n._relations.ref = r(t()) : n.subject.set(e, t()), !0), {
		construct: "provision",
		id: e
	}), (t) => (t.provisions[e] = n, t);
}, hn = function(e, t) {
	let n = [];
	for (let r of t._relations.ref) {
		let t = f(e, "references", r);
		t !== void 0 && n.push(t);
	}
	return {
		...t,
		ref: n
	};
}, gn = function(e) {
	let t = "provision " + e.id + " {\n";
	if (e.subject.forEach((e, n) => {
		t += "  " + n + " " + e + "\n";
	}), t += "  condition \"" + s(e.condition) + "\"\n", e.modality !== "" && (t += "  modality " + e.modality + "\n"), e.ref.length > 0) {
		t += "  reference {\n";
		for (let n of e.ref) t += "    " + n.id + "\n";
		t += "  }\n";
	}
	return t += "}\n", t;
}, _n = (e, t) => {
	let n = {
		id: e,
		document: "",
		clause: ""
	};
	if (t !== "") {
		let a = r(t), o = 0;
		for (; o < a.length;) {
			let t = a[o++];
			if (o < a.length) t === "document" ? n.document = i(a[o++]) : t === "clause" ? n.clause = i(a[o++]) : t === "title" ? n.title = i(a[o++]) : t === "org" ? n.org = i(a[o++]) : t === "edition" ? n.edition = i(a[o++]) : t === "urn" ? n.urn = i(a[o++]) : o++;
			else throw Error(`Parsing error: reference. ID ${e}: Expecting value for ${t}`);
		}
	}
	return (t) => (t.references[e] = n, t);
}, vn = function(e) {
	let t = "reference " + e.id + " {\n";
	return t += "  document \"" + s(e.document) + "\"\n", t += "  clause \"" + s(e.clause) + "\"\n", e.title && (t += "  title \"" + s(e.title) + "\"\n"), e.org && (t += "  org \"" + s(e.org) + "\"\n"), e.edition && (t += "  edition \"" + s(e.edition) + "\"\n"), e.urn && (t += "  urn \"" + s(e.urn) + "\"\n"), t += "}\n", t;
}, yn = (e, t) => {
	let n = {
		id: e,
		name: ""
	};
	return v(t, (e, t) => {
		if (e === "name") n.name = x(t);
		else if (e === "label") n.label = x(t);
		else if (e === "description") n.description = x(t);
		else return !1;
		return !0;
	}, {
		construct: "role",
		id: e
	}), (t) => (t.roles[e] = n, t);
}, bn = function(e) {
	let t = "role " + e.id + " {\n";
	return t += "  name \"" + s(e.name) + "\"\n", e.label && (t += "  label \"" + s(e.label) + "\"\n"), e.description && (t += "  description \"" + s(e.description) + "\"\n"), t += "}\n", t;
}, xn = function(e, t) {
	let n = {
		id: e,
		childs: [],
		edges: [],
		data: [],
		_relations: {
			childs: [],
			edges: [],
			data: []
		},
		_components: {}
	};
	if (t !== "") {
		let a = r(t), o = 0;
		for (; o < a.length;) {
			let t = a[o++];
			if (o < a.length) t === "elements" ? n = Sn(i(a[o++]))(n) : t === "process_flow" ? n = wn(i(a[o++]))(n) : t === "data" ? n = Cn(i(a[o++]))(n) : o++;
			else throw Error(`Parsing error: subprocess. ID ${e}: Expecting value for ${t}`);
		}
	}
	return (t) => (t.pages[e] = n, t);
}, Sn = function(e) {
	let t = r(e), n = {}, i = 0;
	for (; i < t.length;) {
		let e = t[i++];
		if (i < t.length) {
			let r = e.trim();
			n[r] = Tn(r, t[i++]);
		} else throw Error(`Parsing error: elements in subprocess. Expecting value for ${e}`);
	}
	return (e) => ({
		...e,
		_components: {
			...e._components,
			...n
		},
		_relations: {
			...e._relations,
			childs: Object.values(n)
		}
	});
}, Cn = function(e) {
	let t = r(e), n = {}, i = 0;
	for (; i < t.length;) {
		let e = t[i++];
		if (i < t.length) {
			let r = e.trim();
			n[r] = Tn(r, t[i++]);
		} else throw Error(`Parsing error: data in subprocess. Expecting value for ${e}`);
	}
	return (e) => ({
		...e,
		_components: {
			...e._components,
			...n
		},
		_relations: {
			...e._relations,
			data: Object.values(n)
		}
	});
}, wn = function(e) {
	let t = r(e), n = {}, i = 0;
	for (; i < t.length;) {
		let e = t[i++].trim();
		if (i < t.length) n[e] = En(e.trim(), t[i++]);
		else throw Error(`Parsing error: edges in subprocess. Expecting value for ${e}`);
	}
	return (e) => ({
		...e,
		_relations: {
			...e._relations,
			edges: Object.values(n)
		}
	});
};
function Tn(e, t) {
	let n = {
		name: e,
		element: null,
		x: 0,
		y: 0,
		_relations: { element: e }
	}, i = r(t), a = 0;
	for (; a < i.length;) {
		let t = i[a++];
		if (a < i.length) t === "x" ? n.x = parseFloat(i[a++]) : t === "y" ? n.y = parseFloat(i[a++]) : a++;
		else throw Error(`Parsing error: subprocess component. Element ${e}: Expecting value for ${t}`);
	}
	return n;
}
function En(e, t) {
	let n = {
		id: e,
		from: null,
		to: null,
		description: "",
		condition: "",
		_relations: {
			from: "",
			to: ""
		}
	}, a = r(t), o = 0;
	for (; o < a.length;) {
		let t = a[o++];
		if (o < a.length) t === "from" ? n._relations.from = a[o++] : t === "description" ? n.description = i(a[o++]) : t === "condition" ? n.condition = i(a[o++]) : t === "to" ? n._relations.to = a[o++] : o++;
		else throw Error(`Parsing error: process_flow. ID ${e}: Expecting value for ${t}`);
	}
	return n;
}
var Dn = function(e, t) {
	let n = t._relations ?? {
		childs: [],
		edges: [],
		data: []
	}, r = t._components ?? {}, i = /* @__PURE__ */ new Map();
	for (let e of Object.values(r)) e._relations?.element && i.set(e._relations.element, e);
	let a = (t) => ({
		name: t.name,
		x: t.x,
		y: t.y,
		element: On(e, t._relations.element)
	});
	return {
		id: t.id,
		childs: n.childs.map(a),
		edges: n.edges.map((e) => {
			let t = e._relations.from ? i.get(e._relations.from) : void 0, n = e._relations.to ? i.get(e._relations.to) : void 0;
			return {
				id: e.id,
				description: e.description,
				condition: e.condition,
				from: t ? a(t) : null,
				to: n ? a(n) : null
			};
		}),
		data: n.data.map(a)
	};
};
function On(e, t) {
	return f(e, "processes", t) ?? f(e, "approvals", t) ?? f(e, "events", t) ?? f(e, "gateways", t) ?? null;
}
var kn = function(e) {
	let t = "canvas " + e.id + " {\n";
	return t += "  elements {\n", e.childs.forEach((e) => {
		t += An(e);
	}), t += "  }\n", t += "  process_flow {\n", e.edges.forEach((e) => {
		t += jn(e);
	}), t += "  }\n", t += "  data {\n", e.data.forEach((e) => {
		t += An(e);
	}), t += "  }\n", t += "}\n", t;
};
function An(e) {
	let t = "    " + (e.element?.id ?? e.name) + " {\n";
	return t += "      x " + e.x + "\n", t += "      y " + e.y + "\n", t += "    }\n", t;
}
function jn(e) {
	let t = "    " + e.id + " {\n";
	return e.from !== null && e.from.element !== null && (t += "      from " + e.from.element.id + "\n"), e.to !== null && e.to.element !== null && (t += "      to " + e.to.element.id + "\n"), e.description !== "" && (t += "      description \"" + s(e.description) + "\"\n"), e.condition !== "" && (t += "      condition \"" + s(e.condition) + "\"\n"), t += "    }\n", t;
}
//#endregion
//#region src/ser-des/config/note.ts
var Mn = [
	"NOTE",
	"CAUTION",
	"WARNING",
	"EXAMPLE",
	"COMMENTARY"
], Nn = function(e, t) {
	let n = {
		id: e,
		type: "NOTE",
		message: "",
		sourceDiscrepancy: null,
		source: null,
		ref: [],
		_relations: { ref: [] }
	};
	return v(t, (t, o, s) => {
		if (t === "type") {
			let t = o();
			if (!Mn.includes(t)) throw Error(`Parsing error: note. ID ${e}: Unknown type ${t} (valid: ${Mn.join(", ")})`);
			n.type = t;
		} else if (t === "message") n.message = x(o);
		else if (t === "source_discrepancy") n.sourceDiscrepancy = A(i(o()));
		else if (t === "source") {
			let e = I(i(o()));
			n.source ||= e, (n.sourceRefs ??= []).push(e);
		} else if (t === "reference") n._relations.ref = r(o());
		else if (t === "ref") {
			let e = C(o, s, a, i);
			T(n, e);
		} else return !1;
		return !0;
	}, {
		construct: "note",
		id: e
	}), (t) => (t.notes[e] = n, t);
}, Pn = function(e, t) {
	let n = [];
	for (let r of t._relations.ref) {
		let t = f(e, "references", r);
		t !== void 0 && n.push(t);
	}
	return {
		...t,
		ref: n
	};
}, Fn = function(e) {
	let t = "note " + e.id + " {\n";
	t += "  type " + e.type + "\n", t += "  message \"" + s(e.message) + "\"\n", e.sourceDiscrepancy && (t += j(e.sourceDiscrepancy, "  ") + "\n");
	for (let n of e.sourceRefs ?? (e.source && (e.source.doc || e.source.clause) ? [e.source] : [])) t += E(n, "  ", s);
	if (e.ref.length > 0) {
		t += "  reference {\n";
		for (let n of e.ref) t += "    " + n.id + "\n";
		t += "  }\n";
	}
	return t += "}\n", t;
};
//#endregion
//#region src/ser-des/config/table.ts
function In(e) {
	return e.trim() !== "" && !isNaN(Number(e)) ? Number(e) : e;
}
function Ln(e) {
	let t = [], r = n(e), i = 0;
	for (; i < r.length;) {
		let e = P(r[i++]);
		if (!e) break;
		i < r.length && r[i] === ":" && i++;
		let n = i < r.length ? a(r[i++]) : "", o = "";
		i < r.length && r[i].startsWith("\"") && (o = a(r[i++])), t.push({
			name: e,
			type: n,
			unit: o
		});
	}
	return t;
}
function Rn(e) {
	let t = {}, r = n(e), i = 0;
	for (; i < r.length;) {
		let e = P(r[i++]);
		if (!e) break;
		i < r.length && r[i] === ":" && i++, i < r.length && (t[e] = In(a(r[i++])));
	}
	return t;
}
function zn(e) {
	let t = {}, r = n(e), o = 0;
	for (; o < r.length;) {
		let e = P(r[o++]);
		if (!e || (o < r.length && r[o] === ":" && o++, o >= r.length)) break;
		if (r[o].startsWith("[")) {
			let a = oe(r, o);
			o = a.next;
			let s = a.text.trim().slice(1, a.text.lastIndexOf("]")), c = [];
			for (let e of n(s)) e.startsWith("{") && c.push(Rn(i(e)));
			t[e] = c;
		} else t[e] = r[o].startsWith("{") ? Rn(i(r[o++])) : In(a(r[o++]));
	}
	return t;
}
function Bn(e, t) {
	let r = {
		name: e,
		description: "",
		dimension: "",
		unit: "",
		type: "",
		sourceDiscrepancy: null,
		binding: {}
	}, o = n(t), s = 0;
	for (; s < o.length;) {
		let e = o[s++];
		if (s >= o.length) break;
		e === "description" ? r.description = a(o[s++]) : e === "dimension" ? r.dimension = a(o[s++]) : e === "unit" ? r.unit = a(o[s++]) : e === "type" ? r.type = a(o[s++]) : e === "source_discrepancy" ? r.sourceDiscrepancy = A(i(o[s++])) : e === "binding" ? r.binding = zn(i(o[s++])) : i(o[s++]);
	}
	return r;
}
function Vn(e) {
	let t = {}, r = n(e), o = 0;
	for (; o < r.length;) {
		let e = P(r[o++]);
		if (!e) break;
		if (o < r.length && r[o] === ":" && o++, o < r.length && r[o].startsWith("{")) {
			let s = n(i(r[o++])), c = {}, l = 0;
			for (; l < s.length;) {
				let e = P(s[l++]);
				if (!e) break;
				l < s.length && s[l] === ":" && l++, l < s.length && s[l].startsWith("{") ? c[e] = i(s[l++]).trim() : l < s.length && (c[e] = a(s[l++]));
			}
			t[e] = c;
		}
	}
	return t;
}
function Hn(e) {
	let t = {}, r = n(e), o = 0;
	for (; o < r.length;) {
		let e = P(r[o++]);
		if (!e) break;
		if (o < r.length && r[o] === ":" && o++, o < r.length && r[o].startsWith("{")) {
			let s = n(i(r[o++])), c = {
				condition: "",
				by: ""
			}, l = 0;
			for (; l < s.length;) {
				let e = s[l++];
				if (l >= s.length) break;
				e === "condition" ? c.condition = a(s[l++]) : e === "by" ? c.by = a(s[l++]) : i(s[l++]);
			}
			t[e] = c;
		}
	}
	return t;
}
var Un = function(e, t) {
	let o = {
		id: e,
		title: "",
		description: "",
		columns: "",
		columnDefs: null,
		display: "",
		data: [],
		domain: null,
		overrides: null,
		sourceRef: null,
		sourceDiscrepancy: null
	};
	if (t !== "") {
		let s = r(t), c = 0;
		for (; c < s.length;) {
			let t = s[c++];
			if (c < s.length) {
				if (t === "title") o.title = i(s[c++]);
				else if (t === "description") o.description = a(s[c++]);
				else if (t === "columns") {
					let e = s[c++];
					e.startsWith("{") ? o.columnDefs = Ln(i(e)) : o.columns = i(e);
				} else if (t === "display") o.display = i(s[c++]);
				else if (t === "source") {
					let e = I(i(s[c++]));
					o.sourceRef ||= e, (o.sourceRefs ??= []).push(e);
				} else if (t === "source_discrepancy") o.sourceDiscrepancy = A(i(s[c++]));
				else if (t === "overrides") o.overrides = Hn(i(s[c++]));
				else if (t === "profiles") {
					let e = n(i(s[c++])), t = [], r = 0;
					for (; r < e.length;) if (e[r] === "profile") {
						r++;
						let t = a(e[r++]), n = r < e.length ? i(e[r++]) : "";
						o.profileDefs = o.profileDefs ?? [], o.profileDefs.push(Bn(t, n));
					} else t.push(e[r++]);
					t.length > 0 && (o.profiles = Vn(t.join(" ")));
				} else if (t === "domain") o.domain = i(s[c++]);
				else if (t === "data") o.data = Wn(i(s[c++]));
				else if (t === "ref") {
					let e = S(s, c, a, i);
					T(o, e.ref) || (o.refs ??= []).push(e.ref), c = e.next;
				} else if (t === "corresponds") {
					let e = D(s, c, a);
					(o.correspondences ??= []).push(e.corr), c = e.next;
				} else c = y(s, c, t);
			} else throw Error(`Parsing error: table. ID ${e}: Expecting value for ${t}`);
		}
	}
	return (t) => (t.tables[e] = o, t);
};
function Wn(e) {
	return e.split(/\n+/).map((e) => e.trim()).filter((e) => e.length > 0).map((e) => {
		let t = [], n = /"((?:[^"\\]|\\.)*)"|(\S+)/g, r;
		for (; (r = n.exec(e)) !== null;) t.push(r[1] === void 0 ? r[2] ?? "" : o(r[1]));
		return t;
	});
}
function Gn(e) {
	return typeof e == "number" ? String(e) : N(String(e));
}
function Kn(e) {
	return Array.isArray(e) ? "[" + e.map((e) => typeof e == "object" && e ? "{ " + Object.entries(e).map(([e, t]) => e + ": " + Gn(t)).join(" ") + " }" : Gn(e)).join(" ") + "]" : typeof e == "object" && e ? "{ " + Object.entries(e).map(([e, t]) => e + ": " + Gn(t)).join(" ") + " }" : Gn(e);
}
var qn = function(e) {
	let t = "table " + e.id + " {\n";
	if (t += "  title \"" + e.title + "\"\n", e.description && (t += "  description \"" + s(e.description) + "\"\n"), e.columnDefs && e.columnDefs.length > 0) {
		t += "  columns {\n";
		for (let n of e.columnDefs) {
			let e = "    " + n.name + ": " + n.type;
			n.unit && (e += " \"" + s(n.unit) + "\""), t += e + "\n";
		}
		t += "  }\n";
	} else t += "  columns \"" + e.columns + "\"\n";
	e.display && (t += "  display \"" + e.display + "\"\n");
	for (let n of e.sourceRefs ?? (e.sourceRef && (e.sourceRef.doc || e.sourceRef.clause) ? [e.sourceRef] : [])) t += E(n, "  ", s);
	if (e.sourceDiscrepancy && (t += j(e.sourceDiscrepancy, "  ") + "\n"), t += k(e.correspondences, "  ", s, N), e.overrides && Object.keys(e.overrides).length > 0) {
		t += "  overrides { ";
		for (let [n, r] of Object.entries(e.overrides)) t += n + " { condition " + r.condition + " by " + r.by + " } ";
		t += "}\n";
	}
	if (e.domain && (t += "  domain { }\n"), e.data.length > 0) {
		t += "  data {\n";
		for (let n of e.data) {
			let e = n.map((e) => `"${s(e)}"`).join(" ");
			t += "    " + e + "\n";
		}
		t += "  }\n";
	}
	if (e.profiles && Object.keys(e.profiles).length > 0 || e.profileDefs && e.profileDefs.length > 0) {
		t += "  profiles {\n";
		for (let [n, r] of Object.entries(e.profiles ?? {})) {
			t += "    " + n + " { ";
			for (let [e, n] of Object.entries(r)) t += e + ": { " + String(n) + " } ";
			t += "}\n";
		}
		for (let n of e.profileDefs ?? []) {
			let e = "    profile " + n.name + " { ";
			n.description && (e += "description \"" + s(n.description) + "\" "), n.dimension && (e += "dimension " + n.dimension + " "), n.unit && (e += "unit \"" + s(n.unit) + "\" "), n.type && (e += "type " + n.type + " "), n.sourceDiscrepancy && (e += j(n.sourceDiscrepancy, "") + " "), e += "binding { ";
			for (let [t, r] of Object.entries(n.binding)) e += t + ": " + Kn(r) + " ";
			e += "} ", t += e + "}\n";
		}
		t += "  }\n";
	}
	return t += "}\n", t;
}, Jn = function(e, t) {
	let n = {
		id: e,
		title: "",
		src: ""
	};
	if (t !== "") {
		let a = r(t), o = 0;
		for (; o < a.length;) {
			let t = a[o++];
			if (o < a.length) t === "title" ? n.title = i(a[o++]) : t === "src" ? n.src = i(a[o++]) : o++;
			else throw Error(`Parsing error: figure. ID ${e}: Expecting value for ${t}`);
		}
	}
	return (t) => (t.figures[e] = n, t);
}, Yn = function(e) {
	let t = "figure " + e.id + " {\n";
	return t += "  title \"" + s(e.title) + "\"\n", t += "  src \"" + s(e.src) + "\"\n", t += "}\n", t;
}, Xn = ["REPO", "URL"], Zn = function(e, t) {
	let n = {
		id: e,
		kind: "URL",
		target: "",
		namespace: ""
	};
	if (t !== "") {
		let a = r(t), o = 0;
		for (; o < a.length;) {
			let t = a[o++];
			if (o < a.length) {
				if (t === "type" || t === "kind") {
					let t = a[o++];
					if (!Xn.includes(t)) throw Error(`Parsing error: link. ID ${e}: Unknown kind ${t} (valid: ${Xn.join(", ")})`);
					n.kind = t;
				} else t === "target" || t === "path" || t === "url" ? n.target = i(a[o++]) : t === "namespace" || t === "ns" ? n.namespace = i(a[o++]) : o++;
			} else throw Error(`Parsing error: link. ID ${e}: Expecting value for ${t}`);
		}
	}
	return (t) => (t.links[e] = n, t);
}, Qn = function(e) {
	let t = "link " + e.id + " {\n";
	return t += "  type " + e.kind + "\n", t += "  target \"" + s(e.target) + "\"\n", e.namespace && (t += "  namespace \"" + s(e.namespace) + "\"\n"), t += "}\n", t;
}, $n = function(e, t) {
	let n = {
		id: e,
		on: "",
		author: "",
		timestamp: "",
		text: "",
		replyTo: null,
		resolved: !1,
		_feedback: []
	};
	if (t !== "") {
		let e = r(t), a = 0;
		for (; a < e.length;) {
			let t = e[a++];
			t === "on" ? n.on = e[a++] : t === "author" || t === "username" ? n.author = i(e[a++]) : t === "timestamp" ? n.timestamp = i(e[a++]) : t === "text" || t === "message" ? n.text = i(e[a++]) : t === "reply_to" ? n.replyTo = e[a++] : t === "feedback" ? n._feedback = r(i(e[a++])) : t === "resolved" ? n.resolved = a < e.length && (e[a] === "true" || e[a] === "false") ? e[a++] === "true" : !0 : a++;
		}
	}
	return (t) => (t.comments[e] = n, t);
}, er = function(e, t) {
	let n = t.replyTo;
	if (!n) {
		for (let [r, i] of Object.entries(e.comments)) if ((i._feedback ?? []).includes(t.id)) {
			n = r;
			break;
		}
	}
	return {
		id: t.id,
		on: t.on,
		author: t.author,
		timestamp: t.timestamp,
		text: t.text,
		replyTo: n ?? null,
		resolved: t.resolved
	};
}, tr = function(e) {
	let t = "comment " + e.id + " {\n";
	return e.on && (t += "  on " + e.on + "\n"), t += "  author \"" + s(e.author) + "\"\n", t += "  timestamp \"" + s(e.timestamp) + "\"\n", t += "  text \"" + s(e.text) + "\"\n", e.replyTo !== null && (t += "  reply_to " + e.replyTo + "\n"), e.resolved && (t += "  resolved true\n"), t + "}\n";
}, nr = /* @__PURE__ */ new Set([
	"full",
	"minimal",
	"partial",
	"none"
]);
function rr(e, t) {
	let r = {
		target: "",
		description: "",
		justification: "",
		coverage: ""
	}, i = n(t), o = 0;
	for (; o < i.length;) {
		let t = i[o++];
		if (o >= i.length) break;
		if (t === "description") r.description = a(i[o++]);
		else if (t === "justification") r.justification = a(i[o++]);
		else if (t === "coverage") {
			let t = a(i[o++]);
			if (!nr.has(t)) throw Error(`Parsing error: map_profile. ID ${e}: Unknown coverage level "${t}" (valid: full, minimal, partial, none)`);
			r.coverage = t;
		} else i[o].startsWith("{") ? o++ : (o++, o < i.length && i[o].startsWith("{") && o++);
	}
	return r;
}
function ir(e) {
	let t = [];
	for (let n of e) {
		if (n.startsWith("\"") || n.startsWith("{") || !n.includes("->") && !n.includes("→")) {
			t.push(n);
			continue;
		}
		t.push(...n.split(/(->|→)/).filter((e) => e !== ""));
	}
	return t;
}
function ar(e, t) {
	let r = {}, o = ir(n(t)), s = 0;
	for (; s < o.length;) {
		let t = a(o[s++]);
		if (!t) break;
		let n = o[s++];
		if (n !== "->" && n !== "→") throw Error(`Parsing error: map_profile. ID ${e}: Expecting "->" after mapping source "${t}" (got "${n ?? ""}")`);
		let c = a(o[s++]), l = {
			target: c,
			description: "",
			justification: "",
			coverage: ""
		};
		s < o.length && o[s].startsWith("{") && (l = {
			...rr(e, i(o[s++])),
			target: c
		}), (r[t] ??= []).push(l);
	}
	return r;
}
function or(e, t) {
	let r = {}, i = n(t), o = 0;
	for (; o < i.length;) {
		let t = a(i[o++]);
		if (!t) break;
		let n = a(i[o++]);
		if (!nr.has(n)) throw Error(`Parsing error: map_profile. ID ${e}: Unknown coverage level "${n}" for "${t}" (valid: full, minimal, partial, none)`);
		r[t] = n;
	}
	return r;
}
var sr = function(e, t) {
	let n = {
		namespace: a(e),
		description: "",
		mappings: {},
		coverage: {}
	};
	return v(t, (t, r) => {
		if (t === "description") n.description = x(r);
		else if (t === "mapping") {
			let t = ar(e, i(r()));
			for (let [e, r] of Object.entries(t)) (n.mappings[e] ??= []).push(...r);
		} else if (t === "coverage") Object.assign(n.coverage, or(e, i(r())));
		else return !1;
		return !0;
	}, {
		construct: "map_profile",
		id: e
	}), (t) => (t.mapProfiles[e] = n, t);
}, cr = function(e) {
	let t = "map_profile " + N(e.namespace) + " {\n";
	e.description && (t += "  description \"" + s(e.description) + "\"\n");
	let n = Object.keys(e.mappings);
	if (n.length > 0) {
		t += "  mapping {\n";
		for (let r of n) for (let n of e.mappings[r]) {
			let e = "    " + N(r) + " -> " + N(n.target), i = [];
			n.description && i.push("description \"" + s(n.description) + "\""), n.justification && i.push("justification \"" + s(n.justification) + "\""), n.coverage && i.push("coverage " + n.coverage), t += i.length > 0 ? e + " { " + i.join(" ") + " }\n" : e + "\n";
		}
		t += "  }\n";
	}
	let r = Object.keys(e.coverage ?? {});
	if (r.length > 0) {
		t += "  coverage {\n";
		for (let n of r) t += "    " + N(n) + " " + e.coverage[n] + "\n";
		t += "  }\n";
	}
	return t += "}\n", t;
};
//#endregion
//#region src/ser-des/config/viewProfile.ts
function lr(e) {
	return e.startsWith("{") || e.startsWith("[") ? r(e).map(a) : [a(e)];
}
var ur = function(e, t) {
	let n = {
		id: e,
		description: "",
		roles: [],
		visibleElements: [],
		against: ""
	};
	return v(t, (e, t) => {
		if (e === "description") n.description = x(t);
		else if (e === "roles") n.roles = lr(t());
		else if (e === "visible") n.visibleElements = lr(t());
		else if (e === "against") n.against = t().trim();
		else return !1;
		return !0;
	}, {
		construct: "view_profile",
		id: e
	}), (t) => (t.viewProfiles[e] = n, t);
}, dr = function(e) {
	let t = "view_profile " + e.id + " {\n";
	return e.description && (t += "  description \"" + s(e.description) + "\"\n"), e.roles.length > 0 && (t += "  roles { " + e.roles.map(N).join(" ") + " }\n"), e.visibleElements.length > 0 && (t += "  visible { " + e.visibleElements.map(N).join(" ") + " }\n"), e.against && (t += "  against " + e.against + "\n"), t += "}\n", t;
}, fr = function(e, t) {
	let o = {
		id: e,
		name: "",
		description: "",
		dataClassId: "",
		headerFormId: "",
		conformanceProcessId: "",
		section: "",
		requirements: [],
		formNotes: [],
		scope: "",
		formReferences: [],
		calculationContext: null,
		formInstances: [],
		formConstraints: [],
		applicability: [],
		fields: [],
		passFail: null,
		referenceIds: [],
		ref: []
	};
	if (t !== "") {
		let s = r(t), c = 0;
		for (; c < s.length;) {
			let t = s[c++];
			if (c < s.length) {
				if (t === "name") o.name = a(s[c++]);
				else if (t === "description") o.description = a(s[c++]);
				else if (t === "data_class") o.dataClassId = a(s[c++]);
				else if (t === "header") o.headerFormId = a(s[c++]);
				else if (t === "section") o.section = a(s[c++]);
				else if (t === "requirements") o.requirements = r(s[c++]).map(a);
				else if (t === "note") o.formNotes.push(a(s[c++]));
				else if (t === "scope") o.scope = a(s[c++]);
				else if (t === "report_rows") {
					let e = n(i(s[c++])), t = {
						field: "",
						itemKey: ""
					};
					for (let n = 0; n + 1 < e.length; n += 2) e[n] === "field" ? t.field = a(e[n + 1]) : e[n] === "item_key" && (t.itemKey = a(e[n + 1]));
					o.reportRows = t;
				} else if (t === "references") o.formReferences = he(i(s[c++]));
				else if (t === "ref") {
					let e = S(s, c, a, i);
					T(o, e.ref) || (o.refs = [...o.refs ?? [], e.ref]), c = e.next;
				} else if (t === "corresponds") {
					let e = D(s, c, a);
					o.correspondences = [...o.correspondences ?? [], e.corr], c = e.next;
				} else if (t === "calculation_context") o.calculationContext = pr(i(s[c++]));
				else if (t === "instances") o.formInstances = mr(i(s[c++]));
				else if (t === "constraints") o.formConstraints = hr(i(s[c++]));
				else if (t === "conformance_process") {
					let e = s[c++];
					e.startsWith("{") ? (o.conformanceProcessIds = n(i(e)).map(a), o.conformanceProcessId = o.conformanceProcessIds[0] ?? "") : o.conformanceProcessId = a(e);
				} else if (t === "applicability") o.applicability = L(i(s[c++]));
				else if (t === "field") {
					let e = ce(s, c);
					e ? (o.fields.push(le(e.name, e.block, e.type || void 0)), c = e.next) : c++;
				} else if (t === "subform_ref") {
					let e = s[c++], t = c < s.length ? i(s[c++]) : "";
					o.fields.push(vr(e, t));
				} else t === "pass_fail" ? o.passFail = gr(i(s[c++])) : t === "reference" ? o.referenceIds = r(s[c++]).map(a) : c++;
			} else throw Error(`Parsing error: form. ID ${e}: Expecting value for ${t}`);
		}
	}
	return (t) => (t.forms[e] = o, t);
};
function pr(e) {
	let t = {
		header: "",
		dimensions: !1,
		tables: []
	}, r = n(e), o = 0;
	for (; o < r.length;) {
		let e = r[o++];
		if (o >= r.length) break;
		e === "header" ? t.header = a(r[o++]) : e === "dimensions" ? t.dimensions = a(r[o++]) === "true" : e === "tables" ? t.tables = n(a(r[o++])).map(a).filter((e) => e.length > 0) : i(r[o++]);
	}
	return t;
}
function mr(e) {
	let t = [], r = n(e), o = 0;
	for (; o < r.length;) {
		if (r[o++] !== "instance") {
			o < r.length && i(r[o - 1]);
			continue;
		}
		let e = {
			id: a(r[o++]),
			name: ""
		};
		if (o < r.length && r[o].startsWith("{")) {
			let t = n(i(r[o++])), s = 0;
			for (; s < t.length;) {
				let n = t[s++];
				if (s >= t.length) break;
				n === "name" ? e.name = a(t[s++]) : i(t[s++]);
			}
		}
		t.push(e);
	}
	return t;
}
function hr(e) {
	let t = [], r = n(e), o = 0;
	for (; o < r.length;) {
		if (r[o++] !== "constraint") {
			o < r.length && i(r[o - 1]);
			continue;
		}
		let e = {
			id: a(r[o++]),
			rule: "",
			onViolation: "",
			notes: "",
			source: null
		};
		if (o < r.length && r[o].startsWith("{")) {
			let t = n(i(r[o++])), s = 0;
			for (; s < t.length;) {
				let n = t[s++];
				if (s >= t.length) break;
				n === "rule" ? e.rule = a(t[s++]) : n === "on_violation" ? e.onViolation = a(t[s++]) : n === "notes" ? e.notes = a(t[s++]) : n === "source" ? e.source = I(i(t[s++])) : i(t[s++]);
			}
		}
		t.push(e);
	}
	return t;
}
function gr(e) {
	let t = {
		criteria: "",
		passIf: "",
		derivations: []
	}, r = n(e), o = 0;
	for (; o < r.length;) {
		let e = r[o++];
		o < r.length && (e === "criteria" ? t.criteria = a(r[o++]) : e === "pass_if" ? t.passIf = a(r[o++]) : e === "derivation" ? t.derivations = _r(i(r[o++])) : i(r[o++]));
	}
	return t;
}
function _r(e) {
	let t = [], r = n(e), o = 0;
	for (; o < r.length;) {
		if (r[o++] !== "value") {
			o < r.length && i(r[o - 1]);
			continue;
		}
		let e = {
			name: a(r[o++]),
			calculation: "",
			forEach: "",
			unit: ""
		};
		if (o < r.length && r[o].startsWith("{")) {
			let t = n(i(r[o++])), s = 0;
			for (; s < t.length;) {
				let n = t[s++];
				if (s >= t.length) break;
				n === "calculation" ? e.calculation = a(t[s++]) : n === "for_each" ? e.forEach = a(t[s++]) : n === "unit" ? e.unit = a(t[s++]) : i(t[s++]);
			}
		}
		t.push(e);
	}
	return t;
}
function vr(e, t) {
	return {
		name: "",
		type: "array",
		label: "",
		definition: "",
		unit: "",
		symbol: "",
		verdict: "",
		targets: [],
		dimension: "",
		enumRef: "",
		pattern: "",
		required: !1,
		requiredWhen: "",
		measurementMethod: "",
		calculationId: null,
		calculationBindings: [],
		derivation: "",
		evaluation: null,
		values: [],
		trueLabel: "",
		falseLabel: "",
		enumValues: [],
		defaultValue: "",
		hasDefault: !1,
		referenceIds: [],
		refs: [],
		fieldReferences: [],
		specificationReference: "",
		applicability: [],
		sourceDiscrepancy: null,
		fields: [],
		itemsType: "",
		subformRef: pe(e, t)
	};
}
var yr = function(e) {
	let t = "form " + e.id + " {\n";
	t += "  name \"" + s(e.name) + "\"\n", e.description && (t += "  description \"" + s(e.description) + "\"\n"), e.dataClassId && (t += "  data_class " + e.dataClassId + "\n"), e.headerFormId && (t += "  header " + e.headerFormId + "\n"), e.section && (t += "  section \"" + s(e.section) + "\"\n"), e.requirements.length > 0 && (t += "  requirements { " + e.requirements.join(" ") + " }\n");
	for (let n of e.formNotes) t += "  note \"" + s(n) + "\"\n";
	if (e.scope && (t += "  scope " + e.scope + "\n"), e.reportRows && (e.reportRows.field || e.reportRows.itemKey) && (t += "  report_rows { field " + e.reportRows.field + " item_key " + e.reportRows.itemKey + " }\n"), e.formReferences.length > 0) for (let n of e.formReferences) {
		let e = n.role === "source" ? "derives-from" : n.role === "reference" ? "cites" : n.role;
		t += "  ref " + e + " \"" + s(n.urn) + "\"\n";
	}
	if (e.refs && e.refs.length > 0) for (let n of e.refs) t += "  ref " + n.predicate + " \"" + s(n.target) + "\"" + (n.note ? " { note \"" + s(n.note) + "\" }" : "") + "\n";
	if (t += k(e.correspondences, "  ", s, N), e.calculationContext) {
		let n = e.calculationContext, r = "  calculation_context { ";
		n.header && (r += "header " + n.header + " "), n.dimensions && (r += "dimensions true "), n.tables.length > 0 && (r += "tables { " + n.tables.join(" ") + " } "), t += r + "}\n";
	}
	if (e.formInstances.length > 0) {
		t += "  instances {\n";
		for (let n of e.formInstances) t += "    instance " + n.id + " { name \"" + s(n.name) + "\" }\n";
		t += "  }\n";
	}
	if (e.formConstraints.length > 0) {
		t += "  constraints {\n";
		for (let n of e.formConstraints) t += "    constraint " + n.id + " { ", n.rule && (t += "rule \"" + s(n.rule) + "\" "), n.onViolation && (t += "on_violation " + n.onViolation + " "), n.notes && (t += "notes \"" + s(n.notes) + "\" "), n.source && (n.source.doc || n.source.clause) && (t += "source { doc \"" + s(n.source.doc) + "\" clause \"" + s(n.source.clause) + "\"" + (n.source.fragment ? " fragment \"" + s(n.source.fragment) + "\"" : "") + " } "), t += "}\n";
		t += "  }\n";
	}
	e.conformanceProcessIds && e.conformanceProcessIds.length > 1 ? t += "  conformance_process { " + e.conformanceProcessIds.join(" ") + " }\n" : e.conformanceProcessId && (t += "  conformance_process " + e.conformanceProcessId + "\n"), e.applicability.length > 0 && (t += "  applicability {\n    " + R(e.applicability).trim() + "\n  }\n");
	for (let n of e.fields) t += me(n, "  ");
	return e.passFail && (t += br(e.passFail)), t += "}\n", t;
};
function br(e) {
	if (e.derivations.length === 0) return "  pass_fail { criteria \"" + s(e.criteria) + "\" pass_if \"" + s(e.passIf) + "\" }\n";
	let t = "  pass_fail {\n";
	t += "    criteria \"" + s(e.criteria) + "\"\n", t += "    pass_if \"" + s(e.passIf) + "\"\n", t += "    derivation {\n";
	for (let n of e.derivations) {
		let e = "      value " + n.name + " { ";
		n.calculation && (e += "calculation \"" + s(n.calculation) + "\" "), n.forEach && (e += "for_each " + n.forEach + " "), n.unit && (e += "unit \"" + s(n.unit) + "\" "), t += e + "}\n";
	}
	return t += "    }\n", t += "  }\n", t;
}
//#endregion
//#region src/ser-des/config/subform.ts
var xr = function(e, t) {
	let n = {
		id: e,
		description: "",
		shapeType: "object",
		parameters: [],
		fields: []
	};
	if (t !== "") {
		let o = r(t), s = 0;
		for (; s < o.length;) {
			let t = o[s++];
			if (s < o.length) {
				if (t === "description") n.description = a(o[s++]);
				else if (t === "type") {
					let t = o[s++];
					if (t === "object" || t === "array") n.shapeType = t;
					else throw Error(`Parsing error: subform. ID ${e}: type must be object or array (got ${t})`);
				} else if (t === "parameters") n.parameters = Sr(i(o[s++]));
				else if (t === "field") {
					let e = ce(o, s);
					e ? (n.fields.push(le(e.name, e.block, e.type || void 0)), s = e.next) : s++;
				} else s++;
			} else throw Error(`Parsing error: subform. ID ${e}: Expecting value for ${t}`);
		}
	}
	return (t) => (t.subforms[e] = n, t);
};
function Sr(e) {
	let t = [], o = n(e), s = 0;
	for (; s < o.length;) {
		let e = P(o[s++]);
		if (s >= o.length) break;
		o[s] === ":" && s++;
		let c = s < o.length ? o[s++] : "integer", l = "", u = !1, d = "", f = null;
		if (s < o.length && o[s].startsWith("{")) {
			let e = r(i(o[s++])), t = 0;
			for (; t < e.length;) {
				let r = e[t++];
				if (t < e.length) {
					if (r === "description") l = a(e[t++]);
					else if (r === "default") d = a(e[t++]), u = !0;
					else if (r === "mapping") {
						let r = i(e[t++]);
						f = {};
						let o = n(r), s = 0;
						for (; s < o.length;) {
							let e = P(o[s++]);
							s < o.length && (o[s] === ":" && s++, s < o.length && (f[e] = a(o[s++])));
						}
					} else t++;
				}
			}
		}
		t.push({
			name: e,
			type: c,
			description: l,
			hasDefault: u,
			defaultValue: d,
			mapping: f
		});
	}
	return t;
}
var Cr = function(e) {
	let t = "subform " + e.id + " {\n";
	if (t += "  type " + e.shapeType + "\n", e.description && (t += "  description \"" + s(e.description) + "\"\n"), e.parameters.length > 0) {
		t += "  parameters {\n";
		for (let n of e.parameters) {
			let e = "    " + n.name + " : " + n.type + " { ";
			if (n.description && (e += "description \"" + s(n.description) + "\" "), n.hasDefault && (e += "default " + n.defaultValue + " "), n.mapping) {
				e += "mapping { ";
				for (let [t, r] of Object.entries(n.mapping)) e += t + ": " + r + " ";
				e += "} ";
			}
			e += "}\n", t += e;
		}
		t += "  }\n";
	}
	for (let n of e.fields) t += me(n, "  ");
	return t += "}\n", t;
}, wr = [
	"number",
	"integer",
	"string",
	"boolean",
	"enum",
	"collection",
	"array"
], Tr = function(e, t) {
	let o = {
		id: e,
		name: "",
		definition: "",
		type: "number",
		unit: "1",
		latex: "",
		values: [],
		series: null,
		kind: "",
		quantityKind: "",
		origin: "",
		legacyId: "",
		attribute: "",
		calculation: "",
		profile: "",
		sourceRef: null,
		formula: null,
		notes: [],
		ref: [],
		_relations: { ref: [] }
	};
	return v(t, (t, s, c) => {
		if (t === "ref") {
			let e = C(s, c, a, i);
			return T(o, e) || (o.refs ??= []).push(e), !0;
		}
		if (t === "corresponds") return (o.correspondences ??= []).push(O(s, c, a)), !0;
		if (t === "name") o.name = x(s);
		else if (t === "definition") o.definition = x(s);
		else if (t === "type") {
			let t = s();
			if (!wr.includes(t)) throw Error(`Parsing error: symbol. ID ${e}: Unknown type ${t} (valid: ${wr.join(", ")})`);
			o.type = t;
		} else if (t === "unit") o.unit = x(s);
		else if (t === "latex") o.latex = x(s);
		else if (t === "values") {
			let e = s();
			o.values = e.startsWith("{") ? r(e).map(a) : [a(e)];
		} else if (t === "series") o.series = te(i(s()));
		else if (t === "kind") o.kind = a(s());
		else if (t === "quantity_kind") o.quantityKind = a(s());
		else if (t === "origin") o.origin = a(s());
		else if (t === "legacy_id") o.legacyId = a(s());
		else if (t === "attribute") o.attribute = a(s());
		else if (t === "calculation") o.calculation = a(s());
		else if (t === "profile") o.profile = a(s());
		else if (t === "source") o.sourceRef = I(i(s()));
		else if (t === "formula") {
			let e = n(i(s())), t = {
				display: "",
				expression: "",
				inputs: []
			}, r = 0;
			for (; r < e.length;) {
				let o = e[r++];
				if (r >= e.length) break;
				o === "display" ? t.display = a(e[r++]) : o === "expression" ? t.expression = a(e[r++]) : o === "inputs" ? t.inputs = n(a(e[r++])).map(a).filter((e) => e.length > 0) : i(e[r++]);
			}
			o.formula = t;
		} else if (t === "note") o.notes.push(x(s));
		else if (t === "reference") o._relations.ref = r(s());
		else return !1;
		return !0;
	}, {
		construct: "symbol",
		id: e
	}), (t) => (t.symbols[e] = o, t);
}, Er = function(e, t) {
	let n = [];
	for (let r of t._relations.ref) {
		let t = f(e, "references", r);
		t !== void 0 && n.push(t);
	}
	return {
		...t,
		ref: n
	};
}, Dr = function(e) {
	let t = "symbol " + e.id + " {\n";
	if (t += "  name \"" + s(e.name) + "\"\n", e.definition && (t += "  definition \"" + s(e.definition) + "\"\n"), t += "  type " + e.type + "\n", e.unit && e.unit !== "1" && (t += "  unit \"" + s(e.unit) + "\"\n"), e.latex && (t += "  latex \"" + s(e.latex) + "\"\n"), e.values.length > 0 && (t += "  values { " + e.values.map(N).join(" ") + " }\n"), e.series && (t += "  " + ne(e.series) + "\n"), e.kind && (t += "  kind " + e.kind + "\n"), e.quantityKind && (t += "  quantity_kind " + e.quantityKind + "\n"), e.origin && (t += "  origin " + e.origin + "\n"), e.legacyId && (t += "  legacy_id " + e.legacyId + "\n"), e.attribute && (t += "  attribute " + e.attribute + "\n"), e.calculation && (t += "  calculation " + e.calculation + "\n"), e.profile && (t += "  profile " + e.profile + "\n"), e.sourceRef && (e.sourceRef.doc || e.sourceRef.clause) && (t += "  source { doc \"" + s(e.sourceRef.doc) + "\" clause \"" + s(e.sourceRef.clause) + "\"" + (e.sourceRef.fragment ? " fragment \"" + s(e.sourceRef.fragment) + "\"" : "") + " }\n"), e.formula) {
		let n = "  formula { ";
		e.formula.display && (n += "display \"" + s(e.formula.display) + "\" "), e.formula.expression && (n += "expression \"" + s(e.formula.expression) + "\" "), e.formula.inputs.length > 0 && (n += "inputs { " + e.formula.inputs.join(" ") + " } "), t += n + "}\n";
	}
	for (let n of e.notes) t += "  note \"" + s(n) + "\"\n";
	if (e.ref.length > 0) {
		t += "  reference {\n";
		for (let n of e.ref) t += "    " + n.id + "\n";
		t += "  }\n";
	}
	return t += k(e.correspondences, "  ", s, N), t += "}\n", t;
};
//#endregion
//#region src/ser-des/config/formulaNote.ts
function Or(e) {
	return n(a(e)).map(P).map(a).filter((e) => e.length > 0);
}
var kr = (e, t) => {
	let n = {
		id: e,
		text: "",
		appliesTo: []
	};
	return v(t, (e, t) => {
		if (e === "text") n.text = a(t());
		else if (e === "applies_to") n.appliesTo = Or(t());
		else return !1;
		return !0;
	}, {
		construct: "formula_note",
		id: e
	}), (t) => (t.formulaNotes[e] = n, t);
}, Ar = function(e) {
	let t = "formula_note " + e.id + " {\n";
	return e.text && (t += "  text \"" + s(e.text) + "\"\n"), e.appliesTo.length > 0 && (t += "  applies_to { " + e.appliesTo.map(N).join(" ") + " }\n"), t += "}\n", t;
}, jr = function(e, t) {
	let o = {
		id: e,
		name: "",
		description: "",
		inputs: [],
		output: {
			type: "number",
			unit: "1"
		},
		expression: "",
		params: [],
		lookup: null,
		profile: "",
		ref: [],
		_relations: { ref: [] },
		sourceRef: null
	};
	if (t !== "") {
		let s = r(t), c = 0;
		for (; c < s.length;) {
			let t = s[c++];
			if (c < s.length) {
				if (t === "name") o.name = i(s[c++]);
				else if (t === "identifier") o.identifier = a(s[c++]);
				else if (t === "type") o.ruleType = a(s[c++]);
				else if (t === "category") o.category = a(s[c++]);
				else if (t === "label") o.label = a(s[c++]);
				else if (t === "description") o.description = i(s[c++]);
				else if (t === "expression") o.expression = i(s[c++]);
				else if (t === "reference") o._relations.ref = r(s[c++]);
				else if (t === "ref") {
					let e = S(s, c, a, i);
					T(o, e.ref) || (o.refs ??= []).push(e.ref), c = e.next;
				} else if (t === "corresponds") {
					let e = D(s, c, a);
					(o.correspondences ??= []).push(e.corr), c = e.next;
				} else if (t === "source") {
					let e = n(i(s[c++])), t = {
						doc: "",
						clause: ""
					};
					for (let n = 0; n + 1 < e.length; n += 2) e[n] === "doc" ? t.doc = a(e[n + 1]) : e[n] === "clause" ? t.clause = a(e[n + 1]) : e[n] === "fragment" && (t.fragment = a(e[n + 1]));
					o.sourceRef ||= t, (o.sourceRefs ??= []).push(t);
				} else if (t === "inputs") o.inputs = Mr(i(s[c++]));
				else if (t === "output") {
					let e = "";
					s[c] === ":" && (e += s[c++]), c < s.length && !s[c].startsWith("{") && (e += " " + s[c++]), c < s.length && s[c].startsWith("{") && (e += " " + s[c++]), o.output = Nr(e);
				} else if (t === "params") o.params = n(a(s[c++])).map(a).filter((e) => e.length > 0);
				else if (t === "lookup") o.lookup = Pr(i(s[c++]));
				else if (t === "profile") o.profile = a(s[c++]);
				else if (t === "variant") {
					let t = a(s[c++]);
					if (c >= s.length || !s[c].startsWith("{")) throw Error(`Parsing error: calculation. ID ${e}: variant ${t} is missing its block`);
					(o.variants ??= []).push(Ir(t, i(s[c++]), e));
				} else c++;
			} else throw Error(`Parsing error: calculation. ID ${e}: Expecting value for ${t}`);
		}
	}
	return (t) => (t.calculations[e] = o, t);
};
function Mr(e) {
	let t = [], n = r(e), o = 0;
	for (; o < n.length;) {
		let e = n[o++];
		if (o >= n.length) break;
		n[o] === ":" && o++;
		let s = o < n.length ? n[o++] : "number", c = "1", l = "", u = "", d = !1, f, p, m, h, g = !1;
		if (o < n.length && n[o].startsWith("{")) {
			let e = r(i(n[o++])), t = 0;
			for (; t < e.length;) {
				let n = e[t++];
				if (t < e.length) {
					if (n === "unit") c = a(e[t++]);
					else if (n === "quantity_kind") p = a(e[t++]);
					else if (n === "range") {
						let n = r(i(e[t++])), o = 0;
						for (; o < n.length;) {
							let e = n[o++];
							if (o >= n.length) break;
							e === "min" ? (m = a(n[o++]), g = !0) : e === "max" ? (h = a(n[o++]), g = !0) : i(n[o++]);
						}
					} else n === "description" ? l = i(e[t++]) : n === "default" ? (u = a(e[t++]), d = !0) : n === "enum_values" ? f = r(i(e[t++])) : t++;
				}
			}
		}
		let _ = {
			name: e,
			type: s,
			unit: c,
			description: l,
			defaultValue: u,
			hasDefault: d,
			enumValues: f
		};
		p !== void 0 && (_.quantityKind = p), g && (_.hasRange = !0, m !== void 0 && (_.rangeMin = m), h !== void 0 && (_.rangeMax = h)), t.push(_);
	}
	return t;
}
function Nr(e) {
	let t = n(e), o = 0, s = "number", c = "1", l = "", u = "", d, f, p, m = !1;
	if (t[o] === ":" && o++, o < t.length && (s = t[o++]), o < t.length && t[o].startsWith("{")) {
		let e = r(i(t[o++])), n = 0;
		for (; n < e.length;) {
			let t = e[n++];
			if (n < e.length) {
				if (t === "unit") c = a(e[n++]);
				else if (t === "quantity_kind") d = a(e[n++]);
				else if (t === "range") {
					let t = r(i(e[n++])), o = 0;
					for (; o < t.length;) {
						let e = t[o++];
						if (o >= t.length) break;
						e === "min" ? (f = a(t[o++]), m = !0) : e === "max" ? (p = a(t[o++]), m = !0) : i(t[o++]);
					}
				} else t === "name" ? l = a(e[n++]) : t === "description" ? u = a(e[n++]) : n++;
			}
		}
	}
	let h = {
		type: s,
		unit: c
	};
	return l && (h.name = l), u && (h.description = u), d !== void 0 && (h.quantityKind = d), m && (h.hasRange = !0, f !== void 0 && (h.rangeMin = f), p !== void 0 && (h.rangeMax = p)), h;
}
function Pr(e) {
	let t = {
		key: "",
		variable: "",
		multiplier: ""
	}, o = r(e), s = 0;
	for (; s < o.length;) {
		let e = o[s++];
		if (s >= o.length) break;
		if (e === "key") t.key = a(o[s++]);
		else if (e === "variable") t.variable = a(o[s++]);
		else if (e === "multiplier") t.multiplier = a(o[s++]);
		else if (e === "default_tier") {
			let e = n(i(o[s++])), r = { factor: 0 };
			for (let t = 0; t < e.length; t++) e[t] === "factor" && t + 1 < e.length ? r.factor = Number(a(e[++t])) : e[t] === "mode" && t + 1 < e.length && (r.mode = a(e[++t]));
			t.defaultTier = r;
		} else i(o[s++]);
	}
	return t;
}
var Fr = [
	"expression",
	"table_lookup",
	"profile_lookup",
	"pass_fail"
];
function Ir(e, t, o) {
	let s = {
		id: e,
		type: "",
		label: "",
		description: "",
		params: [],
		expression: "",
		lookup: null,
		profile: ""
	}, c = r(t), l = 0;
	for (; l < c.length;) {
		let t = c[l++];
		if (l >= c.length) break;
		if (t === "type") {
			let t = a(c[l++]);
			if (!Fr.includes(t)) throw Error(`Parsing error: calculation. ID ${o}: variant ${e}: Unknown variant type "${t}" (valid: ${Fr.join(", ")})`);
			s.type = t;
		} else t === "label" ? s.label = a(c[l++]) : t === "description" ? s.description = a(c[l++]) : t === "params" ? s.params = n(a(c[l++])).map(a).filter((e) => e.length > 0) : t === "expression" ? s.expression = a(c[l++]) : t === "lookup" ? s.lookup = Pr(i(c[l++])) : t === "profile" ? s.profile = a(c[l++]) : i(c[l++]);
	}
	return s;
}
function Lr(e) {
	let t = "";
	return e.key && (t += "key " + e.key + " "), e.variable && (t += "variable " + e.variable + " "), e.multiplier && (t += "multiplier " + e.multiplier + " "), e.defaultTier && (t += "default_tier { factor " + e.defaultTier.factor, e.defaultTier.mode && (t += " mode " + e.defaultTier.mode), t += " } "), t;
}
function Rr(e) {
	let t = "  variant " + N(e.id) + " {\n";
	return e.type && (t += "    type " + e.type + "\n"), e.label && (t += "    label \"" + s(e.label) + "\"\n"), e.description && (t += "    description \"" + s(e.description) + "\"\n"), e.params.length > 0 && (t += "    params { " + e.params.map(N).join(" ") + " }\n"), e.expression && (t += "    expression \"" + s(e.expression) + "\"\n"), e.lookup && (t += "    lookup { " + Lr(e.lookup) + "}\n"), e.profile && (t += "    profile " + N(e.profile) + "\n"), t += "  }\n", t;
}
var zr = function(e, t) {
	let n = [];
	for (let r of t._relations.ref) {
		let t = f(e, "references", r);
		t !== void 0 && n.push(t);
	}
	return {
		...t,
		ref: n
	};
}, Br = function(e) {
	let t = "calculation " + e.id + " {\n";
	if (t += "  name \"" + s(e.name) + "\"\n", e.identifier && (t += "  identifier \"" + s(e.identifier) + "\"\n"), e.ruleType && (t += "  type " + e.ruleType + "\n"), e.category && (t += "  category " + e.category + "\n"), e.label && (t += "  label \"" + s(e.label) + "\"\n"), e.description && (t += "  description \"" + s(e.description) + "\"\n"), e.inputs.length > 0) {
		t += "  inputs {\n";
		for (let n of e.inputs) {
			let e = "    " + n.name + " : " + n.type + " { ";
			e += "unit \"" + s(n.unit) + "\"", n.quantityKind && (e += " quantity_kind " + n.quantityKind), n.description && (e += " description \"" + s(n.description) + "\""), n.hasDefault && (e += " default " + N(n.defaultValue)), n.enumValues && n.enumValues.length > 0 && (e += " enum_values { " + n.enumValues.join(" ") + " }"), n.hasRange && (e += " range {", n.rangeMin && (e += " min " + N(n.rangeMin)), n.rangeMax && (e += " max " + N(n.rangeMax)), e += " }"), e += " }\n", t += e;
		}
		t += "  }\n";
	}
	let n = "  output : " + e.output.type + " { unit \"" + s(e.output.unit) + "\"";
	e.output.quantityKind && (n += " quantity_kind " + e.output.quantityKind), e.output.name && (n += " name \"" + s(e.output.name) + "\""), e.output.description && (n += " description \"" + s(e.output.description) + "\""), e.output.hasRange && (n += " range {", e.output.rangeMin && (n += " min " + N(e.output.rangeMin)), e.output.rangeMax && (n += " max " + N(e.output.rangeMax)), n += " }"), t += n + " }\n", e.expression && (t += "  expression \"" + s(e.expression) + "\"\n"), e.params && e.params.length > 0 && (t += "  params { " + e.params.join(" ") + " }\n"), e.lookup && (t += "  lookup { " + Lr(e.lookup) + "}\n"), e.profile && (t += "  profile " + e.profile + "\n");
	for (let n of e.variants ?? []) t += Rr(n);
	for (let n of e.sourceRefs ?? (e.sourceRef && (e.sourceRef.doc || e.sourceRef.clause) ? [e.sourceRef] : [])) t += E(n, "  ", s);
	for (let n of e.refs ?? []) t += "  ref " + n.predicate + " \"" + s(n.target) + "\"" + (n.note ? " { note \"" + s(n.note) + "\" }" : "") + "\n";
	if (t += k(e.correspondences, "  ", s, N), e.ref.length > 0) {
		t += "  reference {\n";
		for (let n of e.ref) t += "    " + n.id + "\n";
		t += "  }\n";
	}
	return t += "}\n", t;
}, Vr = [
	"lock",
	"submit",
	"notify",
	"record"
], Hr = function(e, t) {
	let n = {
		entityName: e,
		kind: "lifecycle",
		initialState: "",
		states: [],
		transitions: [],
		referenceIds: []
	};
	if (t !== "") {
		let a = r(t), o = 0;
		for (; o < a.length;) {
			let t = a[o++];
			if (o < a.length) {
				if (t === "kind") {
					let t = a[o++];
					if (t !== "lifecycle" && t !== "operational") throw Error(`Parsing error: state_machine. Entity ${e}: Unknown kind ${t} (valid: lifecycle, operational)`);
					n.kind = t;
				} else if (t === "initial") n.initialState = a[o++];
				else if (t === "states") {
					let e = i(a[o++]);
					for (let t of e.split(/\s+/).filter((e) => e.length > 0)) n.states.push({ name: t });
				} else if (t === "transition") {
					let e = [], t = a[o++];
					if (t.startsWith("[")) {
						let n = t;
						for (; !n.includes("]") && o < a.length;) n += " " + a[o++];
						e = n.replace(/^\[/, "").replace(/\]$/, "").split(/[,\s]+/).filter((e) => e.length > 0);
					} else e = [t];
					o < a.length && (a[o] === "->" || a[o] === "→") && o++;
					let s = o < a.length ? a[o++] : "", c = "";
					o < a.length && a[o] === "action" && (o++, o < a.length && (c = a[o++]));
					let l = "", u = [], d = [];
					if (o < a.length && a[o].startsWith("{")) {
						let e = r(i(a[o++])), t = 0;
						for (; t < e.length;) {
							let n = e[t++];
							if (t < e.length) {
								if (n === "guard") l = i(e[t++]);
								else if (n === "cascade") {
									let n = e[t++];
									if (t < e.length) {
										let r = i(e[t++]);
										u.push(Ur(n, r));
									}
								} else n === "reference" ? d.push(...r(e[t++])) : i(e[t++]);
							}
						}
					}
					for (let t of e) {
						let e = {
							from: t,
							to: s,
							actionName: c,
							guard: l,
							cascades: u,
							referenceIds: d
						};
						n.transitions.push(e);
					}
				} else t === "reference" ? n.referenceIds.push(...r(a[o++])) : o++;
			} else throw Error(`Parsing error: state_machine. Entity ${e}: Expecting value for ${t}`);
		}
	}
	return (t) => (t.stateMachines[e] = n, t);
};
function Ur(e, t) {
	let o = {
		action: null,
		targetEntity: e,
		where: "",
		via: "",
		with: {},
		set: [],
		create: null
	}, s = r(t), c = 0;
	for (; c < s.length;) {
		let e = s[c++];
		if (c < s.length) {
			if (e === "action") {
				let e = s[c++];
				if (!Vr.includes(e)) throw Error(`Parsing error: state_machine cascade. Unknown action ${e} (valid: ${Vr.join(", ")})`);
				o.action = e;
			} else if (e === "where") o.where = i(s[c++]);
			else if (e === "via") o.via = s[c++];
			else if (e === "with") o.with = Wr(s[c++]);
			else if (e === "set") {
				let e = n(i(s[c++])), t = 0;
				for (; t < e.length;) {
					let n = P(e[t++]);
					if (t < e.length && (e[t] === ":" && t++, t < e.length)) {
						let r = {
							field: n,
							value: a(e[t++])
						};
						o.set.push(r);
					}
				}
			} else e === "create" ? o.create = Wr(s[c++]) : i(s[c++]);
		}
	}
	if (o.action && (o.set.length > 0 || o.create !== null)) throw Error(`Parsing error: state_machine cascade. Target ${e} mixes action with set/create — the two forms are mutually exclusive (schema oneOf)`);
	return o;
}
function Wr(e) {
	let t = {}, r = n(i(e)), o = 0;
	for (; o < r.length;) {
		let e = P(r[o++]);
		if (o >= r.length) break;
		r[o] === ":" && o++, o < r.length && (t[e] = a(r[o++]));
	}
	return t;
}
var Gr = function(e) {
	let t = "state_machine " + e.entityName + " {\n";
	if (e.kind === "operational" && (t += "  kind operational\n"), e.initialState && (t += "  initial " + e.initialState + "\n"), e.states.length > 0) {
		t += "  states {\n";
		for (let n of e.states) t += "    " + n.name + "\n";
		t += "  }\n";
	}
	let n = [];
	for (let t of e.transitions) {
		let e = (e) => [
			e.to,
			e.actionName,
			e.guard,
			JSON.stringify(e.cascades),
			JSON.stringify(e.referenceIds)
		].join("|"), r = n[n.length - 1];
		r && e({
			...t,
			from: ""
		}) === e({
			...r,
			from: ""
		}) ? r.froms.push(t.from) : n.push({
			to: t.to,
			actionName: t.actionName,
			guard: t.guard,
			cascades: t.cascades,
			referenceIds: t.referenceIds,
			froms: [t.from]
		});
	}
	for (let e of n) {
		let n = e.froms.length > 1 ? "[" + e.froms.join(", ") + "]" : e.froms[0];
		t += "  transition " + n + " -> " + e.to, e.actionName && (t += " action " + e.actionName), t += " {\n", e.guard && (t += "    guard \"" + s(e.guard) + "\"\n");
		for (let n of e.cascades) {
			if (t += "    cascade " + n.targetEntity + " {\n", n.action && (t += "      action " + n.action + "\n"), n.where && (t += "      where \"" + s(n.where) + "\"\n"), n.via && (t += "      via " + n.via + "\n"), n.with && Object.keys(n.with).length > 0) {
				t += "      with {\n";
				for (let [e, r] of Object.entries(n.with)) t += "        " + e + ": \"" + s(r) + "\"\n";
				t += "      }\n";
			}
			if (n.set.length > 0) {
				t += "      set {\n";
				for (let e of n.set) t += "        " + e.field + ": \"" + s(e.value) + "\"\n";
				t += "      }\n";
			}
			if (n.create && Object.keys(n.create).length > 0) {
				t += "      create {\n";
				for (let [e, r] of Object.entries(n.create)) t += "        " + e + ": \"" + s(r) + "\"\n";
				t += "      }\n";
			}
			t += "    }\n";
		}
		t += "  }\n";
	}
	return t += "}\n", t;
}, Kr = ["shared_risk", "guarded"], qr = [
	"NSFa",
	"NSFd",
	"absolute",
	"ratio"
], Jr = [
	"I/MPE",
	"D/NSFa",
	"D/NSFd",
	"n/a"
];
function Yr(e) {
	let t = {
		rule: "",
		guardBand: null,
		uncertainty: null,
		criterion: "",
		statistics: null
	}, r = n(e), o = 0;
	for (; o < r.length;) {
		let e = r[o++];
		if (o >= r.length) break;
		if (e === "rule") {
			let e = a(r[o++]);
			if (!Kr.includes(e)) throw Error(`Parsing error: acceptance: Unknown rule ${e} (valid: ${Kr.join(", ")})`);
			t.rule = e;
		} else if (e === "guard_band") {
			let e = n(i(r[o++])), s = {
				kind: "",
				value: 0
			}, c = 0;
			for (; c < e.length;) {
				let t = e[c++];
				if (c >= e.length) break;
				t === "kind" ? s.kind = a(e[c++]) : t === "value" ? s.value = Number(a(e[c++])) : i(e[c++]);
			}
			if (!qr.includes(s.kind)) throw Error(`Parsing error: acceptance: Unknown guard_band kind ${s.kind} (valid: ${qr.join(", ")})`);
			t.guardBand = s;
		} else if (e === "uncertainty") {
			let e = n(i(r[o++])), s = 0;
			for (; s < e.length;) {
				let n = e[s++];
				if (s >= e.length) break;
				n === "max_ratio_to_mpe" ? t.uncertainty = { maxRatioToMpe: Number(a(e[s++])) } : i(e[s++]);
			}
		} else if (e === "criterion") {
			let e = a(r[o++]);
			if (!Jr.includes(e)) throw Error(`Parsing error: acceptance: Unknown criterion ${e} (valid: ${Jr.join(", ")})`);
			t.criterion = e;
		} else if (e === "statistics") {
			let e = n(i(r[o++])), s = {
				method: "",
				onBasisOf: "",
				permits: ""
			}, c = 0;
			for (; c < e.length;) {
				let t = e[c++];
				if (c >= e.length) break;
				t === "method" ? s.method = a(e[c++]) : t === "on_basis_of" ? s.onBasisOf = a(e[c++]) : t === "permits" ? s.permits = a(e[c++]) : i(e[c++]);
			}
			t.statistics = s;
		} else i(r[o++]);
	}
	return t;
}
function Xr(e, t) {
	let n = t + "acceptance { ";
	return e.rule && (n += "rule " + e.rule + " "), e.guardBand && (n += "guard_band { kind " + e.guardBand.kind + " value " + e.guardBand.value + " } "), e.uncertainty && (n += "uncertainty { max_ratio_to_mpe " + e.uncertainty.maxRatioToMpe + " } "), e.criterion && (n += "criterion " + e.criterion + " "), e.statistics && (n += "statistics { method " + e.statistics.method + " on_basis_of " + e.statistics.onBasisOf + " permits " + e.statistics.permits + " } "), n += "}", n;
}
//#endregion
//#region src/ser-des/config/design.ts
function Zr(e) {
	return n(a(e)).map(a).filter((e) => e.length > 0);
}
function Qr(e) {
	let t = {
		level: null,
		code: "",
		amplitude: null,
		unit: "",
		note: "",
		variable: ""
	}, r = n(e), o = 0;
	for (; o < r.length;) {
		let e = r[o++];
		if (o >= r.length) break;
		e === "level" ? t.level = Number(a(r[o++])) : e === "code" ? t.code = a(r[o++]) : e === "amplitude" ? t.amplitude = Number(a(r[o++])) : e === "unit" ? t.unit = a(r[o++]) : e === "note" ? t.note = a(r[o++]) : e === "variable" ? t.variable = a(r[o++]) : i(r[o++]);
	}
	return t;
}
function $r(e) {
	let t = {
		level: null,
		code: "",
		amplitude: null,
		unit: "",
		note: "",
		variable: "",
		columns: null
	}, r = n(e), o = 0;
	for (; o < r.length;) {
		let e = r[o++];
		if (o >= r.length) break;
		if (e === "level") t.level = Number(a(r[o++]));
		else if (e === "code") t.code = a(r[o++]);
		else if (e === "amplitude") t.amplitude = Number(a(r[o++]));
		else if (e === "unit") t.unit = a(r[o++]);
		else if (e === "note") t.note = a(r[o++]);
		else if (e === "variable") t.variable = a(r[o++]);
		else if (e === "columns") {
			let e = n(i(r[o++])), a = {
				ac: null,
				dc: null,
				vehicleDc: null
			}, s = 0;
			for (; s < e.length;) {
				let t = P(e[s++]);
				if (s >= e.length) break;
				let n = e[s++], r = n.startsWith("{") ? Qr(i(n)) : null;
				t === "ac" ? a.ac = r : t === "dc" ? a.dc = r : t === "vehicle_dc" && (a.vehicleDc = r);
			}
			t.columns = a;
		} else i(r[o++]);
	}
	return t;
}
function ei(e) {
	let t = [], r = n(e), o = 0;
	for (; o < r.length;) {
		if (r[o++] !== "count") {
			o < r.length && i(r[o - 1]);
			continue;
		}
		let e = {
			context: a(r[o++]),
			minCount: 0,
			clause: "",
			note: "",
			override: null
		};
		if (o < r.length && r[o].startsWith("{")) {
			let t = n(i(r[o++])), s = 0;
			for (; s < t.length;) {
				let r = t[s++];
				if (s >= t.length) break;
				if (r === "min") e.minCount = Number(a(t[s++]));
				else if (r === "clause") e.clause = a(t[s++]);
				else if (r === "note") e.note = a(t[s++]);
				else if (r === "override") {
					let r = n(i(t[s++])), o = {
						condition: "",
						by: "",
						note: ""
					}, c = 0;
					for (; c < r.length;) {
						let e = r[c++];
						if (c >= r.length) break;
						e === "condition" ? o.condition = a(r[c++]) : e === "by" ? o.by = a(r[c++]) : e === "note" ? o.note = a(r[c++]) : i(r[c++]);
					}
					e.override = o;
				} else i(t[s++]);
			}
		}
		t.push(e);
	}
	return t;
}
function ti(e) {
	let t = [], r = n(e), o = 0;
	for (; o < r.length;) {
		if (r[o++] !== "severity") {
			o < r.length && i(r[o - 1]);
			continue;
		}
		let e = {
			row: a(r[o++]),
			envClassValues: {},
			criterion: "",
			footnotes: []
		};
		if (o < r.length && r[o].startsWith("{")) {
			let t = n(i(r[o++])), s = 0;
			for (; s < t.length;) {
				let n = t[s++];
				if (s >= t.length) break;
				if (n === "criterion") e.criterion = a(t[s++]);
				else if (n === "footnotes") e.footnotes = Zr(t[s++]);
				else if (n === "env") {
					let n = a(t[s++]), r = t[s++] ?? "";
					e.envClassValues[n] = r.startsWith("{") ? $r(i(r)) : null;
				} else i(t[s++]);
			}
		}
		t.push(e);
	}
	return t;
}
function ni(e) {
	let t = {
		duration: "",
		cadence: "",
		phases: [],
		constraints: []
	}, r = n(e), o = 0;
	for (; o < r.length;) {
		let e = r[o++];
		if (o >= r.length) break;
		if (e === "duration") t.duration = a(r[o++]);
		else if (e === "cadence") t.cadence = a(r[o++]);
		else if (e === "phases") {
			let e = n(i(r[o++])), s = 0;
			for (; s < e.length;) {
				if (e[s++] !== "phase") {
					s < e.length && i(e[s - 1]);
					continue;
				}
				let r = {
					id: a(e[s++]),
					condition: "",
					window: ""
				};
				if (s < e.length && e[s].startsWith("{")) {
					let t = n(i(e[s++])), o = 0;
					for (; o < t.length;) {
						let e = t[o++];
						if (o >= t.length) break;
						e === "condition" ? r.condition = a(t[o++]) : e === "window" ? r.window = a(t[o++]) : i(t[o++]);
					}
				}
				t.phases.push(r);
			}
		} else e === "constraints" ? t.constraints = Zr(r[o++]) : i(r[o++]);
	}
	return t;
}
function ri(e) {
	let t = {
		count: null,
		maxAdditional: null,
		selection: "",
		selectionRef: "",
		continuity: "",
		rules: []
	}, r = n(e), o = 0;
	for (; o < r.length;) {
		let e = r[o++];
		if (o >= r.length) break;
		if (e === "count") t.count = Number(a(r[o++]));
		else if (e === "max_additional") t.maxAdditional = Number(a(r[o++]));
		else if (e === "selection") {
			let e = r[o++];
			if (e.startsWith("{")) {
				let r = n(i(e)), o = 0;
				for (; o < r.length;) {
					let e = r[o++];
					if (o >= r.length) break;
					e === "ref" ? t.selectionRef = a(r[o++]) : i(r[o++]);
				}
			} else t.selection = a(e);
		} else e === "continuity" ? t.continuity = a(r[o++]) : e === "rules" ? t.rules = Zr(r[o++]) : i(r[o++]);
	}
	return t;
}
function ii(e) {
	let t = {
		counts: [],
		severities: [],
		testPointsRef: "",
		schedule: null,
		specimens: null,
		field: null,
		simulation: null,
		software: null
	}, r = n(e), o = 0;
	for (; o < r.length;) {
		let e = r[o++];
		if (o >= r.length) break;
		if (e === "counts") t.counts = ei(i(r[o++]));
		else if (e === "severities") t.severities = ti(i(r[o++]));
		else if (e === "test_points") {
			let e = n(i(r[o++])), s = 0;
			for (; s < e.length;) {
				let n = e[s++];
				if (s >= e.length) break;
				n === "ref" ? t.testPointsRef = a(e[s++]) : i(e[s++]);
			}
		} else e === "schedule" ? t.schedule = ni(i(r[o++])) : e === "specimens" ? t.specimens = ri(i(r[o++])) : e === "field" ? t.field = ai(i(r[o++])) : e === "simulation" ? t.simulation = oi(i(r[o++])) : e === "software" ? t.software = si(i(r[o++])) : i(r[o++]);
	}
	return t;
}
function ai(e) {
	let t = {
		siteSelection: "",
		trafficConditions: "",
		referenceMeter: null
	}, r = n(e), o = 0;
	for (; o < r.length;) {
		let e = r[o++];
		if (o >= r.length) break;
		if (e === "site_selection") t.siteSelection = a(r[o++]);
		else if (e === "traffic_conditions") t.trafficConditions = a(r[o++]);
		else if (e === "reference_meter") {
			let e = {
				description: "",
				uncertaintyBudget: ""
			}, s = n(i(r[o++])), c = 0;
			for (; c < s.length;) {
				let t = s[c++];
				if (c >= s.length) break;
				t === "description" ? e.description = a(s[c++]) : t === "uncertainty_budget" ? e.uncertaintyBudget = a(s[c++]) : i(s[c++]);
			}
			t.referenceMeter = e;
		} else i(r[o++]);
	}
	return t;
}
function oi(e) {
	let t = {
		simulatorKind: "",
		signal: "",
		uncertaintyBudget: "",
		validation: ""
	}, r = n(e), o = 0;
	for (; o < r.length;) {
		let e = r[o++];
		if (o >= r.length) break;
		e === "simulator_kind" ? t.simulatorKind = a(r[o++]) : e === "signal" ? t.signal = a(r[o++]) : e === "uncertainty_budget" ? t.uncertaintyBudget = a(r[o++]) : e === "validation" ? t.validation = a(r[o++]) : i(r[o++]);
	}
	return t;
}
function si(e) {
	let t = {
		level: "",
		items: []
	}, r = n(e), o = 0;
	for (; o < r.length;) {
		let e = r[o++];
		if (o >= r.length) break;
		if (e === "level") t.level = a(r[o++]);
		else if (e === "items") {
			let e = n(i(r[o++])), s = 0;
			for (; s < e.length;) {
				if (e[s++] !== "item") {
					s < e.length && i(e[s - 1]);
					continue;
				}
				let r = {
					item: Number(a(e[s++])),
					name: "",
					d31: "",
					obligation: "",
					methods: [],
					clause: ""
				};
				if (s < e.length && e[s].startsWith("{")) {
					let t = n(i(e[s++])), o = 0;
					for (; o < t.length;) {
						let e = t[o++];
						if (o >= t.length) break;
						e === "name" ? r.name = a(t[o++]) : e === "d31" ? r.d31 = a(t[o++]) : e === "obligation" ? r.obligation = a(t[o++]) : e === "methods" ? r.methods = Zr(t[o++]) : e === "clause" ? r.clause = a(t[o++]) : i(t[o++]);
					}
				}
				t.items.push(r);
			}
		} else i(r[o++]);
	}
	return t;
}
function ci(e) {
	let t = "";
	return e.level !== null && (t += "level " + e.level + " "), e.code && (t += "code \"" + s(e.code) + "\" "), e.amplitude !== null && (t += "amplitude " + e.amplitude + " "), e.unit && (t += "unit \"" + s(e.unit) + "\" "), e.note && (t += "note \"" + s(e.note) + "\" "), e.variable && (t += "variable " + e.variable + " "), t;
}
function li(e) {
	let t = ci(e);
	return e.columns && (t += "columns { ", t += e.columns.ac ? "ac { " + ci(e.columns.ac) + "} " : "ac null ", t += e.columns.dc ? "dc { " + ci(e.columns.dc) + "} " : "dc null ", t += e.columns.vehicleDc ? "vehicle_dc { " + ci(e.columns.vehicleDc) + "} " : "vehicle_dc null ", t += "} "), t;
}
function ui(e, t) {
	let n = t + "design {\n";
	if (e.counts.length > 0) {
		n += t + "  counts {\n";
		for (let r of e.counts) {
			let e = t + "    count " + r.context + " { min " + r.minCount + " ";
			r.clause && (e += "clause \"" + s(r.clause) + "\" "), r.note && (e += "note \"" + s(r.note) + "\" "), r.override && (e += "override { condition " + r.override.condition, e += " by " + r.override.by, r.override.note && (e += " note \"" + s(r.override.note) + "\""), e += " } "), n += e + "}\n";
		}
		n += t + "  }\n";
	}
	if (e.severities.length > 0) {
		n += t + "  severities {\n";
		for (let r of e.severities) {
			let e = t + "    severity \"" + s(r.row) + "\" { ";
			r.criterion && (e += "criterion " + r.criterion + " "), r.footnotes.length > 0 && (e += "footnotes { " + r.footnotes.join(" ") + " } ");
			for (let [t, n] of Object.entries(r.envClassValues)) e += "env " + t + " " + (n ? "{ " + li(n) + "}" : "null") + " ";
			n += e + "}\n";
		}
		n += t + "  }\n";
	}
	if (e.testPointsRef && (n += t + "  test_points { ref " + e.testPointsRef + " }\n"), e.schedule) {
		let r = e.schedule, i = t + "  schedule { ";
		if (r.duration && (i += "duration " + r.duration + " "), r.cadence && (i += "cadence " + r.cadence + " "), r.phases.length > 0) {
			i += "phases { ";
			for (let e of r.phases) i += "phase " + e.id + " { ", e.condition && (i += "condition \"" + s(e.condition) + "\" "), e.window && (i += "window " + e.window + " "), i += "} ";
			i += "} ";
		}
		r.constraints.length > 0 && (i += "constraints { " + r.constraints.map((e) => "\"" + s(e) + "\"").join(" ") + " } "), n += i + "}\n";
	}
	if (e.specimens) {
		let r = e.specimens, i = t + "  specimens { ";
		r.count !== null && (i += "count " + r.count + " "), r.maxAdditional !== null && (i += "max_additional " + r.maxAdditional + " "), r.selectionRef ? i += "selection { ref " + r.selectionRef + " } " : r.selection && (i += "selection \"" + s(r.selection) + "\" "), r.continuity && (i += "continuity " + r.continuity + " "), r.rules.length > 0 && (i += "rules { " + r.rules.join(" ") + " } "), n += i + "}\n";
	}
	if (e.field) {
		let r = e.field;
		if (n += t + "  field {\n", r.siteSelection && (n += t + "    site_selection \"" + s(r.siteSelection) + "\"\n"), r.trafficConditions && (n += t + "    traffic_conditions \"" + s(r.trafficConditions) + "\"\n"), r.referenceMeter) {
			let e = t + "    reference_meter { ";
			r.referenceMeter.description && (e += "description \"" + s(r.referenceMeter.description) + "\" "), r.referenceMeter.uncertaintyBudget && (e += "uncertainty_budget " + r.referenceMeter.uncertaintyBudget + " "), n += e + "}\n";
		}
		n += t + "  }\n";
	}
	if (e.simulation) {
		let r = e.simulation;
		n += t + "  simulation {\n", r.simulatorKind && (n += t + "    simulator_kind " + r.simulatorKind + "\n"), r.signal && (n += t + "    signal \"" + s(r.signal) + "\"\n"), r.uncertaintyBudget && (n += t + "    uncertainty_budget " + r.uncertaintyBudget + "\n"), r.validation && (n += t + "    validation \"" + s(r.validation) + "\"\n"), n += t + "  }\n";
	}
	if (e.software) {
		let r = e.software;
		if (n += t + "  software {\n", r.level && (n += t + "    level " + r.level + "\n"), r.items.length > 0) {
			n += t + "    items {\n";
			for (let e of r.items) {
				let r = t + "      item " + e.item + " { ";
				e.name && (r += "name \"" + s(e.name) + "\" "), e.d31 && (r += "d31 \"" + s(e.d31) + "\" "), e.obligation && (r += "obligation " + e.obligation + " "), e.methods.length > 0 && (r += "methods { " + e.methods.join(" ") + " } "), e.clause && (r += "clause \"" + s(e.clause) + "\" "), n += r + "}\n";
			}
			n += t + "    }\n";
		}
		n += t + "  }\n";
	}
	return n += t + "}\n", n;
}
//#endregion
//#region src/ser-des/config/competenceKind.ts
function di(e) {
	let t = a(e);
	return t.trim() !== "" && !isNaN(Number(t)) ? Number(t) : t;
}
function fi(e) {
	let t = {
		value: 0,
		unit: ""
	}, r = n(e), o = 0;
	for (; o < r.length;) {
		let e = r[o++];
		if (o >= r.length) break;
		e === "value" ? t.value = Number(a(r[o++])) : e === "unit" ? t.unit = a(r[o++]) : i(r[o++]);
	}
	return t;
}
function pi(e) {
	let t = [], r = n(e), o = 0;
	for (; o < r.length;) {
		if (r[o++] !== "competence") {
			o < r.length && i(r[o++]);
			continue;
		}
		let e = {
			kind: a(r[o++]),
			range: null,
			methodStandard: "",
			resolution: null,
			stability: null,
			description: ""
		};
		if (o < r.length && r[o].startsWith("{")) {
			let t = n(i(r[o++])), s = 0;
			for (; s < t.length;) {
				let r = t[s++];
				if (s >= t.length) break;
				if (r === "range") {
					let r = n(i(t[s++])), o = {
						min: null,
						max: null,
						unit: ""
					}, c = 0;
					for (; c < r.length;) {
						let e = r[c++];
						if (c >= r.length) break;
						e === "min" ? o.min = di(r[c++]) : e === "max" ? o.max = di(r[c++]) : e === "unit" ? o.unit = a(r[c++]) : i(r[c++]);
					}
					e.range = o;
				} else r === "method_standard" ? e.methodStandard = a(t[s++]) : r === "resolution" ? e.resolution = fi(i(t[s++])) : r === "stability" ? e.stability = fi(i(t[s++])) : r === "description" ? e.description = a(t[s++]) : i(t[s++]);
			}
		}
		t.push(e);
	}
	return t;
}
function mi(e, t) {
	return t ? "      " + e + " { value " + String(t.value) + " unit \"" + s(t.unit) + "\" }\n" : "";
}
function hi(e) {
	return e === null ? "" : typeof e == "number" ? String(e) : "\"" + s(e) + "\"";
}
function gi(e) {
	let t = "  required_competence {\n";
	for (let n of e) {
		if (t += "    competence " + n.kind + " {\n", n.range) {
			let e = "      range {";
			n.range.min !== null && (e += " min " + hi(n.range.min)), n.range.max !== null && (e += " max " + hi(n.range.max)), e += " unit \"" + s(n.range.unit) + "\" }\n", t += e;
		}
		n.methodStandard && (t += "      method_standard \"" + s(n.methodStandard) + "\"\n"), t += mi("resolution", n.resolution), t += mi("stability", n.stability), n.description && (t += "      description \"" + s(n.description) + "\"\n"), t += "    }\n";
	}
	return t += "  }\n", t;
}
function _i(e) {
	return e.length >= 2 && e.charAt(0) === "\"" && e.charAt(e.length - 1) === "\"" ? o(e.substr(1, e.length - 2)) : i(e);
}
var vi = function(e, t) {
	let n = {
		id: e,
		label: "",
		definition: "",
		source: null,
		methodStandards: []
	}, o = r(t), s = 0;
	for (; s < o.length;) {
		let t = o[s++];
		if (s >= o.length) throw Error(`Parsing error: competence_kind. ID ${e}: Expecting value for ${t}`);
		if (t === "label") n.label = _i(o[s++]);
		else if (t === "definition") n.definition = _i(o[s++]);
		else if (t === "source") n.source = I(i(o[s++]));
		else if (t === "method_standard") {
			let t = a(o[s++]);
			if (s >= o.length) throw Error(`Parsing error: competence_kind. ID ${e}: Expecting title for method_standard ${t}`);
			n.methodStandards.push({
				id: t,
				title: _i(o[s++])
			});
		} else if (t === "ref") {
			let e = S(o, s, a, i);
			T(n, e.ref) || (n.refs ??= []).push(e.ref), s = e.next;
		} else if (t === "corresponds") {
			let e = D(o, s, a);
			(n.correspondences ??= []).push(e.corr), s = e.next;
		} else s = y(o, s, t);
	}
	return (t) => (t.competenceKinds[e] = n, t);
}, yi = function(e) {
	let t = "competence_kind " + e.id + " {\n";
	e.label && (t += "  label \"" + s(e.label) + "\"\n"), e.definition && (t += "  definition \"" + s(e.definition) + "\"\n"), e.source && (e.source.doc || e.source.clause) && (t += "  source { doc \"" + s(e.source.doc) + "\" clause \"" + s(e.source.clause) + "\"" + (e.source.fragment ? " fragment \"" + s(e.source.fragment) + "\"" : "") + " }\n");
	for (let n of e.methodStandards) t += "  method_standard " + n.id + " \"" + s(n.title) + "\"\n";
	return t += k(e.correspondences, "  ", s, N), t += "}\n", t;
};
//#endregion
//#region src/ser-des/config/conformanceTest.ts
function V(e) {
	return n(a(e)).map(P).map(a).filter((e) => e.length > 0);
}
function bi(e) {
	return e.trim() !== "" && !isNaN(Number(e)) ? Number(e) : e;
}
function xi(e) {
	let t = [], r = n(e), o = 0;
	for (; o < r.length;) {
		if (r[o++] !== "variable") {
			o < r.length && i(r[o - 1]);
			continue;
		}
		let e = {
			name: a(r[o++]),
			type: "",
			unit: "",
			source: "",
			derivation: "",
			description: "",
			itemType: "",
			series: null,
			provenance: null
		};
		if (o < r.length && r[o].startsWith("{")) {
			let t = n(i(r[o++])), s = 0;
			for (; s < t.length;) {
				let r = t[s++];
				if (s >= t.length) break;
				if (r === "type") e.type = a(t[s++]);
				else if (r === "unit") e.unit = a(t[s++]);
				else if (r === "source") e.source = a(t[s++]);
				else if (r === "derivation") e.derivation = a(t[s++]);
				else if (r === "description") e.description = a(t[s++]);
				else if (r === "item_type") e.itemType = a(t[s++]);
				else if (r === "series") e.series = te(i(t[s++]));
				else if (r === "provenance") {
					let r = n(i(t[s++])), o = {
						channel: "",
						ref: "",
						observedAt: "",
						limitation: ""
					};
					for (let e = 0; e + 1 < r.length; e += 2) r[e] === "channel" ? o.channel = a(r[e + 1]) : r[e] === "ref" ? o.ref = a(r[e + 1]) : r[e] === "observed_at" ? o.observedAt = a(r[e + 1]) : r[e] === "limitation" && (o.limitation = a(r[e + 1]));
					e.provenance = o;
				} else i(t[s++]);
			}
		}
		t.push(e);
	}
	return t;
}
function Si(e) {
	let t = [], r = n(e), o = 0;
	for (; o < r.length;) {
		if (r[o++] !== "precondition") {
			o < r.length && i(r[o - 1]);
			continue;
		}
		let e = {
			id: a(r[o++]),
			check: "",
			description: "",
			onViolation: "invalid"
		};
		if (o < r.length && r[o].startsWith("{")) {
			let t = n(i(r[o++])), s = 0;
			for (; s < t.length;) {
				let n = t[s++];
				if (s >= t.length) break;
				n === "check" ? e.check = a(t[s++]) : n === "description" ? e.description = a(t[s++]) : n === "on_violation" ? e.onViolation = a(t[s++]) : n === "on_unresolvable" ? e.onUnresolvable = a(t[s++]) : i(t[s++]);
			}
		}
		t.push(e);
	}
	return t;
}
function Ci(e) {
	let t = [], r = n(e), o = 0;
	for (; o < r.length;) {
		if (r[o++] !== "observable") {
			o < r.length && i(r[o - 1]);
			continue;
		}
		let e = {
			name: a(r[o++]),
			quantityKind: "",
			unit: "",
			as: ""
		};
		if (o < r.length && r[o].startsWith("{")) {
			let t = n(i(r[o++])), s = 0;
			for (; s < t.length;) {
				let n = t[s++];
				if (s >= t.length) break;
				n === "quantity_kind" || n === "quantityKind" ? e.quantityKind = a(t[s++]) : n === "unit" ? e.unit = a(t[s++]) : n === "as" ? e.as = a(t[s++]) : i(t[s++]);
			}
		}
		t.push(e);
	}
	return t;
}
function wi(e, t) {
	let r = n(e), o = 0;
	for (; o < r.length;) {
		let e = r[o++];
		if (e === "type") {
			t.acceptanceCriteriaType = a(r[o++]);
			continue;
		}
		if (e === "description") {
			t.acceptanceCriteriaDescription = a(r[o++]);
			continue;
		}
		if (e === "pass_if") {
			t.acceptancePassIf = a(r[o++]);
			continue;
		}
		if (e !== "criterion" && e !== "item") {
			o < r.length && i(r[o - 1]);
			continue;
		}
		let s = "";
		o < r.length && !r[o].startsWith("{") && (s = a(r[o++]));
		let c = {
			item: s,
			passIf: "",
			requirementId: "",
			criterion: "",
			optional: !1,
			description: "",
			reference: "",
			sourceDiscrepancy: null
		};
		if (o < r.length && r[o].startsWith("{")) {
			let e = n(i(r[o++])), t = 0;
			for (; t < e.length;) {
				let r = e[t++];
				if (t >= e.length) break;
				if (r === "pass_if") c.passIf = a(e[t++]);
				else if (r === "requirement" || r === "target") c.requirementId = a(e[t++]);
				else if (r === "criterion") c.criterion = a(e[t++]);
				else if (r === "optional") c.optional = a(e[t++]) === "true";
				else if (r === "description") c.description = a(e[t++]);
				else if (r === "reference") c.reference = a(e[t++]);
				else if (r === "accepts") {
					let r = n(i(e[t++])), o = {
						verdict: "",
						op: "",
						limit: ""
					};
					for (let e = 0; e + 1 < r.length; e += 2) r[e] === "verdict" ? o.verdict = a(r[e + 1]) : r[e] === "op" ? o.op = a(r[e + 1]) : r[e] === "limit" && (o.limit = a(r[e + 1]));
					c.accepts = o;
				} else r === "source_discrepancy" ? c.sourceDiscrepancy = A(i(e[t++])) : i(e[t++]);
			}
		}
		t.acceptanceCriteria.push(c);
	}
}
function Ti(e) {
	let t = [], r = n(e), o = 0;
	for (; o < r.length;) {
		if (r[o++] !== "value") {
			o < r.length && i(r[o - 1]);
			continue;
		}
		let e = a(r[o++]), s = "";
		if (o < r.length && r[o].startsWith("{")) {
			let e = n(i(r[o++])), t = 0;
			for (; t < e.length;) {
				let n = e[t++];
				if (t >= e.length) break;
				n === "expression" ? s = a(e[t++]) : i(e[t++]);
			}
		}
		t.push({
			name: e,
			expression: s
		});
	}
	return t;
}
function Ei(e) {
	let t = {}, r = n(e), i = 0;
	for (; i < r.length;) {
		let e = P(r[i++]);
		if (i >= r.length) break;
		r[i] === ":" && i++, i < r.length && (t[e] = a(r[i++]));
	}
	return t;
}
function Di(e) {
	let t = {
		by: "",
		values: {}
	}, r = n(e), o = 0;
	for (; o < r.length;) {
		let e = r[o++];
		if (o >= r.length) break;
		if (e === "by") t.by = a(r[o++]);
		else if (e === "values") {
			let e = n(i(r[o++])), s = 0;
			for (; s < e.length;) {
				let r = P(e[s++]);
				if (s >= e.length) break;
				if (e[s] === ":" && s++, s < e.length && e[s].startsWith("{")) {
					let o = n(i(e[s++])), c = {}, l = 0;
					for (; l < o.length;) {
						let e = P(o[l++]);
						if (l >= o.length) break;
						o[l] === ":" && l++, l < o.length && (c[e] = bi(a(o[l++])));
					}
					t.values[r] = c;
				}
			}
		} else i(r[o++]);
	}
	return t;
}
function Oi(e) {
	let t = {}, r = n(e), i = 0;
	for (; i < r.length;) {
		let e = P(r[i++]);
		if (i >= r.length) break;
		if (r[i] === ":" && i++, i < r.length) {
			let n = M(r, i);
			t[e] = a(n.text), i = n.next;
		}
	}
	return t;
}
function ki(e) {
	let t = {
		read: "",
		tolerance: ""
	}, r = n(e), o = 0;
	for (; o < r.length;) {
		let e = r[o++];
		if (o >= r.length) break;
		e === "read" ? t.read = a(r[o++]) : e === "tolerance" ? t.tolerance = a(r[o++]) : i(r[o++]);
	}
	return t;
}
function Ai(e, t, r, o, s) {
	let c = {
		description: "",
		entries: [],
		sourceRefs: []
	}, l = n(e), u = 0;
	for (; u < l.length;) {
		let e = l[u++];
		if (u >= l.length) throw Error(`Parsing error: ${s}: Expecting value for ${e}`);
		if (e === "description") c.description = a(l[u++]);
		else if (e === "source") c.sourceRefs.push(I(i(l[u++])));
		else if (e === "ref") {
			let e = S(l, u, a, i);
			T(c, e.ref), u = e.next;
		} else if (e === t) {
			let e = r(), t = l[u++];
			t.startsWith("{") || (e.order = Number(a(t)), t = u < l.length && l[u].startsWith("{") ? l[u++] : ""), t.startsWith("{") && o(i(t), e), c.entries.push(e);
		} else u = y(l, u, e);
	}
	return c;
}
function ji(e, t) {
	return Ai(e, "step", () => ({
		order: null,
		action: "",
		drive: "",
		args: {},
		hold: "",
		verify: null
	}), (e, n) => {
		v(e, (e, t) => {
			if (e === "action") n.action = x(t);
			else if (e === "drive") n.drive = a(t());
			else if (e === "args") n.args = Oi(i(t()));
			else if (e === "hold") n.hold = a(t());
			else if (e === "verify") n.verify = ki(i(t()));
			else return !1;
			return !0;
		}, {
			construct: "conformance_test.preparation",
			id: t
		});
	}, `conformance_test.preparation. ID ${t}`);
}
function Mi(e, t) {
	return Ai(e, "point", () => ({
		order: null,
		drive: "",
		args: {},
		hold: "",
		freshWithin: "",
		acceptance: ""
	}), (e, n) => {
		v(e, (e, t) => {
			if (e === "drive") n.drive = a(t());
			else if (e === "args") n.args = Oi(i(t()));
			else if (e === "hold") n.hold = a(t());
			else if (e === "fresh_within") n.freshWithin = a(t());
			else if (e === "acceptance") n.acceptance = a(t());
			else return !1;
			return !0;
		}, {
			construct: "conformance_test.stimulus",
			id: t
		});
	}, `conformance_test.stimulus. ID ${t}`);
}
function Ni(e) {
	let t = Object.keys(e);
	return t.length === 0 ? "" : " args { " + t.map((t) => t + ": \"" + s(e[t]) + "\"").join(" ") + " }";
}
function Pi(e) {
	let t = "  preparation {\n";
	e.description !== "" && (t += "    description \"" + s(e.description) + "\"\n");
	for (let n of e.entries) t += "    step" + (n.order === null ? "" : " " + n.order) + " {", n.action !== "" && (t += " action \"" + s(n.action) + "\""), n.drive !== "" && (t += " drive " + N(n.drive)), t += Ni(n.args), n.hold !== "" && (t += " hold " + N(n.hold)), n.verify && (t += " verify {", n.verify.read !== "" && (t += " read " + N(n.verify.read)), n.verify.tolerance !== "" && (t += " tolerance " + N(n.verify.tolerance)), t += " }"), t += " }\n";
	for (let n of e.sourceRefs) t += E(n, "    ", s);
	return t + "  }\n";
}
function Fi(e) {
	let t = "  stimulus {\n";
	e.description !== "" && (t += "    description \"" + s(e.description) + "\"\n");
	for (let n of e.entries) t += "    point" + (n.order === null ? "" : " " + n.order) + " {", n.drive !== "" && (t += " drive " + N(n.drive)), t += Ni(n.args), n.hold !== "" && (t += " hold " + N(n.hold)), n.freshWithin !== "" && (t += " fresh_within " + N(n.freshWithin)), n.acceptance !== "" && (t += " acceptance " + N(n.acceptance)), t += " }\n";
	for (let n of e.sourceRefs) t += E(n, "    ", s);
	return t + "  }\n";
}
var Ii = function(e, t) {
	let o = {
		id: e,
		name: "",
		type: "",
		guidance: "",
		reference: "",
		targets: [],
		bindsTo: [],
		applicability: [],
		procedure: [],
		preparation: null,
		stimulus: null,
		measurements: [],
		kind: "",
		obligation: "",
		obligationNote: "",
		testSubject: {},
		variables: [],
		observables: [],
		conditionsToEnforce: [],
		preconditions: [],
		referenceMaterials: [],
		requiredCompetence: [],
		acceptanceCriteria: [],
		acceptanceCriteriaType: "",
		acceptanceCriteriaDescription: "",
		acceptancePassIf: "",
		design: null,
		acceptance: null,
		dependencies: [],
		instances: null,
		inheritsFrom: "",
		resultForms: [],
		derivedValues: [],
		sourceDiscrepancy: null,
		sourceRef: null
	};
	return v(t, (t, s, c) => {
		if (t === "name") o.name = x(s);
		else if (t === "purpose") o.purpose = x(s);
		else if (t === "method") o.method = x(s);
		else if (t === "method_ref") o.methodRef = a(s());
		else if (t === "guidance") o.guidance = x(s);
		else if (t === "type") o.type = s();
		else if (t === "reference") {
			let e = s();
			if (e.startsWith("{")) {
				let t = n(i(e));
				if (t.includes("doc") || t.includes("clause")) {
					let e = {
						doc: "",
						clause: ""
					};
					for (let n = 0; n + 1 < t.length; n += 2) t[n] === "doc" ? e.doc = a(t[n + 1]) : t[n] === "clause" ? e.clause = a(t[n + 1]) : t[n] === "fragment" && (e.fragment = a(t[n + 1]));
					o.sourceRef ||= e, (o.sourceRefs ??= []).push(e), o.reference ||= e.doc;
				} else o.sourceRef = null, o.sourceRefs = void 0, o.reference = i(e).trim();
			} else o.sourceRef = null, o.sourceRefs = void 0, o.reference = e;
		} else if (t === "targets") o.targets = r(s());
		else if (t === "ref") {
			let e = C(s, c, a, i);
			T(o, e) || (o.refs ??= []).push(e);
		} else if (t === "corresponds") (o.correspondences ??= []).push(O(s, c, a));
		else if (t === "binds_to") o.bindsTo = r(s());
		else if (t === "applicability") o.applicability = L(i(s()));
		else if (t === "procedure") {
			let e = r(s()), t = 0;
			for (; t < e.length;) {
				let n = parseInt(e[t], 10);
				if (!isNaN(n) && t + 1 < e.length) {
					let r = {
						order: n,
						action: x(() => e[t + 1]),
						outputs: []
					};
					t += 2, e[t] === "inputs" && t + 1 < e.length && (r.inputs = V(e[t + 1]), t += 2), e[t] === "outputs" && t + 1 < e.length && (r.outputs = V(e[t + 1]), t += 2), o.procedure.push(r);
				} else t++;
			}
		} else if (t === "procedure_steps") o.procedureSteps = V(s());
		else if (t === "preparation") o.preparation = ji(i(s()), e);
		else if (t === "stimulus") o.stimulus = Mi(i(s()), e);
		else if (t === "kind") o.kind = a(s());
		else if (t === "obligation") o.obligation = a(s());
		else if (t === "obligation_note") o.obligationNote = x(s);
		else if (t === "test_subject") o.testSubject = Ei(i(s()));
		else if (t === "variables") o.variables = xi(i(s()));
		else if (t === "observables") o.observables = Ci(i(s()));
		else if (t === "conditions_to_enforce" || t === "conditionsToEnforce") o.conditionsToEnforce = V(s());
		else if (t === "preconditions") o.preconditions = Si(i(s()));
		else if (t === "reference_materials") o.referenceMaterials = V(s());
		else if (t === "required_competence") o.requiredCompetence = pi(i(s()));
		else if (t === "acceptance_criteria") wi(i(s()), o);
		else if (t === "design") o.design = ii(i(s()));
		else if (t === "acceptance") o.acceptance = Yr(i(s()));
		else if (t === "dependencies") o.dependencies = V(s());
		else if (t === "instances") o.instances = Di(i(s()));
		else if (t === "inherits_from") o.inheritsFrom = a(s());
		else if (t === "result_forms") o.resultForms = V(s());
		else if (t === "produces_artifacts") o.producesArtifacts = V(s());
		else if (t === "report_rows") o.reportRows = V(s());
		else if (t === "derived_values") o.derivedValues = Ti(i(s()));
		else if (t === "validate_measurement") {
			let e = r(s());
			for (let t of e) t.startsWith("\"") && o.measurements.push(i(t));
		} else if (t === "source_discrepancy") o.sourceDiscrepancy = A(i(s()));
		else return !1;
		return !0;
	}, {
		construct: "conformance_test",
		id: e
	}), (t) => (t.conformanceTests[e] = o, t);
}, Li = function(e) {
	let t = "conformance_test " + e.id + " {\n";
	if (e.name && (t += "  name \"" + s(e.name) + "\"\n"), e.type && (t += "  type " + e.type + "\n"), e.purpose && (t += "  purpose \"" + s(e.purpose) + "\"\n"), e.method && (t += "  method \"" + s(e.method) + "\"\n"), e.methodRef && (t += "  method_ref " + e.methodRef + "\n"), e.guidance && (t += "  guidance \"" + s(e.guidance) + "\"\n"), e.sourceRefs && e.sourceRefs.length > 0) for (let n of e.sourceRefs) t += E(n, "  ", s);
	else e.sourceRef && e.sourceRef.doc ? t += E(e.sourceRef, "  ", s) : e.reference && (t += "  reference " + e.reference + "\n");
	for (let n of e.refs ?? []) t += "  ref " + n.predicate + " \"" + s(n.target) + "\"" + (n.note ? " { note \"" + s(n.note) + "\" }" : "") + "\n";
	if (e.targets.length > 0) {
		t += "  targets {\n";
		for (let n of e.targets) t += "    " + n + "\n";
		t += "  }\n";
	}
	if (e.bindsTo && e.bindsTo.length > 0) {
		t += "  binds_to {\n";
		for (let n of e.bindsTo) t += "    " + n + "\n";
		t += "  }\n";
	}
	if (e.applicability.length > 0 && (t += "  applicability {\n    " + R(e.applicability).trim() + "\n  }\n"), e.procedure.length > 0) {
		t += "  procedure {\n";
		for (let n of e.procedure) {
			let e = "    " + n.order + " \"" + s(n.action) + "\"";
			n.inputs && n.inputs.length > 0 && (e += " inputs { " + n.inputs.join(" ") + " }"), n.outputs.length > 0 && (e += " outputs { " + n.outputs.join(" ") + " }"), t += e + "\n";
		}
		t += "  }\n";
	}
	if (e.procedureSteps && e.procedureSteps.length > 0 && (t += "  procedure_steps { " + e.procedureSteps.join(" ") + " }\n"), e.preparation && (t += Pi(e.preparation)), e.stimulus && (t += Fi(e.stimulus)), e.measurements.length > 0) {
		t += "  validate_measurement {\n";
		for (let n of e.measurements) t += "    \"" + s(n) + "\"\n";
		t += "  }\n";
	}
	if (e.kind && (t += "  kind " + e.kind + "\n"), e.obligation && (t += "  obligation " + e.obligation + "\n"), e.obligationNote && (t += "  obligation_note \"" + s(e.obligationNote) + "\"\n"), Object.keys(e.testSubject).length > 0) {
		t += "  test_subject {\n";
		for (let [n, r] of Object.entries(e.testSubject)) t += "    " + n + ": \"" + s(r) + "\"\n";
		t += "  }\n";
	}
	if (e.variables.length > 0) {
		t += "  variables {\n";
		for (let n of e.variables) {
			let e = "    variable " + n.name + " { ";
			if (n.type && (e += "type " + n.type + " "), n.unit && (e += "unit \"" + s(n.unit) + "\" "), n.source && (e += "source " + n.source + " "), n.derivation && (e += "derivation \"" + s(n.derivation) + "\" "), n.description && (e += "description \"" + s(n.description) + "\" "), n.itemType && (e += "item_type \"" + s(n.itemType) + "\" "), n.series && (e += ne(n.series) + " "), n.provenance) {
				let t = "provenance { ";
				n.provenance.channel && (t += "channel " + n.provenance.channel + " "), n.provenance.ref && (t += "ref \"" + s(n.provenance.ref) + "\" "), n.provenance.observedAt && (t += "observed_at " + n.provenance.observedAt + " "), n.provenance.limitation && (t += "limitation \"" + s(n.provenance.limitation) + "\" "), e += t + "} ";
			}
			t += e + "}\n";
		}
		t += "  }\n";
	}
	if (e.observables.length > 0) {
		t += "  observables {\n";
		for (let n of e.observables) {
			let e = "    observable " + n.name + " { ";
			n.quantityKind && (e += "quantity_kind " + n.quantityKind + " "), n.unit && (e += "unit \"" + s(n.unit) + "\" "), n.as && (e += "as \"" + s(n.as) + "\" "), t += e + "}\n";
		}
		t += "  }\n";
	}
	if (e.conditionsToEnforce.length > 0 && (t += "  conditions_to_enforce { " + e.conditionsToEnforce.join(" ") + " }\n"), e.preconditions.length > 0) {
		t += "  preconditions {\n";
		for (let n of e.preconditions) {
			let e = "    precondition " + n.id + " { ";
			n.check && (e += "check \"" + s(n.check) + "\" "), n.description && (e += "description \"" + s(n.description) + "\" "), e += "on_violation " + n.onViolation + " ", n.onUnresolvable && (e += "on_unresolvable " + n.onUnresolvable + " "), t += e + "}\n";
		}
		t += "  }\n";
	}
	if (e.referenceMaterials.length > 0 && (t += "  reference_materials { " + e.referenceMaterials.join(" ") + " }\n"), e.requiredCompetence.length > 0 && (t += gi(e.requiredCompetence)), e.acceptanceCriteria.length > 0 || e.acceptanceCriteriaType || e.acceptancePassIf) {
		t += "  acceptance_criteria {\n", e.acceptanceCriteriaType && (t += "    type " + e.acceptanceCriteriaType + "\n"), e.acceptanceCriteriaDescription && (t += "    description \"" + s(e.acceptanceCriteriaDescription) + "\"\n"), e.acceptancePassIf && (t += "    pass_if \"" + s(e.acceptancePassIf) + "\"\n");
		for (let n of e.acceptanceCriteria) {
			let e = "    criterion " + (n.item || "\"\"") + " { ";
			n.passIf && (e += "pass_if \"" + s(n.passIf) + "\" "), n.requirementId && (e += "requirement " + n.requirementId + " "), n.criterion && (e += "criterion " + n.criterion + " "), n.optional && (e += "optional true "), n.description && (e += "description \"" + s(n.description) + "\" "), n.reference && (e += "reference \"" + s(n.reference) + "\" "), n.accepts && (e += "accepts { verdict " + n.accepts.verdict + " op " + n.accepts.op + " limit \"" + s(n.accepts.limit) + "\" } "), n.sourceDiscrepancy && (e += j(n.sourceDiscrepancy, "") + " "), t += e + "}\n";
		}
		t += "  }\n";
	}
	if (e.design && (t += ui(e.design, "  ")), e.acceptance && (t += Xr(e.acceptance, "  ") + "\n"), e.dependencies.length > 0 && (t += "  dependencies { " + e.dependencies.join(" ") + " }\n"), e.instances) {
		let n = "  instances { by " + e.instances.by + " values { ";
		for (let [t, r] of Object.entries(e.instances.values)) {
			n += t + " { ";
			for (let [e, t] of Object.entries(r)) n += e + ": " + t + " ";
			n += "} ";
		}
		t += n + "} }\n";
	}
	if (e.inheritsFrom && (t += "  inherits_from " + e.inheritsFrom + "\n"), e.resultForms.length > 0 && (t += "  result_forms { " + e.resultForms.join(" ") + " }\n"), e.producesArtifacts && e.producesArtifacts.length > 0 && (t += "  produces_artifacts { " + e.producesArtifacts.join(" ") + " }\n"), e.reportRows && e.reportRows.length > 0 && (t += "  report_rows { " + e.reportRows.join(" ") + " }\n"), e.derivedValues.length > 0) {
		t += "  derived_values {\n";
		for (let n of e.derivedValues) t += "    value " + n.name + " { expression \"" + s(n.expression) + "\" }\n";
		t += "  }\n";
	}
	return e.sourceDiscrepancy && (t += j(e.sourceDiscrepancy, "  ") + "\n"), t += k(e.correspondences, "  ", s, N), t += "}\n", t;
}, Ri = {
	aliases: "aliases",
	alt: "aliases",
	colloquial: "colloquial",
	abbreviations: "abbreviations",
	deprecated: "deprecated"
};
function zi(e) {
	return e in Ri;
}
function Bi(e, t, n) {
	if (t === "aliases") {
		let t = [...e.aliases ?? [], ...n];
		e.aliases = t, e.alt = t;
	} else (e[t] ??= []).push(...n);
}
var Vi = function(e, t) {
	let n = {
		id: e,
		label: "",
		definition: "",
		symbolId: "",
		referenceIds: [],
		ref: []
	};
	return v(t, (t, o, s) => {
		if (t === "ref") {
			let e = C(o, s, a, i);
			return e.predicate === "derives-from" && !n.source ? n.source = e.target : e.predicate === "cites" ? n.referenceIds.push(e.target) : (n.refs ??= []).push(e), !0;
		}
		if (t === "corresponds") return (n.correspondences ??= []).push(O(o, s, a)), !0;
		if (t === "label") n.label = x(o);
		else if (t === "definition") n.definition = x(o);
		else if (t === "symbol") n.symbolId = a(o());
		else if (t === "reference") n.referenceIds = r(o());
		else if (t === "vocab_ref") {
			let e = r(o()), t = {
				register: "",
				clause: ""
			};
			for (let n = 0; n + 1 < e.length; n += 2) e[n] === "register" && (t.register = a(e[n + 1])), e[n] === "clause" && (t.clause = a(e[n + 1]));
			n.vocabRef = t;
		} else if (t === "vocab_term") n.vocabTerm = a(o());
		else if (t === "section") n.section = x(o);
		else if (t === "note") n.note = x(o);
		else if (t === "source") n.source = x(o);
		else if (t === "overlay") n.overlay = o() === "true";
		else if (t === "scope_note") n.scopeNote = x(o);
		else if (t === "language") n.language = x(o);
		else if (t === "form_type") n.formType = x(o);
		else if (t === "part_of_speech") n.partOfSpeech = x(o);
		else if (zi(t)) {
			let i = o(), c, l = i;
			if (!i.startsWith("{")) {
				c = i;
				let n = s();
				if (n === void 0 || !n.startsWith("{")) throw Error(`Parsing error: term. ID ${e}: alias-family facet "${t}" with spelling code "${c}" expects a list block`);
				l = o();
			}
			let u = r(l).map(a), d = Ri[t];
			if (c === void 0) Bi(n, d, u);
			else {
				let e = (n.aliasSpellings ??= {})[c] ??= {};
				(e[d] ??= []).push(...u);
			}
		} else if (t === "see_also") n.seeAlso = r(o()).map(a);
		else return !1;
		return !0;
	}, {
		construct: "term",
		id: e
	}), (t) => (t.terms[e] = n, t);
}, Hi = function(e) {
	let t = "term " + e.id + " {\n";
	e.label && (t += "  label \"" + s(e.label) + "\"\n"), e.definition && (t += "  definition \"" + s(e.definition) + "\"\n"), e.symbolId && (t += "  symbol " + e.symbolId + "\n"), e.vocabRef && (t += "  vocab_ref { register " + e.vocabRef.register + " clause \"" + s(e.vocabRef.clause) + "\" }\n"), e.vocabTerm && (t += "  vocab_term \"" + s(e.vocabTerm) + "\"\n"), e.section && (t += "  section \"" + s(e.section) + "\"\n"), e.note && (t += "  note \"" + s(e.note) + "\"\n"), e.source && (t += "  source \"" + s(e.source) + "\"\n"), e.overlay && (t += "  overlay true\n"), e.scopeNote && (t += "  scope_note \"" + s(e.scopeNote) + "\"\n"), e.language && (t += "  language \"" + s(e.language) + "\"\n"), e.formType && (t += "  form_type \"" + s(e.formType) + "\"\n"), e.partOfSpeech && (t += "  part_of_speech \"" + s(e.partOfSpeech) + "\"\n");
	let n = (e) => /\s/.test(e) ? "\"" + s(e) + "\"" : e, r = (e, t, r) => "  " + e + (r ? " " + r : "") + " { " + t.map(n).join(" ") + " }\n", i = e.aliases ?? e.alt;
	i && i.length > 0 && (t += r("aliases", i)), e.colloquial && e.colloquial.length > 0 && (t += r("colloquial", e.colloquial)), e.abbreviations && e.abbreviations.length > 0 && (t += r("abbreviations", e.abbreviations)), e.deprecated && e.deprecated.length > 0 && (t += r("deprecated", e.deprecated));
	for (let n of Object.keys(e.aliasSpellings ?? {}).sort()) {
		let i = e.aliasSpellings[n];
		for (let e of [
			"aliases",
			"colloquial",
			"abbreviations",
			"deprecated"
		]) {
			let a = i[e];
			a && a.length > 0 && (t += r(e, a, n));
		}
	}
	if (e.seeAlso && e.seeAlso.length > 0 && (t += "  see_also { " + e.seeAlso.map(n).join(" ") + " }\n"), e.referenceIds.length > 0) {
		t += "  reference {\n";
		for (let n of e.referenceIds) t += "    " + n + "\n";
		t += "  }\n";
	}
	return t += k(e.correspondences, "  ", s, N), t += "}\n", t;
}, Ui = [
	"none",
	"max",
	"mean",
	"worst_case",
	"max_abs_over_window"
];
function Wi(e) {
	return n(a(e)).map(P).map(a).filter((e) => e.length > 0);
}
var Gi = function(e, t) {
	let r = {
		id: e,
		quantityKind: "",
		unit: "",
		derive: "",
		inputs: [],
		seriesReduction: null,
		acceptance: null,
		source: null
	};
	return v(t, (t, o, s) => {
		if (t === "quantity") {
			let e = n(i(o())), t = 0;
			for (; t < e.length;) {
				let n = e[t++];
				if (t >= e.length) break;
				n === "kind" ? r.quantityKind = a(e[t++]) : n === "unit" ? r.unit = a(e[t++]) : i(e[t++]);
			}
		} else if (t === "symbol") r.symbol = x(o);
		else if (t === "behavior") r.behavior = o();
		else if (t === "derive" || t === "expression") r.derive = x(o);
		else if (t === "inputs" || t === "uses") r.inputs = Wi(o());
		else if (t === "series_reduction") {
			let t = o();
			if (!Ui.includes(t)) throw Error(`Parsing error: verdict. ID ${e}: Unknown series_reduction ${t} (valid: ${Ui.join(", ")})`);
			r.seriesReduction = t;
		} else if (t === "acceptance") r.acceptance = Yr(i(o()));
		else if (t === "source" || t === "reference") {
			let e = I(i(o()));
			(r.sourceRefs ??= []).push(e), r.source ||= e;
		} else if (t === "ref") {
			let e = C(o, s, a, i);
			T(r, e) || (r.refs ??= []).push(e);
		} else if (t === "corresponds") (r.correspondences ??= []).push(O(o, s, a));
		else return !1;
		return !0;
	}, {
		construct: "verdict",
		id: e
	}), (t) => (t.verdicts[e] = r, t);
}, Ki = function(e) {
	let t = "verdict " + e.id + " {\n";
	e.symbol && (t += "  symbol \"" + s(e.symbol) + "\"\n"), e.behavior && (t += "  behavior " + e.behavior + "\n"), e.quantityKind && (t += "  quantity { kind " + e.quantityKind, e.unit && (t += " unit \"" + s(e.unit) + "\""), t += " }\n"), e.derive && (t += "  derive \"" + s(e.derive) + "\"\n"), e.inputs.length > 0 && (t += "  inputs { " + e.inputs.join(" ") + " }\n"), e.seriesReduction && (t += "  series_reduction " + e.seriesReduction + "\n"), e.acceptance && (t += Xr(e.acceptance, "  ") + "\n");
	let n = e.sourceRefs && e.sourceRefs.length > 0 ? e.sourceRefs : e.source && (e.source.doc || e.source.clause) ? [e.source] : [];
	for (let e of n) t += E(e, "  ", s);
	return t += w(e.refs, "  ", s), t += k(e.correspondences, "  ", s, N), t += "}\n", t;
};
//#endregion
//#region src/ser-des/config/referenceMaterial.ts
function qi(e) {
	let t = [], r = n(e), o = 0;
	for (; o < r.length;) {
		if (r[o++] !== "field") {
			o < r.length && i(r[o - 1]);
			continue;
		}
		let e = {
			name: a(r[o++]),
			description: "",
			unit: "",
			type: "",
			required: !1
		};
		if (o < r.length && r[o].startsWith("{")) {
			let t = n(i(r[o++])), s = 0;
			for (; s < t.length;) {
				let n = t[s++];
				if (s >= t.length) break;
				n === "description" ? e.description = a(t[s++]) : n === "unit" ? e.unit = a(t[s++]) : n === "type" ? e.type = a(t[s++]) : n === "required" ? e.required = a(t[s++]) === "true" : s = y(t, s, n);
			}
		}
		t.push(e);
	}
	return t;
}
function Ji(e) {
	let t = [], r = n(e), o = 0;
	for (; o < r.length;) {
		if (r[o++] !== "constraint") {
			o < r.length && i(r[o - 1]);
			continue;
		}
		let e = {
			id: a(r[o++]),
			description: "",
			rule: "",
			evidence: {},
			override: null,
			onViolation: "",
			source: null
		};
		if (o < r.length && r[o].startsWith("{")) {
			let t = n(i(r[o++])), s = 0;
			for (; s < t.length;) {
				let r = t[s++];
				if (s >= t.length) break;
				if (r === "description") e.description = a(t[s++]);
				else if (r === "rule") e.rule = a(t[s++]);
				else if (r === "evidence") {
					let r = n(i(t[s++])), o = 0;
					for (; o < r.length;) {
						let t = P(r[o++]);
						if (o >= r.length) break;
						r[o] === ":" && o++, o < r.length && (e.evidence[t] = a(r[o++]));
					}
				} else if (r === "override") {
					let r = n(i(t[s++])), o = {
						rule: "",
						by: "",
						evidence: ""
					}, c = 0;
					for (; c < r.length;) {
						let e = r[c++];
						if (c >= r.length) break;
						e === "rule" ? o.rule = a(r[c++]) : e === "by" ? o.by = a(r[c++]) : e === "evidence" ? o.evidence = a(r[c++]) : i(r[c++]);
					}
					e.override = o;
				} else if (r === "on_violation") e.onViolation = a(t[s++]);
				else if (r === "source") e.source = I(i(t[s++]));
				else if (r === "ref") {
					let n = S(t, s, a, i);
					if (s = n.next, n.ref.predicate === "derives-from" && !e.source) {
						let t = ee(n.ref.target);
						t && (e.source = t);
					}
				} else s = y(t, s, r);
			}
		}
		t.push(e);
	}
	return t;
}
var Yi = function(e, t) {
	let n = {
		id: e,
		kind: "",
		name: "",
		definition: "",
		source: null,
		identityFields: [],
		constraints: []
	};
	return v(t, (e, t, r) => {
		if (e === "kind") n.kind = a(t());
		else if (e === "name") n.name = x(t);
		else if (e === "definition") n.definition = x(t);
		else if (e === "source") {
			let e = I(i(t()));
			(n.sourceRefs ??= []).push(e), n.source ||= e;
		} else if (e === "ref") {
			let e = C(t, r, a, i);
			T(n, e) || (n.refs ??= []).push(e);
		} else if (e === "corresponds") (n.correspondences ??= []).push(O(t, r, a));
		else if (e === "identity_fields") n.identityFields = qi(i(t()));
		else if (e === "constraints") n.constraints = Ji(i(t()));
		else return !1;
		return !0;
	}, {
		construct: "reference_material",
		id: e
	}), (t) => (t.referenceMaterials[e] = n, t);
}, Xi = function(e) {
	let t = "reference_material " + e.id + " {\n";
	e.kind && (t += "  kind " + e.kind + "\n"), e.name && (t += "  name \"" + s(e.name) + "\"\n"), e.definition && (t += "  definition \"" + s(e.definition) + "\"\n");
	let n = e.sourceRefs && e.sourceRefs.length > 0 ? e.sourceRefs : e.source ? [e.source] : [];
	for (let e of n) t += E(e, "  ", s);
	if (t += w(e.refs, "  ", s), t += k(e.correspondences, "  ", s, N), e.identityFields.length > 0) {
		t += "  identity_fields {\n";
		for (let n of e.identityFields) {
			let e = "    field " + n.name + " { ";
			n.description && (e += "description \"" + s(n.description) + "\" "), n.unit && (e += "unit \"" + s(n.unit) + "\" "), n.type && (e += "type " + n.type + " "), n.required && (e += "required true "), t += e + "}\n";
		}
		t += "  }\n";
	}
	if (e.constraints.length > 0) {
		t += "  constraints {\n";
		for (let n of e.constraints) {
			t += "    constraint " + n.id + " {\n", n.description && (t += "      description \"" + s(n.description) + "\"\n"), n.rule && (t += "      rule \"" + s(n.rule) + "\"\n");
			let e = Object.keys(n.evidence);
			e.length > 0 && (t += "      evidence { " + e.map((e) => e + ": " + n.evidence[e]).join(" ") + " }\n"), n.override && (t += "      override { rule \"" + s(n.override.rule) + "\"", t += " by " + n.override.by, n.override.evidence && (t += " evidence " + n.override.evidence), t += " }\n"), n.onViolation && (t += "      on_violation " + n.onViolation + "\n"), n.source && (n.source.doc || n.source.clause) && (t += E(n.source, "      ", s)), t += "    }\n";
		}
		t += "  }\n";
	}
	return t += "}\n", t;
}, Zi = [
	"common",
	"determination",
	"attestation",
	"surveillance"
], Qi = [
	"product_type",
	"batch",
	"ongoing_production",
	"service_or_process"
];
function $i(e) {
	return r(i(e)).map(P).map(a).filter((e) => e.length > 0);
}
var ea = (e, t) => {
	let n = {
		id: e,
		family: "common",
		row: "",
		label: "",
		source: {
			doc: "",
			clause: ""
		}
	};
	return v(t, (t, r) => {
		if (t === "family") {
			let t = a(r());
			if (!Zi.includes(t)) throw Error(`Parsing error: scheme_activity_kind. ID ${e}: Unknown family "${t}" (valid: ${Zi.join(", ")})`);
			n.family = t;
		} else if (t === "row") n.row = a(r());
		else if (t === "label") n.label = a(r());
		else if (t === "source") n.source = I(i(r()));
		else return !1;
		return !0;
	}, {
		construct: "scheme_activity_kind",
		id: e
	}), (t) => (t.schemeActivityKinds[e] = n, t);
};
function ta(e) {
	let t = {
		required: !1,
		activities: []
	};
	return v(e, (e, n) => {
		if (e === "required") t.required = a(n()) === "true";
		else if (e === "activities") t.activities = $i(n());
		else return !1;
		return !0;
	}, {
		construct: "scheme_type surveillance",
		id: ""
	}), t;
}
var na = (e, t) => {
	let n = {
		id: e,
		label: "",
		clause: "",
		description: "",
		sampling: "",
		attestationObject: "",
		determination: [],
		attestation: [],
		surveillance: null,
		notes: [],
		source: {
			doc: "",
			clause: ""
		}
	};
	return v(t, (t, o) => {
		if (t === "label") n.label = a(o());
		else if (t === "clause") n.clause = a(o());
		else if (t === "description") n.description = a(o());
		else if (t === "sampling") n.sampling = a(o());
		else if (t === "attestation_object") {
			let t = a(o());
			if (!Qi.includes(t)) throw Error(`Parsing error: scheme_type. ID ${e}: Unknown attestation_object "${t}" (valid: ${Qi.join(", ")})`);
			n.attestationObject = t;
		} else if (t === "determination") n.determination = $i(o());
		else if (t === "attestation") n.attestation = $i(o());
		else if (t === "surveillance") n.surveillance = ta(i(o()));
		else if (t === "notes") n.notes = r(i(o())).map(a).filter((e) => e.length > 0);
		else if (t === "source") n.source = I(i(o()));
		else return !1;
		return !0;
	}, {
		construct: "scheme_type",
		id: e
	}), (t) => (t.schemeTypes[e] = n, t);
};
function ra(e, t) {
	if (!e.doc && !e.clause) return "";
	let n = t + "source {\n";
	return e.doc && (n += t + "  doc \"" + s(e.doc) + "\"\n"), e.clause && (n += t + "  clause \"" + s(e.clause) + "\"\n"), n += t + "}\n", n;
}
var ia = function(e) {
	let t = "scheme_activity_kind " + e.id + " {\n";
	return t += "  family " + e.family + "\n", e.row && (t += "  row \"" + s(e.row) + "\"\n"), e.label && (t += "  label \"" + s(e.label) + "\"\n"), t += ra(e.source, "  "), t += "}\n", t;
}, aa = function(e) {
	let t = "scheme_type " + e.id + " {\n";
	if (e.label && (t += "  label \"" + s(e.label) + "\"\n"), e.clause && (t += "  clause \"" + s(e.clause) + "\"\n"), e.description && (t += "  description \"" + s(e.description) + "\"\n"), e.sampling && (t += "  sampling \"" + s(e.sampling) + "\"\n"), e.attestationObject && (t += "  attestation_object " + e.attestationObject + "\n"), e.determination.length > 0 && (t += "  determination { " + e.determination.map(N).join(" ") + " }\n"), e.attestation.length > 0 && (t += "  attestation { " + e.attestation.map(N).join(" ") + " }\n"), e.surveillance && (t += "  surveillance {\n", t += "    required " + (e.surveillance.required ? "true" : "false") + "\n", e.surveillance.activities.length > 0 && (t += "    activities { " + e.surveillance.activities.map(N).join(" ") + " }\n"), t += "  }\n"), e.notes.length > 0) {
		t += "  notes {\n";
		for (let n of e.notes) t += "    \"" + s(n) + "\"\n";
		t += "  }\n";
	}
	return t += ra(e.source, "  "), t += "}\n", t;
}, oa = function(e, t) {
	let n = {
		id: e,
		kind: "",
		description: "",
		subjectKinds: [],
		targetKinds: [],
		resolution: "",
		inverse: "",
		transitive: !1,
		symmetric: !1
	}, o = r(t), s = 0;
	for (; s < o.length;) {
		let t = o[s++];
		if (s >= o.length) throw Error(`Parsing error: predicate. ID ${e}: Expecting value for ${t}`);
		if (t === "kind") {
			let t = a(o[s++]);
			if (t !== "citation" && t !== "semantic") throw Error(`Parsing error: predicate. ID ${e}: kind must be citation|semantic (got '${t}')`);
			n.kind = t;
		} else t === "description" || t === "definition" ? n.description = a(o[s++]) : t === "subject_kinds" ? n.subjectKinds = r(i(o[s++])).map(a) : t === "target_kinds" ? n.targetKinds = r(i(o[s++])).map(a) : t === "resolution" ? n.resolution = a(o[s++]) : t === "inverse" ? n.inverse = a(o[s++]) : t === "transitive" ? n.transitive = a(o[s++]) === "true" : t === "symmetric" ? n.symmetric = a(o[s++]) === "true" : s++;
	}
	return (t) => (t.predicates ??= {}, t.predicates[e] = n, t);
}, sa = function(e) {
	let t = "predicate " + e.id + " {\n";
	return e.kind && (t += "  kind " + e.kind + "\n"), e.description && (t += "  description \"" + s(e.description) + "\"\n"), e.subjectKinds.length > 0 && (t += "  subject_kinds { " + e.subjectKinds.join(" ") + " }\n"), e.targetKinds.length > 0 && (t += "  target_kinds { " + e.targetKinds.join(" ") + " }\n"), e.resolution && (t += "  resolution " + e.resolution + "\n"), e.inverse && (t += "  inverse " + e.inverse + "\n"), e.transitive && (t += "  transitive true\n"), e.symmetric && (t += "  symmetric true\n"), t += "}\n", t;
};
//#endregion
//#region src/ser-des/config/constraint.ts
function ca(e) {
	return e.length >= 2 && e.charAt(0) === "\"" && e.charAt(e.length - 1) === "\"" ? o(e.substr(1, e.length - 2)) : i(e);
}
var la = function(e, t) {
	let n = {
		id: e,
		stereotype: "",
		name: "",
		check: "",
		violationMeaning: "",
		onViolation: "invalid",
		source: null
	}, o = r(t), s = 0;
	for (; s < o.length;) {
		let t = o[s++];
		if (s >= o.length) throw Error(`Parsing error: constraint. ID ${e}: Expecting value for ${t}`);
		if (t === "stereotype") n.stereotype = a(o[s++]);
		else if (t === "name") n.name = ca(o[s++]);
		else if (t === "check") n.check = ca(o[s++]);
		else if (t === "violation_meaning") n.violationMeaning = ca(o[s++]);
		else if (t === "on_violation") n.onViolation = a(o[s++]);
		else if (t === "source") n.source = I(i(o[s++]));
		else if (t === "ref") {
			let e = S(o, s, a, i);
			T(n, e.ref) || (n.refs ??= []).push(e.ref), s = e.next;
		} else if (t === "corresponds") {
			let e = D(o, s, a);
			(n.correspondences ??= []).push(e.corr), s = e.next;
		} else s = y(o, s, t);
	}
	return (t) => (t.constraints[e] = n, t);
}, ua = function(e) {
	let t = "constraint " + e.id + " {\n";
	return e.stereotype && (t += "  stereotype " + e.stereotype + "\n"), e.name && (t += "  name \"" + s(e.name) + "\"\n"), e.check && (t += "  check \"" + s(e.check) + "\"\n"), e.violationMeaning && (t += "  violation_meaning \"" + s(e.violationMeaning) + "\"\n"), t += "  on_violation " + (e.onViolation || "invalid") + "\n", e.source && (e.source.doc || e.source.clause) && (t += "  source { doc \"" + s(e.source.doc) + "\" clause \"" + s(e.source.clause) + "\"" + (e.source.fragment ? " fragment \"" + s(e.source.fragment) + "\"" : "") + " }\n"), t += k(e.correspondences, "  ", s, N), t += "}\n", t;
}, da = ["open", "resolved"], fa = function(e, t) {
	let i = {
		id: e,
		status: "",
		summary: "",
		sources: [],
		resolution: "",
		governing: "",
		rationale: ""
	}, o = r(t), s = 0;
	for (; s < o.length;) {
		let t = o[s++];
		if (s >= o.length) throw Error(`Parsing error: discrepancy_record. ID ${e}: Expecting value for ${t}`);
		if (t === "status") {
			let t = a(o[s++]);
			if (!da.includes(t)) throw Error(`Parsing error: discrepancy_record. ID ${e}: Unknown status ${t} (valid: ${da.join(", ")})`);
			i.status = t;
		} else if (t === "summary") i.summary = a(o[s++]);
		else if (t === "sources") i.sources = n(a(o[s++])).map(a).filter((e) => e.length > 0);
		else if (t === "resolution") {
			let t = a(o[s++]);
			if (!re.includes(t)) throw Error(`Parsing error: discrepancy_record. ID ${e}: Unknown resolution ${t} (valid: ${re.join(", ")})`);
			i.resolution = t;
		} else t === "governing" ? i.governing = a(o[s++]) : t === "rationale" ? i.rationale = a(o[s++]) : s++;
	}
	return (t) => (t.discrepancyRecords[e] = i, t);
}, pa = function(e) {
	let t = "discrepancy_record " + e.id + " {\n";
	return e.status && (t += "  status " + e.status + "\n"), e.summary && (t += "  summary \"" + s(e.summary) + "\"\n"), t += "  sources { " + e.sources.map((e) => "\"" + s(e) + "\"").join(" ") + " }\n", e.resolution && (t += "  resolution " + e.resolution + "\n"), e.governing && (t += "  governing \"" + s(e.governing) + "\"\n"), e.rationale && (t += "  rationale \"" + s(e.rationale) + "\"\n"), t += "}\n", t;
};
//#endregion
//#region src/ser-des/config/testPointSet.ts
function ma(e) {
	let t = {}, r = n(e), o = 0;
	for (; o < r.length;) {
		let e = P(r[o++]);
		if (!e) break;
		if (o < r.length && r[o] === ":" && o++, o < r.length && r[o].startsWith("{")) {
			let s = n(i(r[o++])), c = {
				minPoints: null,
				rule: ""
			}, l = 0;
			for (; l < s.length;) {
				let e = s[l++];
				if (l >= s.length) break;
				e === "min_points" ? c.minPoints = Number(a(s[l++])) : e === "rule" ? c.rule = a(s[l++]) : i(s[l++]);
			}
			t[e] = c;
		}
	}
	return t;
}
function ha(e) {
	let t = [], r = n(e), o = 0;
	for (; o < r.length;) {
		if (r[o++] !== "point") {
			o < r.length && i(r[o - 1]);
			continue;
		}
		let e = {
			id: a(r[o++]),
			fraction: null,
			anchor: "",
			offset: ""
		};
		if (o < r.length && r[o].startsWith("{")) {
			let t = n(i(r[o++])), s = 0;
			for (; s < t.length;) {
				let n = t[s++];
				if (s >= t.length) break;
				n === "fraction" ? e.fraction = Number(a(t[s++])) : n === "anchor" ? e.anchor = a(t[s++]) : n === "offset" ? e.offset = a(t[s++]) : i(t[s++]);
			}
		}
		t.push(e);
	}
	return t;
}
var ga = function(e, t) {
	let n = {
		id: e,
		description: "",
		source: null,
		cardinality: {},
		repetitionsPerPoint: null,
		points: []
	};
	return v(t, (e, t, r) => {
		if (e === "description") n.description = x(t);
		else if (e === "source") {
			let e = I(i(t()));
			(n.sourceRefs ??= []).push(e), n.source ||= e;
		} else if (e === "ref") {
			let e = C(t, r, a, i);
			T(n, e) || (n.refs ??= []).push(e);
		} else if (e === "corresponds") (n.correspondences ??= []).push(O(t, r, a));
		else if (e === "cardinality") n.cardinality = ma(i(t()));
		else if (e === "repetitions_per_point") n.repetitionsPerPoint = Number(a(t()));
		else if (e === "points") n.points = ha(i(t()));
		else return !1;
		return !0;
	}, {
		construct: "test_point_set",
		id: e
	}), (t) => (t.testPointSets[e] = n, t);
}, _a = function(e) {
	let t = "test_point_set " + e.id + " {\n";
	e.description && (t += "  description \"" + s(e.description) + "\"\n");
	let n = e.sourceRefs && e.sourceRefs.length > 0 ? e.sourceRefs : e.source && (e.source.doc || e.source.clause) ? [e.source] : [];
	for (let e of n) t += E(e, "  ", s);
	t += w(e.refs, "  ", s), t += k(e.correspondences, "  ", s, N);
	let r = Object.keys(e.cardinality);
	if (r.length > 0) {
		t += "  cardinality {\n";
		for (let n of r) {
			let r = e.cardinality[n], i = "    " + n + " { ";
			r.minPoints !== null && (i += "min_points " + r.minPoints + " "), r.rule && (i += "rule \"" + s(r.rule) + "\" "), t += i + "}\n";
		}
		t += "  }\n";
	}
	if (e.repetitionsPerPoint !== null && (t += "  repetitions_per_point " + e.repetitionsPerPoint + "\n"), e.points.length > 0) {
		t += "  points {\n";
		for (let n of e.points) {
			let e = "    point " + n.id + " { ";
			n.fraction !== null && (e += "fraction " + n.fraction + " "), n.anchor && (e += "anchor " + n.anchor + " "), n.offset && (e += "offset \"" + s(n.offset) + "\" "), t += e + "}\n";
		}
		t += "  }\n";
	}
	return t += "}\n", t;
}, va = (e, t) => {
	let n = {
		id: e,
		title: "",
		reference: "",
		description: "",
		source: null
	};
	return v(t, (e, t) => {
		if (e === "title") n.title = a(t());
		else if (e === "reference") n.reference = a(t());
		else if (e === "description") n.description = a(t());
		else if (e === "source") n.source = I(i(t()));
		else return !1;
		return !0;
	}, {
		construct: "common_test_condition",
		id: e
	}), (t) => (t.commonTestConditions[e] = n, t);
}, ya = function(e) {
	let t = "common_test_condition " + e.id + " {\n";
	return e.title && (t += "  title \"" + s(e.title) + "\"\n"), e.reference && (t += "  reference \"" + s(e.reference) + "\"\n"), e.description && (t += "  description \"" + s(e.description) + "\"\n"), e.source && (e.source.doc || e.source.clause) && (t += "  source {\n", e.source.doc && (t += "    doc \"" + s(e.source.doc) + "\"\n"), e.source.clause && (t += "    clause \"" + s(e.source.clause) + "\"\n"), t += "  }\n"), t += "}\n", t;
};
//#endregion
//#region src/ser-des/config/requirement.ts
function H(e) {
	return n(a(e)).map(P).map(a).filter((e) => e.length > 0);
}
function ba(e) {
	let t = {
		verdict: "",
		op: "",
		limit: "",
		sourceDiscrepancy: null
	}, r = n(e), o = 0;
	for (; o < r.length;) {
		let e = r[o++];
		if (o >= r.length) break;
		e === "verdict" ? t.verdict = a(r[o++]) : e === "op" ? t.op = a(r[o++]) : e === "limit" ? t.limit = a(r[o++]) : e === "source_discrepancy" ? t.sourceDiscrepancy = A(i(r[o++])) : o = y(r, o, e);
	}
	return t;
}
function xa(e) {
	let t = {
		expression: "",
		uses: [],
		modality: "",
		relativeTo: "",
		notes: "",
		accepts: null,
		quantity: null,
		acceptance: null,
		sourceDiscrepancy: null
	}, r = n(e), o = 0;
	for (; o < r.length;) {
		let e = r[o++];
		if (o >= r.length) break;
		if (e === "expression") t.expression = a(r[o++]);
		else if (e === "uses") t.uses = H(r[o++]);
		else if (e === "modality") t.modality = a(r[o++]);
		else if (e === "relative_to") t.relativeTo = a(r[o++]);
		else if (e === "notes") t.notes = a(r[o++]);
		else if (e === "quantity") {
			let e = {
				kind: "",
				unit: ""
			}, s = n(i(r[o++])), c = 0;
			for (; c < s.length;) {
				let t = s[c++];
				if (c >= s.length) break;
				t === "kind" ? e.kind = a(s[c++]) : t === "unit" ? e.unit = a(s[c++]) : i(s[c++]);
			}
			t.quantity = e;
		} else e === "accepts" ? t.accepts = ba(i(r[o++])) : e === "acceptance" ? t.acceptance = Yr(i(r[o++])) : e === "source_discrepancy" ? t.sourceDiscrepancy = A(i(r[o++])) : o = y(r, o, e);
	}
	return t;
}
function Sa(e) {
	let t = [], r = n(e), o = 0;
	for (; o < r.length;) {
		if (r[o++] !== "subject") {
			o < r.length && i(r[o - 1]);
			continue;
		}
		let e = {
			slot: Number(a(r[o++])),
			entityId: "",
			label: ""
		};
		if (o < r.length && r[o].startsWith("{")) {
			let t = n(i(r[o++])), s = 0;
			for (; s < t.length;) {
				let n = t[s++];
				if (s >= t.length) break;
				n === "entity_id" ? e.entityId = a(t[s++]) : n === "label" ? e.label = a(t[s++]) : i(t[s++]);
			}
		}
		t.push(e);
	}
	return t;
}
function Ca(e) {
	let t = [], r = n(e), o = 0;
	for (; o < r.length;) {
		if (r[o++] !== "param") {
			o < r.length && i(r[o - 1]);
			continue;
		}
		let e = {
			name: P(a(r[o++])),
			type: "",
			description: "",
			unit: "",
			defaultValue: "",
			hasDefault: !1,
			rangeMin: "",
			rangeMax: "",
			hasRange: !1,
			enumValues: [],
			bind: ""
		};
		if (o < r.length && !r[o].startsWith("{") && (e.type = a(r[o++])), o < r.length && r[o].startsWith("{")) {
			let t = n(i(r[o++])), s = 0;
			for (; s < t.length;) {
				let r = t[s++];
				if (s >= t.length) break;
				if (r === "description") e.description = a(t[s++]);
				else if (r === "unit") e.unit = a(t[s++]);
				else if (r === "bind") e.bind = a(t[s++]);
				else if (r === "default") e.defaultValue = a(t[s++]), e.hasDefault = !0;
				else if (r === "range") {
					let r = n(i(t[s++])), o = 0;
					for (; o < r.length;) {
						let t = r[o++];
						if (o >= r.length) break;
						t === "min" ? (e.rangeMin = a(r[o++]), e.hasRange = !0) : t === "max" ? (e.rangeMax = a(r[o++]), e.hasRange = !0) : i(r[o++]);
					}
				} else r === "enum_values" ? e.enumValues = H(t[s++]) : i(t[s++]);
			}
		}
		t.push(e);
	}
	return t;
}
var wa = function(e, t) {
	let o = {
		id: e,
		name: "",
		statement: "",
		guidance: "",
		bindsTo: [],
		limit: null,
		applicability: [],
		channel: "",
		subjects: [],
		parameters: [],
		obligation: "",
		acceptanceCriteria: "",
		verificationMethod: "",
		dependencies: [],
		sourceDiscrepancy: null,
		source: null,
		referenceIds: []
	}, s = r(t), c = 0;
	for (; c < s.length;) {
		let e = s[c++];
		if (c >= s.length) break;
		if (e === "name") o.name = a(s[c++]);
		else if (e === "statement") o.statement = a(s[c++]);
		else if (e === "guidance") o.guidance = a(s[c++]);
		else if (e === "binds_to") o.bindsTo = H(s[c++]);
		else if (e === "subjects") o.subjects = Sa(i(s[c++]));
		else if (e === "parameters") o.parameters = Ca(i(s[c++]));
		else if (e === "limit") o.limit = xa(i(s[c++]));
		else if (e === "applicability") o.applicability = L(i(s[c++]));
		else if (e === "channel") o.channel = a(s[c++]);
		else if (e === "report_row") o.reportRow = a(s[c++]);
		else if (e === "obligation") o.obligation = a(s[c++]);
		else if (e === "acceptance_criteria") o.acceptanceCriteria = i(s[c++]).trim();
		else if (e === "verification") {
			let e = n(i(s[c++])), t = 0;
			for (; t < e.length;) {
				let n = e[t++];
				if (t >= e.length) break;
				n === "method" ? o.verificationMethod = a(e[t++]) : n === "description" ? o.verificationDescription = a(e[t++]) : i(e[t++]);
			}
		} else if (e === "dependencies") o.dependencies = H(s[c++]);
		else if (e === "source_discrepancy") o.sourceDiscrepancy = A(i(s[c++]));
		else if (e === "source" || e === "reference") {
			let e = I(i(s[c++]));
			o.source ||= e, (o.sourceRefs ??= []).push(e);
		} else if (e === "ref") {
			let e = S(s, c, a, i);
			T(o, e.ref) || (o.refs ??= []).push(e.ref), c = e.next;
		} else if (e === "corresponds") {
			let e = D(s, c, a);
			(o.correspondences ??= []).push(e.corr), c = e.next;
		} else c = y(s, c, e);
	}
	return (t) => (t.requirements[e] = o, t);
};
function Ta(e) {
	let t = "  limit {\n";
	if (e.expression && (t += "    expression \"" + s(e.expression) + "\"\n"), e.uses.length > 0 && (t += "    uses { " + e.uses.join(" ") + " }\n"), e.modality && (t += "    modality " + e.modality + "\n"), e.relativeTo && (t += "    relative_to " + e.relativeTo + "\n"), e.notes && (t += "    notes \"" + s(e.notes) + "\"\n"), e.quantity) {
		let n = "    quantity {";
		e.quantity.kind && (n += " kind " + e.quantity.kind), e.quantity.unit && (n += " unit \"" + s(e.quantity.unit) + "\""), t += n + " }\n";
	}
	if (e.accepts) {
		let n = e.accepts, r = "    accepts { verdict " + n.verdict;
		n.op && (r += " op " + n.op), n.limit && (r += " limit \"" + s(n.limit) + "\""), n.sourceDiscrepancy && (r += " " + j(n.sourceDiscrepancy, "")), t += r + " }\n";
	}
	return e.acceptance && (t += Xr(e.acceptance, "    ") + "\n"), e.sourceDiscrepancy && (t += j(e.sourceDiscrepancy, "    ") + "\n"), t += "  }\n", t;
}
var Ea = function(e) {
	let t = "requirement " + e.id + " {\n";
	if (e.name && (t += "  name \"" + s(e.name) + "\"\n"), e.statement && (t += "  statement \"" + s(e.statement) + "\"\n"), e.guidance && (t += "  guidance \"" + s(e.guidance) + "\"\n"), e.bindsTo.length > 0 && (t += "  binds_to { " + e.bindsTo.join(" ") + " }\n"), e.subjects.length > 0) {
		t += "  subjects { ";
		for (let n of e.subjects) t += "subject " + n.slot + " { ", n.entityId && (t += "entity_id \"" + s(n.entityId) + "\" "), n.label && (t += "label \"" + s(n.label) + "\" "), t += "} ";
		t += "}\n";
	}
	if (e.parameters.length > 0) {
		t += "  parameters {\n";
		for (let n of e.parameters) {
			let e = "    param " + n.name + ": " + n.type + " { ";
			n.description && (e += "description \"" + s(n.description) + "\" "), n.unit && (e += "unit \"" + s(n.unit) + "\" "), n.bind && (e += "bind \"" + s(n.bind) + "\" "), n.hasDefault && (e += "default " + N(n.defaultValue) + " "), n.hasRange && (e += "range { ", n.rangeMin && (e += "min " + N(n.rangeMin) + " "), n.rangeMax && (e += "max " + N(n.rangeMax) + " "), e += "} "), n.enumValues.length > 0 && (e += "enum_values { " + n.enumValues.join(" ") + " } "), t += e + "}\n";
		}
		t += "  }\n";
	}
	if (e.limit && (t += Ta(e.limit)), e.applicability.length > 0 && (t += "  applicability {\n    " + R(e.applicability).trim() + "\n  }\n"), e.channel && (t += "  channel " + e.channel + "\n"), e.reportRow && (t += "  report_row " + e.reportRow + "\n"), e.obligation && (t += "  obligation " + e.obligation + "\n"), e.acceptanceCriteria && (t += "  acceptance_criteria {\n    " + e.acceptanceCriteria + "\n  }\n"), e.verificationMethod) {
		let n = "  verification { method " + e.verificationMethod;
		e.verificationDescription && (n += " description \"" + s(e.verificationDescription) + "\""), t += n + " }\n";
	}
	e.dependencies.length > 0 && (t += "  dependencies { " + e.dependencies.join(" ") + " }\n"), e.sourceDiscrepancy && (t += j(e.sourceDiscrepancy, "  ") + "\n");
	for (let n of e.sourceRefs ?? (e.source && (e.source.doc || e.source.clause) ? [e.source] : [])) t += E(n, "  ", s);
	for (let n of e.refs ?? []) t += "  ref " + n.predicate + " \"" + s(n.target) + "\"" + (n.note ? " { note \"" + s(n.note) + "\" }" : "") + "\n";
	return t += k(e.correspondences, "  ", s, N), t += "}\n", t;
}, Da = function(e, t) {
	let n = {
		id: e,
		name: "",
		subject: "",
		guidance: "",
		dependencies: [],
		referenceIds: []
	}, o = r(t), s = 0;
	for (; s < o.length;) {
		let e = o[s++];
		if (s >= o.length) break;
		e === "name" ? n.name = a(o[s++]) : e === "title" ? n.title = a(o[s++]) : e === "description" ? n.description = a(o[s++]) : e === "subject" ? n.subject = a(o[s++]) : e === "guidance" ? n.guidance = a(o[s++]) : e === "applicability" ? n.applicability = L(i(o[s++])) : e === "dependencies" ? n.dependencies = H(o[s++]) : e === "reference" ? n.referenceIds = H(o[s++]) : s = y(o, s, e);
	}
	return (t) => (t.requirementClasses[e] = n, t);
}, Oa = function(e) {
	let t = "requirement_class " + e.id + " {\n";
	return e.name && (t += "  name \"" + s(e.name) + "\"\n"), e.subject && (t += "  subject \"" + s(e.subject) + "\"\n"), e.guidance && (t += "  guidance \"" + s(e.guidance) + "\"\n"), e.applicability && e.applicability.length > 0 && (t += "  applicability {\n    " + R(e.applicability).trim() + "\n  }\n"), e.dependencies.length > 0 && (t += "  dependencies { " + e.dependencies.join(" ") + " }\n"), e.referenceIds.length > 0 && (t += "  reference { " + e.referenceIds.join(" ") + " }\n"), t += "}\n", t;
}, ka = {
	keyword: "requirement",
	field: "requirements",
	takesID: !0,
	parse: wa,
	dump: Ea
}, Aa = {
	keyword: "requirement_class",
	field: "requirementClasses",
	takesID: !0,
	parse: Da,
	dump: Oa
};
//#endregion
//#region src/ser-des/config/packageManifest.ts
function U(e) {
	return n(a(e)).map(a).filter((e) => e.length > 0);
}
var ja = [
	"core",
	"module",
	"rec",
	"product_reference",
	"certification_program"
], Ma = [
	"current",
	"preview",
	"superseded",
	"withdrawn"
];
function Na(e) {
	return e.startsWith("{") ? U(e) : [a(e)];
}
var Pa = function(e) {
	let t = {
		id: "",
		title: "",
		version: "",
		editions: [],
		baseUrn: "",
		extends: "",
		description: "",
		source: null
	}, r = n(e);
	r[0] === "package" && (r = r.slice(1)), r[0] && r[0].startsWith("{") && (r = n(i(r[0])));
	let o = 0;
	for (; o < r.length;) {
		let e = r[o++];
		if (o >= r.length) break;
		if (e === "id") t.id = a(r[o++]);
		else if (e === "title") t.title = a(r[o++]);
		else if (e === "version") t.version = a(r[o++]);
		else if (e === "editions") t.editions = U(r[o++]);
		else if (e === "baseUrn" || e === "base_urn") t.baseUrn = a(r[o++]);
		else if (e === "extends") t.extends = a(r[o++]);
		else if (e === "uses") {
			let e = [], n = {};
			for (let t of U(r[o++])) {
				let r = t.indexOf("@");
				if (r === -1) {
					e.push(t);
					continue;
				}
				let i = t.slice(0, r), a = t.slice(r + 1);
				if (!i || !a || a.includes("@")) throw Error(`Parsing error: package: malformed uses entry "${t}" — the version-pin form is <package-id>@<edition>`);
				e.push(i), i in n || (n[i] = a);
			}
			t.uses = e, Object.keys(n).length > 0 && (t.usePins = n);
		} else if (e === "kind") {
			let e = a(r[o++]);
			if (!ja.includes(e)) throw Error(`Parsing error: package: Expected kind ${ja.join("|")}, got "${e}"`);
			t.kind = e;
		} else if (e === "manufacturer") t.manufacturer = a(r[o++]);
		else if (e === "product") t.product = a(r[o++]);
		else if (e === "maps_to" || e === "mapsTo") t.mapsTo = U(r[o++]);
		else if (e === "ref") {
			let e = S(r, o, a, i);
			T(t, e.ref) || (t.refs ??= []).push(e.ref), o = e.next;
		} else if (e === "corresponds") {
			let e = D(r, o, a);
			(t.correspondences ??= []).push(e.corr), o = e.next;
		} else if (e === "scheme_type" || e === "schemeType") t.schemeType = a(r[o++]);
		else if (e === "license_key" || e === "licenseKey") t.licenseKey !== void 0 && (t.licenseKeyDuplicates ??= []).push(t.licenseKey), t.licenseKey = a(r[o++]);
		else if (e === "license_holder" || e === "licenseHolder") t.licenseHolder = a(r[o++]);
		else if (e === "provides") t.provides = U(r[o++]);
		else if (e === "requires") t.requires = U(r[o++]);
		else if (e === "waives") t.waives = U(r[o++]);
		else if (e === "supersedes") t.supersedes = Na(r[o++]);
		else if (e === "replaces") t.replaces = Na(r[o++]);
		else if (e === "superseded_by") t.supersededBy = Na(r[o++]);
		else if (e === "validity") {
			let e = n(i(r[o++])), s = { from: "" }, c = 0;
			for (; c < e.length;) {
				let t = e[c++];
				if (c >= e.length) break;
				t === "from" ? s.from = a(e[c++]) : t === "to" ? s.to = a(e[c++]) : i(e[c++]);
			}
			t.validity = s;
		} else if (e === "status") {
			let e = a(r[o++]);
			if (!Ma.includes(e)) throw Error(`Parsing error: package: Expected status ${Ma.join("|")}, got "${e}"`);
			t.status = e;
		} else if (e === "default_spelling" || e === "defaultSpelling") t.defaultSpelling = a(r[o++]);
		else if (e === "spellings") t.spellings = U(r[o++]);
		else if (e === "description") t.description = a(r[o++]);
		else if (e === "source") {
			let e = {
				collection: "",
				parts: []
			}, s = n(i(r[o++])), c = 0;
			for (; c < s.length;) {
				let t = s[c++];
				if (c >= s.length) break;
				t === "collection" ? e.collection = a(s[c++]) : t === "parts" ? e.parts = U(s[c++]) : i(s[c++]);
			}
			t.source = e;
		} else o = y(r, o, e);
	}
	return (e) => (e.packageManifest = t, e);
};
function Fa(e) {
	let t = "package {\n";
	e.id && (t += "  id " + e.id + "\n"), e.kind && (t += "  kind " + e.kind + "\n"), e.manufacturer && (t += "  manufacturer \"" + e.manufacturer.replace(/\\/g, "\\\\").replace(/"/g, "\\\"") + "\"\n"), e.product && (t += "  product \"" + e.product.replace(/\\/g, "\\\\").replace(/"/g, "\\\"") + "\"\n"), e.mapsTo && e.mapsTo.length > 0 && (t += "  maps_to { " + e.mapsTo.join(" ") + " }\n");
	for (let n of e.refs ?? []) t += "  ref " + n.predicate + " \"" + n.target.replace(/\\/g, "\\\\").replace(/"/g, "\\\"") + "\"" + (n.note ? " { note \"" + n.note.replace(/\\/g, "\\\\").replace(/"/g, "\\\"") + "\" }" : "") + "\n";
	return t += k(e.correspondences, "  ", s, N), e.schemeType && (t += "  scheme_type " + e.schemeType + "\n"), e.licenseKey && (t += "  license_key \"" + e.licenseKey.replace(/\\/g, "\\\\").replace(/"/g, "\\\"") + "\"\n"), e.licenseHolder && (t += "  license_holder \"" + e.licenseHolder.replace(/\\/g, "\\\\").replace(/"/g, "\\\"") + "\"\n"), e.title && (t += "  title \"" + e.title.replace(/\\/g, "\\\\").replace(/"/g, "\\\"") + "\"\n"), e.version && (t += "  version \"" + e.version + "\"\n"), e.editions.length > 0 && (t += "  editions { " + e.editions.join(" ") + " }\n"), e.baseUrn && (t += "  baseUrn \"" + e.baseUrn + "\"\n"), e.extends && (t += "  extends " + e.extends + "\n"), e.uses && e.uses.length > 0 && (t += "  uses { " + e.uses.map((t) => e.usePins?.[t] ? `${t}@${e.usePins[t]}` : t).join(" ") + " }\n"), e.provides && e.provides.length > 0 && (t += "  provides { " + e.provides.join(" ") + " }\n"), e.requires && e.requires.length > 0 && (t += "  requires { " + e.requires.join(" ") + " }\n"), e.waives && e.waives.length > 0 && (t += "  waives { " + e.waives.join(" ") + " }\n"), e.supersedes && e.supersedes.length > 0 && (t += "  supersedes { " + e.supersedes.join(" ") + " }\n"), e.replaces && e.replaces.length > 0 && (t += "  replaces { " + e.replaces.join(" ") + " }\n"), e.supersededBy && e.supersededBy.length > 0 && (t += "  superseded_by { " + e.supersededBy.join(" ") + " }\n"), e.validity && e.validity.from && (t += "  validity { from " + e.validity.from + (e.validity.to ? " to " + e.validity.to : "") + " }\n"), e.status && (t += "  status " + e.status + "\n"), e.defaultSpelling && (t += "  default_spelling " + e.defaultSpelling + "\n"), e.spellings && e.spellings.length > 0 && (t += "  spellings { " + e.spellings.join(" ") + " }\n"), e.description && (t += "  description \"" + e.description.replace(/\\/g, "\\\\").replace(/"/g, "\\\"") + "\"\n"), e.source && (t += "  source { collection \"" + e.source.collection + "\" parts { " + e.source.parts.join(" ") + " } }\n"), t += "}\n", t;
}
var Ia = {
	keyword: "conformance_class",
	field: "conformanceClasses",
	takesID: !0,
	parse: function(e, t) {
		let o = {
			id: e,
			name: "",
			title: "",
			description: "",
			target: "",
			subject: "",
			applicability: [],
			guidance: "",
			dependencies: [],
			referenceIds: []
		}, s = r(t), c = 0;
		for (; c < s.length;) {
			let e = s[c++];
			if (c >= s.length) break;
			e === "name" ? o.name = a(s[c++]) : e === "title" ? o.title = a(s[c++]) : e === "description" ? o.description = a(s[c++]) : e === "target" ? o.target = a(s[c++]) : e === "subject" ? o.subject = a(s[c++]) : e === "applicability" ? o.applicability = L(i(s[c++])) : e === "test_subject" ? o.testSubject = Ei(i(s[c++])) : e === "guidance" ? o.guidance = a(s[c++]) : e === "dependencies" ? o.dependencies = n(a(s[c++])).map(a) : e === "reference" ? o.referenceIds = n(a(s[c++])).map(a) : c = y(s, c, e);
		}
		return (t) => (t.conformanceClasses[e] = o, t);
	},
	dump: function(e) {
		let t = "conformance_class " + e.id + " {\n";
		if (e.title && (t += "  title \"" + s(e.title) + "\"\n"), e.name && (t += "  name \"" + s(e.name) + "\"\n"), e.target && (t += "  target " + e.target + "\n"), e.subject && (t += "  subject \"" + s(e.subject) + "\"\n"), e.description && (t += "  description \"" + s(e.description) + "\"\n"), e.applicability.length > 0 && (t += "  applicability {\n    " + R(e.applicability).trim() + "\n  }\n"), e.guidance && (t += "  guidance \"" + s(e.guidance) + "\"\n"), e.testSubject && Object.keys(e.testSubject).length > 0) {
			t += "  test_subject {\n";
			for (let [n, r] of Object.entries(e.testSubject)) t += "    " + n + ": \"" + s(r) + "\"\n";
			t += "  }\n";
		}
		return e.dependencies.length > 0 && (t += "  dependencies { " + e.dependencies.join(" ") + " }\n"), e.referenceIds.length > 0 && (t += "  reference { " + e.referenceIds.join(" ") + " }\n"), t += "}\n", t;
	}
}, La = [
	"query",
	"subscribe",
	"invoke"
], Ra = [
	"public",
	"registered",
	"authority"
], za = /* @__PURE__ */ new Set([
	"kind",
	"serves",
	"does",
	"payload"
]);
function Ba(e, t) {
	let r = e[t] ?? "";
	if (r.startsWith("{")) return {
		names: n(i(r)).flatMap((e) => e.split(",")).map((e) => a(e.trim())).filter((e) => e.length > 0),
		next: t + 1
	};
	let o = [], s = t;
	for (; s < e.length && !za.has(e[s]) && !e[s].startsWith("{");) {
		for (let t of e[s].split(",")) {
			let e = a(t.trim());
			e && o.push(e);
		}
		s++;
	}
	return {
		names: o,
		next: s
	};
}
function Va(e, t) {
	let r = {
		name: e,
		kind: "",
		serves: [],
		does: [],
		payload: null
	}, o = n(t), s = 0;
	for (; s < o.length;) {
		let e = o[s++];
		if (s > o.length) break;
		if (e === "kind") r.kind = a(o[s++] ?? "");
		else if (e === "serves") {
			let e = Ba(o, s);
			r.serves = e.names, s = e.next;
		} else if (e === "does") {
			let e = Ba(o, s);
			r.does = e.names, s = e.next;
		} else if (e === "payload") {
			let e = n(i(o[s++] ?? "")), t = {
				quantityKind: "",
				unit: "",
				timestamp: !1
			}, c = 0;
			for (; c < e.length;) {
				let n = P(e[c++]);
				if (c >= e.length) break;
				n === "quantity_kind" ? t.quantityKind = a(e[c++]) : n === "unit" ? t.unit = a(e[c++]) : n === "timestamp" ? t.timestamp = a(e[c++]) === "true" : i(e[c++]);
			}
			r.payload = t;
		} else i(o[s++] ?? "");
	}
	return r;
}
function Ha(e) {
	let t = {}, r = n(e), o = 0;
	for (; o < r.length;) {
		let e = P(r[o++]);
		if (!e) break;
		if (o < r.length && r[o].startsWith("{")) {
			let s = n(i(r[o++])).map((e) => a(e)).filter((e) => e.length > 0);
			t[e] = [...t[e] ?? [], ...s];
		}
	}
	return t;
}
function Ua(e, t) {
	let r = {
		id: e,
		operations: [],
		access: {},
		profile: ""
	}, o = n(t), s = 0;
	for (; s < o.length;) {
		let e = o[s++];
		if (s > o.length) break;
		if (e === "operation") {
			let e = P(o[s++] ?? ""), t = s < o.length ? i(o[s++]) : "";
			e && r.operations.push(Va(e, t));
		} else e === "access" ? r.access = Ha(i(o[s++] ?? "")) : e === "profile" ? r.profile = a(o[s++] ?? "") : i(o[s++] ?? "");
	}
	return r;
}
function Wa(e, t) {
	let n = t + "operation " + N(e.name) + " {";
	return e.kind && (n += " kind " + N(e.kind)), e.serves.length > 0 && (n += " serves { " + e.serves.map(N).join(" ") + " }"), e.does.length > 0 && (n += " does { " + e.does.map(N).join(" ") + " }"), e.payload && (n += " payload { quantity_kind " + N(e.payload.quantityKind) + " unit " + N(e.payload.unit) + " timestamp " + (e.payload.timestamp ? "true" : "false") + " }"), n + " }\n";
}
function Ga(e, t) {
	let n = t + "endpoint " + N(e.id) + " {\n";
	for (let r of e.operations) n += Wa(r, t + "  ");
	let r = Ra.filter((t) => (e.access[t] ?? []).length > 0), i = Object.keys(e.access).filter((e) => !Ra.includes(e));
	if (r.length + i.length > 0) {
		n += t + "  access {";
		for (let t of [...r, ...i]) n += " " + t + " { " + (e.access[t] ?? []).map(N).join(" ") + " }";
		n += " }\n";
	}
	return e.profile && (n += t + "  profile " + N(e.profile) + "\n"), n + t + "}\n";
}
function Ka(e, t) {
	let r = {
		aspect: "",
		via: "",
		freshWithin: ""
	};
	if (r.aspect = a(e[t++] ?? ""), e[t] === "via" && (t++, r.via = a(e[t++] ?? "")), t < e.length && e[t].startsWith("{")) {
		let o = n(i(e[t++])), s = 0;
		for (; s < o.length;) {
			let e = o[s++];
			if (s >= o.length) break;
			e === "fresh_within" ? r.freshWithin = a(o[s++]) : i(o[s++]);
		}
	}
	return {
		binding: r,
		next: t
	};
}
function qa(e, t) {
	let n = t + "serve " + N(e.aspect) + " via " + N(e.via);
	return e.freshWithin && (n += " { fresh_within " + N(e.freshWithin) + " }"), n + "\n";
}
var Ja = {
	keyword: "connector_profile",
	field: "connectorProfiles",
	takesID: !0,
	parse: function(e, t) {
		let o = {
			id: e,
			protocol: "",
			description: "",
			referenceIds: []
		}, s = r(t), c = 0;
		for (; c < s.length;) {
			let e = s[c++];
			if (c >= s.length) break;
			e === "protocol" ? o.protocol = a(s[c++]) : e === "description" ? o.description = a(s[c++]) : e === "reference" ? o.referenceIds = n(i(s[c++])).map((e) => a(e)).filter((e) => e.length > 0) : i(s[c++]);
		}
		return (t) => (t.connectorProfiles[e] = o, t);
	},
	dump: function(e) {
		let t = "connector_profile " + e.id + " {\n";
		return e.protocol && (t += "  protocol \"" + s(e.protocol) + "\"\n"), e.description && (t += "  description \"" + s(e.description) + "\"\n"), e.referenceIds.length > 0 && (t += "  reference { " + e.referenceIds.join(" ") + " }\n"), t += "}\n", t;
	}
};
//#endregion
//#region src/ser-des/config/composition.ts
function Ya(e, t) {
	let r = {
		id: e,
		product: "",
		endpoint: "",
		serial: "",
		certificate: null
	}, o = n(t), s = 0;
	for (; s < o.length;) {
		let e = o[s++];
		if (e === "product") r.product = a(o[s++] ?? "");
		else if (e === "endpoint") r.endpoint = a(o[s++] ?? "");
		else if (e === "serial") r.serial = a(o[s++] ?? "");
		else if (e === "certificate") {
			let e = a(o[s++] ?? "");
			r.certificate = e === "null" ? null : e;
		} else i(o[s++] ?? "");
	}
	return r;
}
function Xa(e) {
	let t = [];
	for (let n of e.split("\n")) {
		let e = n.trim();
		if (!e) continue;
		let r = /^(\S+)\s*->\s*rule\s+(\S+)\s*$/.exec(e);
		if (r) {
			t.push({
				register: r[1],
				component: "composite",
				rule: r[2]
			});
			continue;
		}
		let i = /^(\S+)\s*->\s*(\S+)\.(\S+)\s*$/.exec(e);
		i && t.push({
			register: i[1],
			component: i[2],
			componentRegister: i[3]
		});
	}
	return t;
}
function Za(e) {
	let t = {
		components: [],
		decomposition: []
	}, n = r(e), a = 0;
	for (; a < n.length;) {
		let e = n[a++];
		if (e === "component") {
			let e = n[a++] ?? "", r = a < n.length ? i(n[a++]) : "";
			e && t.components.push(Ya(e, r));
		} else if (e === "decomposition") t.decomposition = Xa(i(n[a++] ?? ""));
		else if (e === "revision") {
			let e = Number(n[a++] ?? "");
			Number.isFinite(e) && (t.revision = e);
		} else i(n[a++] ?? "");
	}
	return t;
}
function Qa(e, t) {
	let n = t + "component " + N(e.id) + " {\n";
	return n += t + "  product " + N(e.product) + "\n", n += t + "  endpoint " + N(e.endpoint) + "\n", n += t + "  serial " + s(e.serial) + "\n", n += t + "  certificate " + (e.certificate === null ? "null" : s(e.certificate)) + "\n", n + t + "}\n";
}
function $a(e, t) {
	let n = t + "composed_of {\n";
	for (let r of e.components) n += Qa(r, t + "  ");
	if (e.decomposition.length > 0) {
		n += t + "  decomposition {\n";
		for (let r of e.decomposition) n += t + "    " + N(r.register) + " -> " + (r.component === "composite" ? "rule " + N(r.rule ?? "") : N(r.component) + "." + N(r.componentRegister ?? "")) + "\n";
		n += t + "  }\n";
	}
	return e.revision !== void 0 && (n += t + "  revision " + String(e.revision) + "\n"), n + t + "}\n";
}
//#endregion
//#region src/ser-des/config/subject.ts
function W(e, t, n) {
	if (!t || !t.doc && !t.clause) return "";
	let r = t.fragment ? ` fragment "${s(t.fragment)}"` : "";
	return `${n}${e} { doc "${s(t.doc)}" clause "${s(t.clause)}"${r} }\n`;
}
function G(e) {
	return n(a(e)).map(P).map(a).filter((e) => e.length > 0);
}
function K(e, t, n) {
	return t.length === 0 ? "" : `${n}${e} { ${t.join(" ")} }\n`;
}
function q(e) {
	return n(a(e)).map(a).filter((e) => e.length > 0);
}
var eo = function(e, t) {
	let o = {
		id: e,
		extends: "",
		definition: "",
		variants: [],
		dimensions: [],
		perChannel: "",
		familyCriteria: [],
		familyDefaultDimensions: [],
		familyDefaultParameters: [],
		modelGroup: null,
		referenceIds: [],
		measurand: null,
		components: [],
		structure: [],
		source: null
	}, s = r(t), c = 0;
	for (; c < s.length;) {
		let e = s[c++];
		if (c >= s.length) break;
		if (e === "extends") o.extends = a(s[c++]);
		else if (e === "measurand_kind") o.measurandKind = a(s[c++]);
		else if (e === "measurand") o.measurand = to(i(s[c++]));
		else if (e === "component") o.components.push(no(a(s[c++]), i(s[c++])));
		else if (e === "structure") o.structure.push(ro(a(s[c++]), i(s[c++])));
		else if (e === "definition") o.definition = a(s[c++]);
		else if (e === "note") o.note = a(s[c++]);
		else if (e === "source") {
			let e = I(i(s[c++]));
			(o.sourceRefs ??= []).push(e), o.source ||= e;
		} else if (e === "variant") {
			let e = a(s[c++]), t = c < s.length ? i(s[c++]) : "", r = {
				id: e,
				definition: ""
			}, l = n(t), u = 0;
			for (; u < l.length;) {
				let e = l[u++];
				if (u >= l.length) break;
				e === "name" ? r.name = a(l[u++]) : e === "definition" ? r.definition = a(l[u++]) : e === "note" ? r.note = a(l[u++]) : e === "source" ? r.source = I(i(l[u++])) : i(l[u++]);
			}
			o.variants.push(r);
		} else if (e === "dimension") o.dimensions.push(io(a(s[c++]), i(s[c++])));
		else if (e === "per_channel") o.perChannel = a(s[c++]);
		else if (e === "family_criteria") o.familyCriteria = q(s[c++]);
		else if (e === "family") {
			let e = n(i(s[c++])), t = 0;
			for (; t < e.length;) {
				let n = e[t++];
				if (t >= e.length) break;
				if (n === "metamodel_class") o.familyMetamodelClass = a(e[t++]);
				else if (n === "definition") o.familyDefinition = a(e[t++]);
				else if (n === "note") o.familyNote = a(e[t++]);
				else if (n === "source") o.familySource = I(i(e[t++]));
				else if (n === "ref") {
					let n = S(e, t, a, i);
					if (t = n.next, n.ref.predicate === "derives-from") {
						let e = ee(n.ref.target);
						e && !o.familySource && (o.familySource = e);
					}
				} else i(e[t++]);
			}
		} else if (e === "family_defaults") {
			let e = n(i(s[c++])), t = 0;
			for (; t < e.length;) {
				let n = e[t++];
				if (t >= e.length) break;
				n === "dimensions" ? o.familyDefaultDimensions = G(e[t++]) : n === "parameters" ? o.familyDefaultParameters = G(e[t++]) : i(e[t++]);
			}
		} else if (e === "model_group") o.modelGroup = so(i(s[c++]));
		else if (e === "reference") o.referenceIds = q(s[c++]);
		else if (e === "ref") {
			let e = S(s, c, a, i);
			T(o, e.ref) || (o.refs ??= []).push(e.ref), c = e.next;
		} else if (e === "corresponds") {
			let e = D(s, c, a);
			(o.correspondences ??= []).push(e.corr), c = e.next;
		} else c = y(s, c, e);
	}
	return (t) => (t.instruments[e] = o, t);
};
function to(e) {
	let t = {
		kind: "",
		description: "",
		context: null,
		source: null
	}, r = n(e), o = 0;
	for (; o < r.length;) {
		let e = r[o++];
		if (o >= r.length) break;
		if (e === "kind") t.kind = a(r[o++]);
		else if (e === "description") t.description = a(r[o++]);
		else if (e === "context") {
			let e = {
				targetObject: "",
				identificationMethod: ""
			}, s = n(i(r[o++])), c = 0;
			for (; c < s.length;) {
				let t = s[c++];
				if (c >= s.length) break;
				t === "target_object" ? e.targetObject = a(s[c++]) : t === "identification_method" ? e.identificationMethod = a(s[c++]) : i(s[c++]);
			}
			t.context = e;
		} else e === "source" ? t.source = I(i(r[o++])) : o = y(r, o, e);
	}
	return t;
}
function no(e, t) {
	let r = {
		id: e,
		classId: "",
		definition: "",
		source: null
	}, o = n(t), s = 0;
	for (; s < o.length;) {
		let e = o[s++];
		if (s >= o.length) break;
		e === "class" ? r.classId = a(o[s++]) : e === "definition" ? r.definition = a(o[s++]) : e === "source" ? r.source = I(i(o[s++])) : s = y(o, s, e);
	}
	return r;
}
function ro(e, t) {
	let r = {
		id: e,
		predicate: "",
		subject: "",
		target: "",
		applicability: [],
		propagation: [],
		note: "",
		source: null
	}, o = n(t), s = 0;
	for (; s < o.length;) {
		let e = o[s++];
		if (s >= o.length) break;
		if (e === "predicate") r.predicate = a(o[s++]);
		else if (e === "subject") r.subject = a(o[s++]);
		else if (e === "target") r.target = a(o[s++]);
		else if (e === "applicability") r.applicability = L(i(o[s++]));
		else if (e === "propagation") {
			let e = n(i(o[s++]));
			for (let t = 0; t + 1 < e.length; t += 2) r.propagation.push({
				property: a(e[t]),
				direction: a(e[t + 1])
			});
		} else e === "note" ? r.note = a(o[s++]) : e === "source" ? r.source = I(i(o[s++])) : s = y(o, s, e);
	}
	return r;
}
function io(e, t) {
	let r = {
		id: e,
		label: "",
		scope: "",
		cardinality: "",
		labelSeparator: "",
		description: "",
		source: null,
		values: []
	}, o = n(t), s = 0;
	for (; s < o.length;) {
		let t = o[s++];
		if (s >= o.length) break;
		if (t === "label") r.label = a(o[s++]);
		else if (t === "scope") r.scope = a(o[s++]);
		else if (t === "cardinality") {
			let t = a(o[s++]);
			if (t !== "single" && t !== "set") throw Error(`Parsing error: dimension. ID ${e}: Unknown cardinality ${t} (valid: single, set)`);
			r.cardinality = t;
		} else if (t === "label_separator") r.labelSeparator = a(o[s++]);
		else if (t === "description") r.description = a(o[s++]);
		else if (t === "reference" || t === "source") r.source = I(i(o[s++]));
		else if (t === "values") r.values = ao(i(o[s++]));
		else if (t === "values_of") r.valuesOf = a(o[s++]);
		else if (t === "ref") {
			let e = S(o, s, a, i);
			T(r, e.ref) || (r.refs ??= []).push(e.ref), s = e.next;
		} else s = y(o, s, t);
	}
	return r;
}
function ao(e) {
	let t = [], r = n(e), o = 0;
	for (; o < r.length;) {
		let e = P(r[o++]);
		if (!e) break;
		let s = {
			id: e,
			label: "",
			description: "",
			payload: {},
			implies: []
		};
		if (o < r.length && r[o].startsWith("{")) {
			let e = n(i(r[o++])), t = 0;
			for (; t < e.length;) {
				let r = e[t++];
				if (t >= e.length) break;
				if (r === "label") s.label = a(e[t++]);
				else if (r === "description") s.description = a(e[t++]);
				else if (r === "implies") s.implies = G(e[t++]);
				else if (r === "term_ref") s.termRef = a(e[t++]);
				else if (r === "payload") {
					let r = n(i(e[t++])), o = 0;
					for (; o < r.length;) {
						let e = P(r[o++]);
						if (o >= r.length) break;
						if (r[o] === ":" && o++, o < r.length && r[o].startsWith("{")) {
							let t = n(i(r[o++])), c = {}, l = 0;
							for (; l < t.length;) {
								let e = P(t[l++]);
								if (l >= t.length) break;
								t[l] === ":" && l++, l < t.length && (c[e] = a(t[l++]));
							}
							s.payload[e] = c;
						} else o < r.length && (s.payload[e] = a(r[o++]));
					}
				} else i(e[t++]);
			}
		}
		t.push(s);
	}
	return t;
}
function oo(e, t) {
	let n = t + "  ", r = t + "    ", i = t + "dimension " + e.id + " {\n";
	if (e.label && (i += n + "label \"" + s(e.label) + "\"\n"), e.scope && (i += n + "scope " + e.scope + "\n"), e.cardinality && (i += n + "cardinality " + e.cardinality + "\n"), e.labelSeparator && (i += n + "label_separator \"" + s(e.labelSeparator) + "\"\n"), e.description && (i += n + "description \"" + s(e.description) + "\"\n"), i += W("reference", e.source, n), e.valuesOf && (i += n + "values_of " + e.valuesOf + "\n"), e.values.length > 0) {
		i += n + "values {\n";
		for (let t of e.values) {
			let e = r + t.id;
			if (t.label || t.description || t.termRef || Object.keys(t.payload).length > 0 || t.implies.length > 0) {
				if (e += " { ", t.label && (e += "label \"" + s(t.label) + "\" "), t.description && (e += "description \"" + s(t.description) + "\" "), t.termRef && (e += "term_ref " + t.termRef + " "), t.implies.length > 0 && (e += "implies { " + t.implies.join(" ") + " } "), Object.keys(t.payload).length > 0) {
					e += "payload { ";
					for (let [n, r] of Object.entries(t.payload)) if (typeof r == "object" && r) {
						e += n + " { ";
						for (let [t, n] of Object.entries(r)) e += t + ": \"" + s(String(n)) + "\" ";
						e += "} ";
					} else e += n + ": \"" + s(String(r)) + "\" ";
					e += "} ";
				}
				e += "}";
			}
			i += e + "\n";
		}
		i += n + "}\n";
	}
	return i += w(e.refs, n, s), i += t + "}\n", i;
}
function so(e) {
	let t = {
		definition: "",
		identicalCharacteristics: [],
		identicalAttributes: [],
		sources: [],
		sampleSelection: []
	}, r = n(e), o = 0;
	for (; o < r.length;) {
		let e = r[o++];
		if (o >= r.length) break;
		if (e === "definition") t.definition = a(r[o++]);
		else if (e === "identical_characteristics") t.identicalCharacteristics = G(r[o++]);
		else if (e === "identical_attributes") t.identicalAttributes = G(r[o++]);
		else if (e === "group_by") t.groupBy = a(r[o++]);
		else if (e === "note") t.note = a(r[o++]);
		else if (e === "source") t.sources.push(I(i(r[o++])));
		else if (e === "ref") {
			let e = S(r, o, a, i);
			if (o = e.next, e.ref.predicate === "derives-from") {
				let n = ee(e.ref.target);
				n && t.sources.push(n);
			}
		} else e === "sample_selection" ? t.sampleSelection.push(I(i(r[o++]))) : o = y(r, o, e);
	}
	return t;
}
var co = function(e) {
	let t = "instrument " + e.id + " {\n";
	if (e.extends && (t += "  extends " + e.extends + "\n"), e.perChannel && (t += "  per_channel " + e.perChannel + "\n"), e.measurandKind && (t += "  measurand_kind " + e.measurandKind + "\n"), e.measurand) {
		let n = e.measurand;
		t += "  measurand {\n", n.kind && (t += "    kind " + n.kind + "\n"), n.description && (t += "    description \"" + s(n.description) + "\"\n"), n.context && (t += "    context {", n.context.targetObject && (t += " target_object \"" + s(n.context.targetObject) + "\""), n.context.identificationMethod && (t += " identification_method \"" + s(n.context.identificationMethod) + "\""), t += " }\n"), t += W("source", n.source, "    "), t += "  }\n";
	}
	for (let n of e.components ?? []) {
		let e = "  component " + n.id + " { ";
		n.classId && (e += "class " + n.classId + " "), n.definition && (e += "definition \"" + s(n.definition) + "\" "), n.source && (n.source.doc || n.source.clause) && (e += "source { doc \"" + s(n.source.doc) + "\" clause \"" + s(n.source.clause) + "\" } "), t += e + "}\n";
	}
	for (let n of e.structure ?? []) {
		if (t += "  structure " + n.id + " {\n", n.predicate && (t += "    predicate " + n.predicate + "\n"), n.subject && (t += "    subject " + n.subject + "\n"), n.target && (t += "    target " + n.target + "\n"), n.applicability.length > 0 && (t += "    applicability { " + R(n.applicability).trim() + " }\n"), n.propagation.length > 0) {
			t += "    propagation { ";
			for (let e of n.propagation) t += e.property + " " + e.direction + " ";
			t += "}\n";
		}
		n.note && (t += "    note \"" + s(n.note) + "\"\n"), t += W("source", n.source, "    "), t += "  }\n";
	}
	e.definition && (t += "  definition \"" + s(e.definition) + "\"\n"), e.note && (t += "  note \"" + s(e.note) + "\"\n");
	for (let n of e.variants) {
		let e = "  variant " + n.id + " { ";
		n.name && (e += "name \"" + s(n.name) + "\" "), e += "definition \"" + s(n.definition) + "\" ", n.note && (e += "note \"" + s(n.note) + "\" "), n.source && (n.source.doc || n.source.clause) && (e += "source { doc \"" + s(n.source.doc) + "\" clause \"" + s(n.source.clause) + "\" } "), t += e + "}\n";
	}
	for (let n of e.dimensions) t += oo(n, "  ");
	if ((e.familyMetamodelClass || e.familyDefinition || e.familyNote || e.familySource && (e.familySource.doc || e.familySource.clause)) && (t += "  family {\n", e.familyMetamodelClass && (t += "    metamodel_class " + e.familyMetamodelClass + "\n"), e.familyDefinition && (t += "    definition \"" + s(e.familyDefinition) + "\"\n"), e.familyNote && (t += "    note \"" + s(e.familyNote) + "\"\n"), e.familySource && (e.familySource.doc || e.familySource.clause) && (t += E(e.familySource, "    ", s)), t += "  }\n"), e.familyCriteria.length > 0) {
		t += "  family_criteria {\n";
		for (let n of e.familyCriteria) t += "    \"" + s(n) + "\"\n";
		t += "  }\n";
	}
	if ((e.familyDefaultDimensions.length > 0 || e.familyDefaultParameters.length > 0) && (t += "  family_defaults {\n", t += K("dimensions", e.familyDefaultDimensions, "    "), t += K("parameters", e.familyDefaultParameters, "    "), t += "  }\n"), e.modelGroup) {
		t += "  model_group {\n", e.modelGroup.definition && (t += "    definition \"" + s(e.modelGroup.definition) + "\"\n"), e.modelGroup.groupBy && (t += "    group_by " + e.modelGroup.groupBy + "\n"), e.modelGroup.note && (t += "    note \"" + s(e.modelGroup.note) + "\"\n"), t += K("identical_characteristics", e.modelGroup.identicalCharacteristics, "    "), t += K("identical_attributes", e.modelGroup.identicalAttributes, "    ");
		for (let n of e.modelGroup.sources ?? []) t += E(n, "    ", s);
		for (let n of e.modelGroup.sampleSelection ?? []) t += W("sample_selection", n, "    ");
		t += "  }\n";
	}
	let n = e.sourceRefs && e.sourceRefs.length > 0 ? e.sourceRefs : e.source ? [e.source] : [];
	for (let e of n) t += E(e, "  ", s);
	return t += w(e.refs, "  ", s), t += k(e.correspondences, "  ", s, N), t += K("reference", e.referenceIds, "  "), t += "}\n", t;
};
function lo(e) {
	let t = {
		key: "",
		value: "",
		keyDimension: "",
		components: []
	}, r = n(e), o = 0;
	for (; o < r.length;) {
		let e = r[o++];
		if (o > r.length) break;
		if (e === "key") t.key = a(r[o++]);
		else if (e === "value") t.value = a(r[o++]);
		else if (e === "key_dimension") t.keyDimension = a(r[o++]);
		else if (e === "component") {
			let e = {
				id: a(r[o++]),
				name: "",
				source: null
			};
			if (o < r.length && r[o].startsWith("{")) {
				let t = n(i(r[o++])), s = 0;
				for (; s < t.length;) {
					let n = t[s++];
					if (s >= t.length) break;
					n === "name" ? e.name = a(t[s++]) : n === "source" ? e.source = I(i(t[s++])) : i(t[s++]);
				}
			}
			t.components.push(e);
		} else o = y(r, o, e);
	}
	return t;
}
function uo(e) {
	let t = "  pair_list {\n";
	t += "    key " + N(e.key) + "\n", t += "    value " + N(e.value) + "\n", e.keyDimension && (t += "    key_dimension " + N(e.keyDimension) + "\n");
	for (let n of e.components) t += "    component " + N(n.id) + " {\n", n.name && (t += "      name \"" + s(n.name) + "\"\n"), n.source && (n.source.doc || n.source.clause) && (t += "      source {\n", n.source.doc && (t += "        doc \"" + s(n.source.doc) + "\"\n"), n.source.clause && (t += "        clause \"" + s(n.source.clause) + "\"\n"), t += "      }\n"), t += "    }\n";
	return t += "  }\n", t;
}
var fo = function(e, t) {
	let n = {
		id: e,
		symbol: "",
		name: "",
		definition: "",
		source: null,
		quantityKind: "",
		unit: "",
		valueType: "",
		origin: "",
		scope: "",
		category: "",
		isDimension: null,
		enumRef: "",
		irdi: "",
		derived: "",
		referenceIds: []
	}, o = r(t), s = 0;
	for (; s < o.length;) {
		let e = o[s++];
		if (s >= o.length) break;
		if (e === "symbol") n.symbol = a(o[s++]);
		else if (e === "name") n.name = a(o[s++]);
		else if (e === "definition") n.definition = a(o[s++]);
		else if (e === "source" || e === "reference") {
			let e = I(i(o[s++]));
			(n.sourceRefs ??= []).push(e), n.source ||= e;
		} else if (e === "quantity_kind") n.quantityKind = a(o[s++]);
		else if (e === "unit") n.unit = a(o[s++]);
		else if (e === "value_type") n.valueType = a(o[s++]);
		else if (e === "pair_list") n.pairList = lo(i(o[s++]));
		else if (e === "origin") n.origin = a(o[s++]);
		else if (e === "scope") n.scope = a(o[s++]);
		else if (e === "category") n.category = a(o[s++]);
		else if (e === "is_dimension") n.isDimension = a(o[s++]) === "true";
		else if (e === "enum") n.enumRef = a(o[s++]);
		else if (e === "enum_values") n.enumValues = G(o[s++]);
		else if (e === "note") n.note = a(o[s++]);
		else if (e === "irdi") n.irdi = a(o[s++]);
		else if (e === "derived") n.derived = a(o[s++]);
		else if (e === "ref") {
			let e = S(o, s, a, i);
			T(n, e.ref) || (n.refs ??= []).push(e.ref), s = e.next;
		} else if (e === "corresponds") {
			let e = D(o, s, a);
			(n.correspondences ??= []).push(e.corr), s = e.next;
		} else s = y(o, s, e);
	}
	return (t) => (t.attributeDefinitions[e] = n, t);
}, po = function(e) {
	let t = "attribute_definition " + e.id + " {\n";
	e.symbol && (t += "  symbol \"" + s(e.symbol) + "\"\n"), e.name && (t += "  name \"" + s(e.name) + "\"\n"), e.definition && (t += "  definition \"" + s(e.definition) + "\"\n");
	let n = e.sourceRefs && e.sourceRefs.length > 0 ? e.sourceRefs : e.source ? [e.source] : [];
	for (let e of n) t += E(e, "  ", s);
	for (let n of e.referenceIds) t += "  ref cites \"" + s(n) + "\"\n";
	return t += w(e.refs, "  ", s), t += k(e.correspondences, "  ", s, N), e.quantityKind && (t += "  quantity_kind " + e.quantityKind + "\n"), e.unit && (t += "  unit \"" + s(e.unit) + "\"\n"), e.valueType && (t += "  value_type " + e.valueType + "\n"), e.pairList && (t += uo(e.pairList)), e.origin && (t += "  origin " + e.origin + "\n"), e.scope && (t += "  scope " + e.scope + "\n"), e.category && (t += "  category " + e.category + "\n"), e.isDimension !== null && e.isDimension !== void 0 && (t += "  is_dimension " + (e.isDimension ? "true" : "false") + "\n"), e.enumRef && (t += "  enum " + e.enumRef + "\n"), e.enumValues && e.enumValues.length > 0 && (t += "  enum_values { " + e.enumValues.map(N).join(" ") + " }\n"), e.irdi && (t += "  irdi \"" + s(e.irdi) + "\"\n"), e.derived && (t += "  derived \"" + s(e.derived) + "\"\n"), e.note && (t += "  note \"" + s(e.note) + "\"\n"), t += "}\n", t;
}, mo = function(e, t) {
	let n = {
		id: e,
		label: "",
		description: "",
		abstract: !1,
		extends: [],
		requires: [],
		hasParameters: [],
		satisfiesRequirements: [],
		verifiedByTests: [],
		referenceIds: []
	}, o = r(t), s = 0;
	for (; s < o.length;) {
		let e = o[s++];
		if (s >= o.length) break;
		if (e === "label") n.label = a(o[s++]);
		else if (e === "description") n.description = a(o[s++]);
		else if (e === "abstract") n.abstract = a(o[s++]) === "true";
		else if (e === "extends") n.extends = G(o[s++]);
		else if (e === "requires") n.requires = G(o[s++]);
		else if (e === "has_parameters") n.hasParameters = G(o[s++]);
		else if (e === "satisfies_requirements") n.satisfiesRequirements = q(o[s++]);
		else if (e === "verified_by_tests" || e === "verified_by") n.verifiedByTests = q(o[s++]);
		else if (e === "reference") n.referenceIds = q(o[s++]);
		else if (e === "ref") {
			let e = S(o, s, a, i);
			T(n, e.ref) || (n.refs ??= []).push(e.ref), s = e.next;
		} else if (e === "corresponds") {
			let e = D(o, s, a);
			(n.correspondences ??= []).push(e.corr), s = e.next;
		} else s = y(o, s, e);
	}
	return (t) => (t.capabilities[e] = n, t);
}, ho = function(e) {
	let t = "capability " + e.id + " {\n";
	return e.label && (t += "  label \"" + s(e.label) + "\"\n"), e.description && (t += "  description \"" + s(e.description) + "\"\n"), e.abstract && (t += "  abstract true\n"), t += K("extends", e.extends, "  "), t += K("requires", e.requires, "  "), t += K("has_parameters", e.hasParameters, "  "), t += K("satisfies_requirements", e.satisfiesRequirements, "  "), t += K("verified_by_tests", e.verifiedByTests, "  "), t += K("reference", e.referenceIds, "  "), t += w(e.refs, "  ", s), t += k(e.correspondences, "  ", s, N), t += "}\n", t;
}, go = function(e, t) {
	let n = {
		id: e,
		kind: "",
		stimulus: "",
		response: "",
		source: null,
		verifiedBy: [],
		referenceIds: []
	}, o = r(t), s = 0;
	for (; s < o.length;) {
		let e = o[s++];
		if (s >= o.length) break;
		if (e === "kind") n.kind = a(o[s++]);
		else if (e === "stimulus") n.stimulus = a(o[s++]);
		else if (e === "response") n.response = a(o[s++]);
		else if (e === "source" || e === "reference") {
			let e = I(i(o[s++]));
			(n.sourceRefs ??= []).push(e), n.source ||= e;
		} else if (e === "verified_by" || e === "verified_by_tests") n.verifiedBy = q(o[s++]);
		else if (e === "ref") {
			let e = S(o, s, a, i);
			T(n, e.ref) || (n.refs ??= []).push(e.ref), s = e.next;
		} else if (e === "corresponds") {
			let e = D(o, s, a);
			(n.correspondences ??= []).push(e.corr), s = e.next;
		} else s = y(o, s, e);
	}
	return (t) => (t.behaviors[e] = n, t);
}, _o = function(e) {
	let t = "behavior " + e.id + " {\n";
	e.kind && (t += "  kind " + e.kind + "\n"), e.stimulus && (t += "  stimulus " + e.stimulus + "\n"), e.response && (t += "  response \"" + s(e.response) + "\"\n");
	let n = e.sourceRefs && e.sourceRefs.length > 0 ? e.sourceRefs : e.source ? [e.source] : [];
	for (let e of n) t += E(e, "  ", s);
	return t += w(e.refs, "  ", s), t += k(e.correspondences, "  ", s, N), t += K("verified_by", e.verifiedBy, "  "), t += "}\n", t;
}, vo = function(e, t) {
	let n = {
		id: e,
		role: "",
		entries: [],
		source: null,
		sources: [],
		referenceIds: []
	}, o = r(t), s = 0;
	for (; s < o.length;) {
		let e = o[s++];
		if (s >= o.length) break;
		if (e === "role") n.role = a(o[s++]);
		else if (e === "subject") n.subject = a(o[s++]);
		else if (e === "description") n.description = a(o[s++]);
		else if (e === "entries") n.entries = yo(i(o[s++]));
		else if (e === "source") {
			let e = I(i(o[s++]));
			n.sources.push(e), n.source ||= e;
		} else if (e === "ref") {
			let e = S(o, s, a, i);
			if (s = e.next, e.ref.predicate === "derives-from") {
				let t = ee(e.ref.target);
				t ? (n.sources.push(t), n.source ||= t) : (n.refs ??= []).push(e.ref);
			} else e.ref.predicate === "cites" ? n.referenceIds.push(e.ref.target) : (n.refs ??= []).push(e.ref);
		} else if (e === "corresponds") {
			let e = D(o, s, a);
			(n.correspondences ??= []).push(e.corr), s = e.next;
		} else e === "reference" ? n.referenceIds = q(o[s++]) : s = y(o, s, e);
	}
	return (t) => (t.conditionSets[e] = n, t);
};
function yo(e) {
	let t = [], r = n(e), o = 0;
	for (; o < r.length;) {
		let e = P(r[o++]);
		if (!e) break;
		let s = {
			quantityKind: e,
			value: "",
			unit: "",
			tolerance: ""
		};
		if (o < r.length && r[o].startsWith("{")) {
			let e = n(i(r[o++])), t = 0;
			for (; t < e.length;) {
				let n = e[t++];
				if (t >= e.length) break;
				n === "value" ? s.value = a(e[t++]) : n === "unit" ? s.unit = a(e[t++]) : n === "tolerance" ? s.tolerance = a(e[t++]) : n === "note" ? s.note = a(e[t++]) : i(e[t++]);
			}
		}
		t.push(s);
	}
	return t;
}
var bo = function(e) {
	let t = "condition_set " + e.id + " {\n";
	if (e.role && (t += "  role " + e.role + "\n"), e.subject && (t += "  subject " + e.subject + "\n"), e.description && (t += "  description \"" + s(e.description) + "\"\n"), e.entries.length > 0) {
		t += "  entries {\n";
		for (let n of e.entries) {
			let e = "    " + n.quantityKind + " { value " + N(n.value);
			n.unit && (e += " unit \"" + s(n.unit) + "\""), n.tolerance && (e += " tolerance " + N(n.tolerance)), n.note && (e += " note \"" + s(n.note) + "\""), t += e + " }\n";
		}
		t += "  }\n";
	}
	let n = e.sources && e.sources.length > 0 ? e.sources : e.source ? [e.source] : [];
	for (let e of n) t += E(e, "  ", s);
	return t += K("reference", e.referenceIds, "  "), t += w(e.refs, "  ", s), t += k(e.correspondences, "  ", s, N), t += "}\n", t;
};
function xo(e) {
	let t = {}, r = n(e), i = 0;
	for (; i < r.length;) {
		let e = P(r[i++]);
		if (!e) break;
		r[i] === ":" && i++, i < r.length && (t[e] = a(r[i++]));
	}
	return t;
}
function So(e) {
	let t = {}, r = n(e), i = 0;
	for (; i < r.length;) {
		let e = P(r[i++]);
		if (!e) break;
		r[i] === ":" && i++;
		let n = [];
		for (; i < r.length && r[i + 1] !== ":";) n.push(a(r[i++]));
		t[e] = n.join(" ");
	}
	return t;
}
function Co(e) {
	return n(e).map(a).filter((e) => e.length > 0);
}
function wo(e) {
	let t = {}, r = n(e), o = 0;
	for (; o < r.length;) {
		let e = P(r[o++]);
		if (!e) break;
		if (r[o] === ":" && o++, r[o] === "in" && o++, o < r.length) {
			let n = r[o++];
			t[e] = (n.startsWith("{") ? i(n) : a(n)).split(/[,\s]+/).map((e) => e.trim()).filter((e) => e.length > 0);
		}
	}
	return t;
}
function To(e) {
	let t = {}, r = n(e), o = 0;
	for (; o < r.length;) {
		let e = P(r[o++]);
		if (!e) break;
		if (o < r.length && r[o].startsWith("{")) {
			t[e] = Eo(i(r[o++]));
			continue;
		}
		let n = "", s = "", c = !1;
		if (e.length > 1 && e.endsWith("=") && (e = e.slice(0, -1), c = !0), !c && o < r.length && r[o] !== "=" && (c = r[o].endsWith("="), n = c ? r[o].slice(0, -1) : r[o], o++), c || r[o] === "=") {
			c || o++;
			let e = M(r, o);
			s = a(e.text), o = e.next;
		}
		t[e] = {
			symbol: n,
			derivation: s
		};
	}
	return t;
}
function Eo(e) {
	let t = {
		symbol: "",
		derivation: ""
	}, r = n(e), o = 0;
	for (; o < r.length;) {
		let e = r[o++];
		if (o >= r.length) break;
		if (e === "symbol") t.symbol = a(r[o++]);
		else if (e === "derivation" || e === "derive") {
			let e = M(r, o);
			t.derivation = a(e.text), o = e.next;
		} else e === "behavior" ? t.behavior = a(r[o++]) : e === "quantity_kind" ? t.quantityKind = a(r[o++]) : e === "unit" ? t.unit = a(r[o++]) : e === "source" || e === "reference" ? t.source = I(i(r[o++])) : o = y(r, o, e);
	}
	return t;
}
var Do = /* @__PURE__ */ new Set(["state", "behavior"]);
function Oo(e, t, n) {
	return e === "endpoint" ? (n < t.length && !t[n].startsWith("{") && n++, n < t.length && t[n].startsWith("{") && n++, n) : e === "serve" ? (n < t.length && n++, t[n] === "via" && (n += 2), n < t.length && t[n].startsWith("{") && n++, n) : n;
}
function ko(e, t, n, r, i) {
	let a = P(n);
	return e.misplacedAspects.push({
		family: t,
		aspect: a
	}), i < r.length && r[i].startsWith("{") || Do.has(a) ? i++ : i = Oo(a, r, i), i;
}
function Ao(e, t) {
	let r = e[t] ?? "";
	if (r === "symbolic") return {
		level: {
			kind: "symbolic",
			symbolic: a(e[t + 1] ?? "")
		},
		next: t + 2
	};
	if (r === "range") {
		let r = { kind: "range" }, o = n(i(e[t + 1] ?? "")), s = 0;
		for (; s < o.length;) {
			let e = o[s++];
			if (s > o.length) break;
			e === "min" ? r.min = z(o[s++]) : e === "max" ? r.max = z(o[s++]) : e === "unit" ? r.unit = a(o[s++]) : i(o[s++]);
		}
		return {
			level: r,
			next: t + 2
		};
	}
	return {
		level: {
			kind: "quantity",
			quantity: ve(i(r))
		},
		next: t + 1
	};
}
function jo(e) {
	let t = [], r = n(e), o = 0;
	for (; o < r.length;) {
		let e = r[o++];
		if (!e) break;
		if (e.startsWith("\"") || o >= r.length || !r[o].startsWith("{")) {
			t.push({
				id: "",
				target: "",
				level: null,
				conditions: "",
				statement: a(e),
				verifiedBy: [],
				source: null,
				certificate: null
			});
			continue;
		}
		t.push(Po(P(e), i(r[o++])));
	}
	return t;
}
var Mo = ["mandatory", "optional"];
function No(e, t) {
	let r = {
		attribute: "",
		attributes: [],
		dimension: "",
		type: "",
		label: "",
		obligation: ""
	}, o = n(t), s = 0;
	for (; s < o.length;) {
		let t = o[s++];
		if (s > o.length) break;
		if (t === "attribute") r.attribute = a(o[s++]);
		else if (t === "attributes") r.attributes = G(o[s++]);
		else if (t === "dimension") r.dimension = a(o[s++]);
		else if (t === "type") r.type = a(o[s++]);
		else if (t === "label") r.label = a(o[s++]);
		else if (t === "obligation") {
			let t = a(o[s++]);
			if (!Mo.includes(t)) throw Error(`Parsing error: promise. ID ${e}: Unknown certificate obligation "${t}" (valid: ${Mo.join(", ")})`);
			r.obligation = t;
		} else i(o[s++]);
	}
	return r;
}
function Po(e, t) {
	let r = {
		id: e,
		target: "",
		level: null,
		conditions: "",
		statement: "",
		verifiedBy: [],
		source: null,
		certificate: null
	}, o = n(t), s = 0;
	for (; s < o.length;) {
		let e = o[s++];
		if (s >= o.length) break;
		if (e === "target") r.target = a(o[s++]);
		else if (e === "level") {
			let e = Ao(o, s);
			r.level = e.level, s = e.next;
		} else if (e === "conditions") {
			let e = M(o, s);
			r.conditions = a(e.text), s = e.next;
		} else e === "statement" ? r.statement = a(o[s++]) : e === "verified_by" ? r.verifiedBy = G(o[s++]) : e === "source" ? r.source = I(i(o[s++])) : e === "certificate" ? r.certificate = No(r.id, i(o[s++])) : i(o[s++]);
	}
	return r;
}
function Fo(e) {
	return e.id === "" && !e.target && !e.level && !e.conditions && e.verifiedBy.length === 0 && !e.source && !e.certificate;
}
function Io(e, t) {
	let r = n(e), a = 0;
	for (; a < r.length;) {
		let e = r[a++];
		if (a >= r.length) break;
		if (e === "metadata") t.is.metadata = xo(i(r[a++]));
		else if (e === "provenance") t.is.provenance = xo(i(r[a++]));
		else if (e === "structure") t.is.structure = Co(i(r[a++]));
		else if (e === "design_parameters") t.is.designParameters = So(i(r[a++]));
		else if (e === "designed_conditions") t.is.designedConditions = xo(i(r[a++]));
		else if (e === "promises") t.is.promises = jo(i(r[a++]));
		else if (e === "artifacts") t.is.artifacts = Co(i(r[a++]));
		else if (e === "endpoint") {
			let e = P(r[a++] ?? ""), n = a < r.length ? i(r[a++]) : "";
			e && t.is.endpoints.push(Ua(e, n));
		} else e === "composed_of" ? t.is.composedOf = Za(i(r[a++] ?? "")) : a = ko(t, "is", e, r, a);
	}
}
function Lo(e, t) {
	let r = n(e), o = 0;
	for (; o < r.length;) {
		let e = r[o++];
		if (o >= r.length) break;
		if (e === "attributes") t.has.attributes = So(i(r[o++]));
		else if (e === "dimensions") t.has.dimensions = wo(i(r[o++]));
		else if (e === "state") t.has.state = a(r[o++]);
		else if (e === "characteristics") t.has.characteristics = To(i(r[o++]));
		else if (e === "environmental_context") t.has.environmentalContext = Co(i(r[o++]));
		else if (e === "artifact_instances") t.has.artifactInstances = Co(i(r[o++]));
		else if (e === "serve") {
			let e = Ka(r, o);
			t.has.serves.push(e.binding), o = e.next;
		} else o = ko(t, "has", e, r, o);
	}
}
function Ro(e, t) {
	let r = n(e), i = 0;
	for (; i < r.length;) {
		let e = r[i++];
		if (i >= r.length) break;
		e === "behavior" ? t.does.behaviors.push(a(r[i++])) : i = ko(t, "does", e, r, i);
	}
}
var zo = function(e, t) {
	let n = {
		id: e,
		extends: "",
		is: {
			metadata: {},
			provenance: {},
			structure: [],
			designParameters: {},
			designedConditions: {},
			promises: [],
			artifacts: [],
			endpoints: []
		},
		has: {
			attributes: {},
			dimensions: {},
			state: "",
			characteristics: {},
			environmentalContext: [],
			artifactInstances: [],
			serves: []
		},
		does: { behaviors: [] },
		referenceIds: [],
		misplacedAspects: []
	}, o = r(t), s = 0;
	for (; s < o.length;) {
		let e = o[s++];
		if (s >= o.length) break;
		e === "extends" ? n.extends = a(o[s++]) : e === "is" ? Io(i(o[s++]), n) : e === "has" ? Lo(i(o[s++]), n) : e === "does" ? Ro(i(o[s++]), n) : e === "reference" ? n.referenceIds = q(o[s++]) : s = y(o, s, e);
	}
	return (t) => (t.subjects[e] = n, t);
};
function Bo(e, t) {
	return {
		id: t.id,
		extends: "",
		is: {
			metadata: {
				...e.is.metadata,
				...t.is.metadata
			},
			provenance: {
				...e.is.provenance,
				...t.is.provenance
			},
			structure: [...e.is.structure, ...t.is.structure],
			designParameters: {
				...e.is.designParameters,
				...t.is.designParameters
			},
			designedConditions: {
				...e.is.designedConditions,
				...t.is.designedConditions
			},
			promises: [...e.is.promises, ...t.is.promises],
			artifacts: [...e.is.artifacts, ...t.is.artifacts],
			endpoints: [...e.is.endpoints, ...t.is.endpoints],
			...t.is.composedOf ? { composedOf: t.is.composedOf } : e.is.composedOf ? { composedOf: e.is.composedOf } : {}
		},
		has: {
			attributes: {
				...e.has.attributes,
				...t.has.attributes
			},
			dimensions: {
				...e.has.dimensions,
				...t.has.dimensions
			},
			state: t.has.state || e.has.state,
			characteristics: {
				...e.has.characteristics,
				...t.has.characteristics
			},
			environmentalContext: [...e.has.environmentalContext, ...t.has.environmentalContext],
			artifactInstances: [...e.has.artifactInstances, ...t.has.artifactInstances],
			serves: [...e.has.serves, ...t.has.serves]
		},
		does: { behaviors: [...e.does.behaviors, ...t.does.behaviors] },
		referenceIds: t.referenceIds,
		misplacedAspects: t.misplacedAspects
	};
}
function Vo(e, t) {
	let n = (t, r) => {
		let i = t.extends;
		if (!i || r.has(i)) return t;
		let a = e.subjects[i];
		return a ? (r.add(i), Bo(n(a, r), t)) : t;
	};
	return n(t, /* @__PURE__ */ new Set([t.id]));
}
function Ho(e, t) {
	let n = Object.keys(t);
	return n.length === 0 ? "" : "    " + e + " { " + n.map((e) => e + " " + N(t[e])).join(" ") + " }\n";
}
function Uo(e, t) {
	let n = Object.keys(t);
	return n.length === 0 ? "" : "    " + e + " { " + n.map((e) => e + " :" + (t[e] ? " " + N(t[e]) : "")).join(" ") + " }\n";
}
function Wo(e, t) {
	return t.length === 0 ? "" : "    " + e + " { " + t.map(N).join(" ") + " }\n";
}
function Go(e) {
	let t = Object.keys(e);
	return t.length === 0 ? "" : "    dimensions { " + t.map((t) => t + " in { " + e[t].join(", ") + " }").join(" ") + " }\n";
}
function Ko(e) {
	return /^ocl\{[\s\S]*\}$/.test(e) ? e : N(e);
}
function qo(e) {
	if (e.kind === "symbolic") return "symbolic " + N(e.symbolic ?? "");
	if (e.kind === "range") {
		let t = "";
		return e.min !== void 0 && (t += "min " + B(e.min) + " "), e.max !== void 0 && (t += "max " + B(e.max) + " "), e.unit && (t += "unit \"" + s(e.unit) + "\""), "range { " + t.trimEnd() + " }";
	}
	return xe(e.quantity ?? { value: "" });
}
function Jo(e, t) {
	let n = t + "  ", r = t + "certificate {\n";
	return e.attribute && (r += n + "attribute " + N(e.attribute) + "\n"), e.attributes.length > 0 && (r += n + "attributes { " + e.attributes.map(N).join(" ") + " }\n"), e.dimension && (r += n + "dimension " + N(e.dimension) + "\n"), e.type && (r += n + "type " + N(e.type) + "\n"), e.label && (r += n + "label \"" + s(e.label) + "\"\n"), e.obligation && (r += n + "obligation " + N(e.obligation) + "\n"), r += t + "}\n", r;
}
function Yo(e, t, n = "") {
	let r = t + "  ", i = t + n + N(e.id) + " {\n";
	return e.target && (i += r + "target " + N(e.target) + "\n"), e.level && (i += r + "level " + qo(e.level) + "\n"), e.conditions && (i += r + "conditions " + Ko(e.conditions) + "\n"), e.statement && (i += r + "statement \"" + s(e.statement) + "\"\n"), i += K("verified_by", e.verifiedBy, r), i += W("source", e.source ?? null, r), e.certificate && (i += Jo(e.certificate, r)), i += t + "}\n", i;
}
function Xo(e) {
	if (e.length === 0) return "";
	if (e.every(Fo)) return "    promises { " + e.map((e) => N(e.statement)).join(" ") + " }\n";
	let t = "    promises {\n";
	for (let n of e) {
		if (Fo(n)) {
			t += "      " + N(n.statement) + "\n";
			continue;
		}
		t += Yo(n, "      ");
	}
	return t += "    }\n", t;
}
function Zo(e) {
	let t = Object.keys(e);
	if (t.length === 0) return "";
	let n = "    characteristics {\n";
	for (let r of t) {
		let t = e[r];
		if (t.behavior || t.quantityKind || t.unit || t.source && (t.source.doc || t.source.clause)) {
			n += "      " + r + " {\n", t.symbol && (n += "        symbol \"" + s(t.symbol) + "\"\n"), t.derivation && (n += "        derivation " + Ko(t.derivation) + "\n"), t.behavior && (n += "        behavior " + N(t.behavior) + "\n"), t.quantityKind && (n += "        quantity_kind " + N(t.quantityKind) + "\n"), t.unit && (n += "        unit \"" + s(t.unit) + "\"\n"), n += W("source", t.source ?? null, "        "), n += "      }\n";
			continue;
		}
		n += "      " + r + (t.symbol ? " " + t.symbol : ""), t.derivation && (n += " = " + Ko(t.derivation)), n += "\n";
	}
	return n += "    }\n", n;
}
function Qo(e) {
	let t = "";
	for (let n of e) t += Ga(n, "    ");
	return t;
}
function $o(e) {
	let t = "";
	for (let n of e) t += qa(n, "    ");
	return t;
}
var es = function(e) {
	let t = "subject " + e.id + " {\n";
	e.extends && (t += "  extends " + e.extends + "\n");
	let n = Ho("metadata", e.is.metadata) + Ho("provenance", e.is.provenance) + Wo("structure", e.is.structure) + Uo("design_parameters", e.is.designParameters) + Ho("designed_conditions", e.is.designedConditions) + Xo(e.is.promises) + Wo("artifacts", e.is.artifacts) + Qo(e.is.endpoints) + (e.is.composedOf ? $a(e.is.composedOf, "    ") : "");
	n && (t += "  is {\n" + n + "  }\n");
	let r = Uo("attributes", e.has.attributes) + Go(e.has.dimensions) + (e.has.state ? "    state " + N(e.has.state) + "\n" : "") + Zo(e.has.characteristics) + Wo("environmental_context", e.has.environmentalContext) + Wo("artifact_instances", e.has.artifactInstances) + $o(e.has.serves);
	r && (t += "  has {\n" + r + "  }\n");
	let i = "";
	for (let t of e.does.behaviors) i += "    behavior " + N(t) + "\n";
	return i && (t += "  does {\n" + i + "  }\n"), t += K("reference", e.referenceIds, "  "), t += "}\n", t;
}, ts = {
	keyword: "instrument",
	field: "instruments",
	takesID: !0,
	parse: eo,
	dump: co
}, ns = {
	keyword: "attribute_definition",
	field: "attributeDefinitions",
	takesID: !0,
	parse: fo,
	dump: po
}, rs = {
	keyword: "capability",
	field: "capabilities",
	takesID: !0,
	parse: mo,
	dump: ho
}, is = {
	keyword: "behavior",
	field: "behaviors",
	takesID: !0,
	parse: go,
	dump: _o
}, as = {
	keyword: "condition_set",
	field: "conditionSets",
	takesID: !0,
	parse: vo,
	dump: bo
}, os = {
	keyword: "subject",
	field: "subjects",
	takesID: !0,
	parse: zo,
	resolve: Vo,
	dump: es
};
//#endregion
//#region src/ser-des/config/instance.ts
function ss(e) {
	return !e.startsWith("\"") && e.endsWith(":") && e.length > 1;
}
function cs(e) {
	let t = {}, r = n(e), o = 0;
	for (; o < r.length;) {
		let e = P(r[o++]);
		if (!e) break;
		r[o] === ":" && o++;
		let n = [];
		for (; o < r.length && r[o + 1] !== ":" && !ss(r[o]);) n.push(r[o++]);
		if (n.length === 0) {
			t[e] = { value: "" };
			continue;
		}
		if (n.length > 2) throw Error(`Parsing error: instance value entry "${e}" has ${n.length} tokens (shape: key : value [unit]) — quote multi-word values`);
		if (n.length === 1 && n[0].startsWith("{")) {
			t[e] = ve(i(n[0]));
			continue;
		}
		let [s, c] = n, l = z(s);
		t[e] = c === void 0 ? { value: l } : {
			value: l,
			unit: a(c)
		};
	}
	return t;
}
function ls(e) {
	let t = {}, r = n(e), i = 0;
	for (; i < r.length;) {
		let e = P(r[i++]);
		if (!e) break;
		r[i] === ":" && i++, i < r.length && (t[e] = a(r[i++]));
	}
	return t;
}
function us(e) {
	return n(a(e)).map(a).filter((e) => e.length > 0);
}
function ds(e, t) {
	let r = n(e), a = 0;
	for (; a < r.length;) {
		let e = r[a++];
		if (a >= r.length) break;
		e === "attributes" ? t.has.attributes = cs(i(r[a++])) : e === "dimensions" ? t.has.dimensions = ls(i(r[a++])) : e === "test_context" ? t.has.testContext = cs(i(r[a++])) : i(r[a++]);
	}
}
var fs = function(e, t) {
	let n = {
		id: e,
		of: "",
		level: "",
		model: "",
		group: "",
		family: "",
		definitionVersions: {},
		has: {
			attributes: {},
			dimensions: {},
			testContext: {}
		},
		referenceIds: []
	}, o = r(t), s = 0;
	for (; s < o.length;) {
		let e = o[s++];
		if (s >= o.length) break;
		e === "of" ? n.of = a(o[s++]) : e === "level" ? n.level = a(o[s++]) : e === "model" ? n.model = a(o[s++]) : e === "group" ? n.group = a(o[s++]) : e === "family" ? n.family = a(o[s++]) : e === "definition_versions" ? n.definitionVersions = ls(i(o[s++])) : e === "has" ? ds(i(o[s++]), n) : e === "reference" ? n.referenceIds = us(o[s++]) : i(o[s++]);
	}
	return (t) => (t.instances[e] = n, t);
};
function ps(e, t) {
	let n = Object.keys(t);
	return n.length === 0 ? "" : "    " + e + " { " + n.map((e) => e + " : " + be(t[e])).join(" ") + " }\n";
}
function ms(e, t) {
	let n = Object.keys(t);
	return n.length === 0 ? "" : "    " + e + " { " + n.map((e) => e + " : " + N(t[e])).join(" ") + " }\n";
}
var hs = {
	keyword: "instance",
	field: "instances",
	takesID: !0,
	parse: fs,
	dump: function(e) {
		let t = "instance " + e.id + " {\n";
		e.of && (t += "  of " + e.of + "\n"), e.level && (t += "  level " + e.level + "\n"), e.model && (t += "  model " + e.model + "\n"), e.group && (t += "  group " + e.group + "\n"), e.family && (t += "  family " + e.family + "\n");
		let n = Object.keys(e.definitionVersions);
		n.length > 0 && (t += "  definition_versions { " + n.map((t) => t + " : " + N(e.definitionVersions[t])).join(" ") + " }\n");
		let r = ps("attributes", e.has.attributes) + ms("dimensions", e.has.dimensions) + ps("test_context", e.has.testContext);
		return r && (t += "  has {\n" + r + "  }\n"), e.referenceIds.length > 0 && (t += "  reference { " + e.referenceIds.join(" ") + " }\n"), t += "}\n", t;
	}
}, gs = [
	"string",
	"designation",
	"serial",
	"year",
	"mark",
	"map"
], _s = ["marked-on-instrument", "accompanying-document"], vs = (e, t) => {
	let r = {
		id: e,
		label: "",
		type: "",
		presentation: [],
		optional: !1,
		definition: "",
		metamodelClass: "",
		source: null
	};
	return v(t, (t, o) => {
		if (t === "label") r.label = a(o());
		else if (t === "type") {
			let t = a(o());
			if (!gs.includes(t)) throw Error(`Parsing error: identity_slot. ID ${e}: Unknown identity slot type "${t}" (valid: ${gs.join(", ")})`);
			r.type = t;
		} else if (t === "presentation") {
			let t = n(a(o())).map(P).map(a).filter((e) => e.length > 0);
			for (let n of t) if (!_s.includes(n)) throw Error(`Parsing error: identity_slot. ID ${e}: Unknown presentation channel "${n}" (valid: ${_s.join(", ")})`);
			r.presentation = t;
		} else if (t === "optional") r.optional = o() === "true";
		else if (t === "definition") r.definition = a(o());
		else if (t === "metamodel_class") r.metamodelClass = a(o());
		else if (t === "source") r.source = I(i(o()));
		else return !1;
		return !0;
	}, {
		construct: "identity_slot",
		id: e
	}), (t) => (t.identitySlots[e] = r, t);
}, ys = function(e) {
	let t = "identity_slot " + e.id + " {\n";
	return e.label && (t += "  label \"" + s(e.label) + "\"\n"), e.type && (t += "  type " + N(e.type) + "\n"), e.presentation.length > 0 && (t += "  presentation { " + e.presentation.map(N).join(" ") + " }\n"), e.optional && (t += "  optional true\n"), e.definition && (t += "  definition \"" + s(e.definition) + "\"\n"), e.metamodelClass && (t += "  metamodel_class " + N(e.metamodelClass) + "\n"), e.source && (e.source.doc || e.source.clause) && (t += "  source {\n", e.source.doc && (t += "    doc \"" + s(e.source.doc) + "\"\n"), e.source.clause && (t += "    clause \"" + s(e.source.clause) + "\"\n"), t += "  }\n"), t += "}\n", t;
}, bs = [
	"marking",
	"inscription",
	"sealing",
	"display",
	"control",
	"interface",
	"power-supply",
	"enclosure",
	"construction",
	"documentation",
	"other"
], xs = (e, t) => {
	let r = {
		id: e,
		label: "",
		kind: "",
		definition: "",
		metamodelClass: "",
		termRef: "",
		component: "",
		attribute: "",
		contains: [],
		source: null
	};
	return v(t, (t, o) => {
		if (t === "label") r.label = a(o());
		else if (t === "kind") {
			let t = a(o());
			if (!bs.includes(t)) throw Error(`Parsing error: aspect. ID ${e}: Unknown aspect kind "${t}" (valid: ${bs.join(", ")})`);
			r.kind = t;
		} else if (t === "definition") r.definition = a(o());
		else if (t === "metamodel_class") r.metamodelClass = a(o());
		else if (t === "term_ref") r.termRef = a(o());
		else if (t === "component") r.component = a(o());
		else if (t === "attribute") r.attribute = a(o());
		else if (t === "contains") r.contains = n(a(o())).map(P).map(a).filter((e) => e.length > 0);
		else if (t === "source") r.source = I(i(o()));
		else return !1;
		return !0;
	}, {
		construct: "aspect",
		id: e
	}), (t) => (t.aspects[e] = r, t);
}, Ss = function(e) {
	let t = "aspect " + e.id + " {\n";
	return e.label && (t += "  label \"" + s(e.label) + "\"\n"), e.kind && (t += "  kind " + N(e.kind) + "\n"), e.definition && (t += "  definition \"" + s(e.definition) + "\"\n"), e.metamodelClass && (t += "  metamodel_class " + N(e.metamodelClass) + "\n"), e.termRef && (t += "  term_ref " + N(e.termRef) + "\n"), e.component && (t += "  component " + N(e.component) + "\n"), e.attribute && (t += "  attribute " + N(e.attribute) + "\n"), e.contains.length > 0 && (t += "  contains { " + e.contains.map(N).join(" ") + " }\n"), e.source && (e.source.doc || e.source.clause) && (t += "  source {\n", e.source.doc && (t += "    doc \"" + s(e.source.doc) + "\"\n"), e.source.clause && (t += "    clause \"" + s(e.source.clause) + "\"\n"), t += "  }\n"), t += "}\n", t;
}, Cs = (e, t) => {
	let n = {
		id: e,
		promises: []
	};
	return v(t, (e, t) => {
		if (e === "promise") {
			let e = a(P(t()));
			n.promises.push(Po(e, i(t())));
		} else return !1;
		return !0;
	}, {
		construct: "promise_set",
		id: e
	}), (t) => (t.promiseSets[e] = n, t);
}, ws = function(e) {
	let t = "promise_set " + N(e.id) + " {\n";
	for (let n of e.promises) t += Yo(n, "  ", "promise ");
	return t += "}\n", t;
}, Ts = [
	"shall",
	"should",
	"may"
], Es = (e, t) => {
	let n = {
		id: e,
		declarationForm: "",
		documents: []
	};
	return v(t, (t, r) => {
		if (t === "declaration_form") n.declarationForm = a(r());
		else if (t === "document") {
			let t = {
				id: a(P(r())),
				name: "",
				description: "",
				obligation: "",
				source: null
			};
			v(i(r()), (n, r) => {
				if (n === "name") t.name = a(r());
				else if (n === "description") t.description = a(r());
				else if (n === "obligation") {
					let n = a(r());
					if (!Ts.includes(n)) throw Error(`Parsing error: application_declaration. ID ${e}: Unknown obligation "${n}" (valid: ${Ts.join(", ")})`);
					t.obligation = n;
				} else if (n === "source") t.source = I(i(r()));
				else return !1;
				return !0;
			}, {
				construct: "application_declaration",
				id: e
			}), n.documents.push(t);
		} else return !1;
		return !0;
	}, {
		construct: "application_declaration",
		id: e
	}), (t) => (t.applicationDeclarations[e] = n, t);
}, Ds = function(e) {
	let t = "application_declaration " + N(e.id) + " {\n";
	e.declarationForm && (t += "  declaration_form " + N(e.declarationForm) + "\n");
	for (let n of e.documents) t += "  document " + N(n.id) + " {\n", n.name && (t += "    name \"" + s(n.name) + "\"\n"), n.description && (t += "    description \"" + s(n.description) + "\"\n"), n.obligation && (t += "    obligation " + N(n.obligation) + "\n"), n.source && (n.source.doc || n.source.clause) && (t += "    source {\n", n.source.doc && (t += "      doc \"" + s(n.source.doc) + "\"\n"), n.source.clause && (t += "      clause \"" + s(n.source.clause) + "\"\n"), t += "    }\n"), t += "  }\n";
	return t += "}\n", t;
}, Os = (e, t) => {
	let n = {
		id: e,
		fields: []
	};
	return v(t, (t, r) => {
		if (t === "field") {
			let t = {
				id: a(P(r())),
				source: "",
				expression: ""
			};
			v(i(r()), (e, n) => {
				if (e === "source") t.source = a(n());
				else if (e === "expression") t.expression = a(n());
				else return !1;
				return !0;
			}, {
				construct: "calculation_context",
				id: e
			}), n.fields.push(t);
		} else return !1;
		return !0;
	}, {
		construct: "calculation_context",
		id: e
	}), (t) => (t.calculationContexts[e] = n, t);
}, ks = function(e) {
	let t = "calculation_context " + N(e.id) + " {\n";
	for (let n of e.fields) {
		let e = "  field " + N(n.id) + " { source " + N(n.source);
		n.expression && (e += " expression \"" + s(n.expression) + "\""), t += e + " }\n";
	}
	return t += "}\n", t;
}, As = [
	"integer",
	"number",
	"string",
	"text",
	"boolean",
	"date"
], js = [
	"MUST",
	"SHALL",
	"RECOMMEND",
	"SHOULD",
	"MAY",
	"OPTIONAL"
], Ms = (e, t) => {
	let n = {
		id: e,
		label: "",
		fields: []
	};
	return v(t, (t, r) => {
		if (t === "label") n.label = a(r());
		else if (t === "field") {
			let t = {
				id: a(P(r())),
				label: "",
				type: "",
				enumRef: "",
				required: !1,
				editable: !0,
				setting: "",
				multiple: !1
			};
			v(i(r()), (n, r) => {
				if (n === "label") t.label = a(r());
				else if (n === "type") {
					let n = a(r());
					if (!As.includes(n)) throw Error(`Parsing error: evaluation_dimensions. ID ${e}: Unknown field type "${n}" (valid: ${As.join(", ")})`);
					t.type = n;
				} else if (n === "enum") t.enumRef = a(r());
				else if (n === "required") t.required = r() === "true";
				else if (n === "editable") t.editable = r() === "true";
				else if (n === "setting") {
					let n = a(r());
					if (!js.includes(n)) throw Error(`Parsing error: evaluation_dimensions. ID ${e}: Unknown setting "${n}" (valid: ${js.join(", ")})`);
					t.setting = n;
				} else if (n === "multiple") t.multiple = r() === "true";
				else return !1;
				return !0;
			}, {
				construct: "evaluation_dimensions",
				id: e
			}), n.fields.push(t);
		} else return !1;
		return !0;
	}, {
		construct: "evaluation_dimensions",
		id: e
	}), (t) => (t.evaluationDimensions[e] = n, t);
}, Ns = function(e) {
	let t = "evaluation_dimensions " + N(e.id) + " {\n";
	e.label && (t += "  label \"" + s(e.label) + "\"\n");
	for (let n of e.fields) t += "  field " + N(n.id) + " {\n", n.label && (t += "    label \"" + s(n.label) + "\"\n"), n.type && (t += "    type " + N(n.type) + "\n"), n.enumRef && (t += "    enum " + N(n.enumRef) + "\n"), t += "    required " + (n.required ? "true" : "false") + "\n", t += "    editable " + (n.editable ? "true" : "false") + "\n", n.setting && (t += "    setting " + N(n.setting) + "\n"), n.multiple && (t += "    multiple true\n"), t += "  }\n";
	return t += "}\n", t;
}, Ps = (e, t) => {
	let r = {
		id: e,
		dimensions: {},
		description: ""
	};
	return v(t, (e, t) => {
		if (e === "dimensions") {
			let e = n(i(t()));
			for (let t = 0; t + 1 < e.length; t += 2) {
				let o = a(P(e[t])), s = e[t + 1], c = s.startsWith("{") ? n(i(s)).map((e) => a(e)) : a(s);
				o && (r.dimensions[o] = c);
			}
		} else if (e === "description") r.description = a(t());
		else return !1;
		return !0;
	}, {
		construct: "evaluation_profile",
		id: e
	}), (t) => (t.evaluationProfiles[e] = r, t);
}, Fs = function(e) {
	let t = "evaluation_profile " + N(e.id) + " {\n", n = Object.keys(e.dimensions);
	return n.length > 0 && (t += "  dimensions { " + n.map((t) => {
		let n = e.dimensions[t];
		return Array.isArray(n) ? N(t) + " { " + n.map(N).join(" ") + " }" : N(t) + " " + N(n);
	}).join(" ") + " }\n"), e.description && (t += "  description \"" + s(e.description) + "\"\n"), t += "}\n", t;
}, Is = ["mandatory", "optional"];
function Ls(e) {
	return n(a(e)).map(P).map(a).filter((e) => e.length > 0);
}
var Rs = (e, t) => {
	let n = {
		id: e,
		numberFormat: "",
		dimensionLabels: null,
		characteristics: [],
		anrSection: null
	};
	return v(t, (t, r) => {
		if (t === "number_format") n.numberFormat = a(r());
		else if (t === "dimension_labels") {
			let t = {
				pattern: "",
				separator: ""
			};
			v(i(r()), (e, n) => {
				if (e === "pattern") t.pattern = a(n());
				else if (e === "separator") t.separator = a(n());
				else return !1;
				return !0;
			}, {
				construct: "certificate_template",
				id: e
			}), n.dimensionLabels = t;
		} else if (t === "characteristic") {
			let t = {
				id: a(P(r())),
				type: "",
				label: "",
				attribute: "",
				attributes: [],
				dimension: "",
				obligation: ""
			};
			v(i(r()), (n, r) => {
				if (n === "type") t.type = a(r());
				else if (n === "label") t.label = a(r());
				else if (n === "attribute") t.attribute = a(r());
				else if (n === "attributes") t.attributes = Ls(r());
				else if (n === "dimension") t.dimension = a(r());
				else if (n === "obligation") {
					let n = a(r());
					if (!Is.includes(n)) throw Error(`Parsing error: certificate_template. ID ${e}: Unknown obligation "${n}" (valid: ${Is.join(", ")})`);
					t.obligation = n;
				} else return !1;
				return !0;
			}, {
				construct: "certificate_template",
				id: e
			}), n.characteristics.push(t);
		} else if (t === "anr_section") {
			let t = {
				title: "",
				coveredLabel: "",
				notEvaluatedLabel: "",
				pendingLabel: "",
				noneTargetedNote: ""
			};
			v(i(r()), (e, n) => {
				if (e === "title") t.title = a(n());
				else if (e === "covered_label") t.coveredLabel = a(n());
				else if (e === "not_evaluated_label") t.notEvaluatedLabel = a(n());
				else if (e === "pending_label") t.pendingLabel = a(n());
				else if (e === "none_targeted_note") t.noneTargetedNote = a(n());
				else return !1;
				return !0;
			}, {
				construct: "certificate_template",
				id: e
			}), n.anrSection = t;
		} else return !1;
		return !0;
	}, {
		construct: "certificate_template",
		id: e
	}), (t) => (t.certificateTemplates[e] = n, t);
}, zs = function(e) {
	let t = "certificate_template " + N(e.id) + " {\n";
	e.numberFormat && (t += "  number_format \"" + s(e.numberFormat) + "\"\n"), e.dimensionLabels && (t += "  dimension_labels {\n", t += "    pattern \"" + s(e.dimensionLabels.pattern) + "\"\n", e.dimensionLabels.separator && (t += "    separator \"" + s(e.dimensionLabels.separator) + "\"\n"), t += "  }\n");
	for (let n of e.characteristics) t += "  characteristic " + N(n.id) + " {\n", n.type && (t += "    type " + N(n.type) + "\n"), n.label && (t += "    label \"" + s(n.label) + "\"\n"), n.attribute && (t += "    attribute " + N(n.attribute) + "\n"), n.attributes.length > 0 && (t += "    attributes { " + n.attributes.map(N).join(" ") + " }\n"), n.dimension && (t += "    dimension " + N(n.dimension) + "\n"), n.obligation && (t += "    obligation " + n.obligation + "\n"), t += "  }\n";
	if (e.anrSection) {
		let n = e.anrSection;
		t += "  anr_section {\n", n.title && (t += "    title \"" + s(n.title) + "\"\n"), n.coveredLabel && (t += "    covered_label \"" + s(n.coveredLabel) + "\"\n"), n.notEvaluatedLabel && (t += "    not_evaluated_label \"" + s(n.notEvaluatedLabel) + "\"\n"), n.pendingLabel && (t += "    pending_label \"" + s(n.pendingLabel) + "\"\n"), n.noneTargetedNote && (t += "    none_targeted_note \"" + s(n.noneTargetedNote) + "\"\n"), t += "  }\n";
	}
	return t += "}\n", t;
};
//#endregion
//#region src/ser-des/config/artifact.ts
function Bs(e) {
	return n(a(e)).map(P).map(a).filter((e) => e.length > 0);
}
function Vs(e, t, n) {
	return t.length === 0 ? "" : `${n}${e} { ${t.join(" ")} }\n`;
}
function Hs(e) {
	return n(a(e)).map(a).filter((e) => e.length > 0);
}
function Us(e) {
	let t = [], r = n(e), i = 0;
	for (; i < r.length;) {
		let e = P(r[i++]);
		if (!e) break;
		r[i] === ":" && i++;
		let n = "";
		i < r.length && r[i] !== ":" && (n = a(r[i++]));
		let o = !1;
		r[i] === "optional" && (o = !0, i++);
		let s = "";
		i < r.length && r[i].startsWith("\"") && (s = a(r[i++])), t.push({
			name: e,
			type: n,
			optional: o,
			description: s
		});
	}
	return t;
}
function Ws(e) {
	let t = [], r = n(e), o = 0;
	for (; o < r.length;) {
		let e = P(r[o++]);
		if (!e) break;
		let s = {
			field: e,
			kinds: [],
			role: ""
		};
		if (o < r.length && r[o].startsWith("{")) {
			let e = n(i(r[o++])), t = 0;
			for (; t < e.length;) {
				let n = e[t++];
				if (t >= e.length) break;
				n === "kinds" ? s.kinds = Bs(e[t++]) : n === "role" ? s.role = a(e[t++]) : i(e[t++]);
			}
		}
		t.push(s);
	}
	return t;
}
function Gs(e) {
	let t = {
		fields: [],
		structure: "",
		media: []
	}, r = n(e), o = 0;
	for (; o < r.length;) {
		let e = r[o++];
		if (o >= r.length) break;
		e === "fields" ? t.fields = Us(i(r[o++])) : e === "structure" ? t.structure = a(r[o++]) : e === "media" ? t.media = Ws(i(r[o++])) : o = y(r, o, e);
	}
	return t;
}
var Ks = function(e, t) {
	let n = {
		id: e,
		name: "",
		description: "",
		contentContract: {
			fields: [],
			structure: "",
			media: []
		},
		producedWhen: { kind: "" },
		retention: "",
		source: null,
		referenceIds: []
	}, o = r(t), s = 0;
	for (; s < o.length;) {
		let e = o[s++];
		if (s >= o.length) break;
		if (e === "name") n.name = a(o[s++]);
		else if (e === "description") n.description = a(o[s++]);
		else if (e === "content_contract") n.contentContract = Gs(i(o[s++]));
		else if (e === "produced_when") {
			let e = a(o[s++] ?? "");
			n.producedWhen = e === "per_interval" ? {
				kind: e,
				interval: a(o[s++] ?? "")
			} : e === "on_event" ? {
				kind: e,
				event: a(o[s++] ?? "")
			} : { kind: e };
		} else if (e === "retention") n.retention = a(o[s++]);
		else if (e === "source") {
			let e = I(i(o[s++]));
			(n.sourceRefs ??= []).push(e), n.source ||= e;
		} else if (e === "reference") n.referenceIds = Hs(o[s++]);
		else if (e === "ref") {
			let e = S(o, s, a, i);
			T(n, e.ref) || (n.refs ??= []).push(e.ref), s = e.next;
		} else if (e === "corresponds") {
			let e = D(o, s, a);
			(n.correspondences ??= []).push(e.corr), s = e.next;
		} else s = y(o, s, e);
	}
	return (t) => (t.artifactDefinitions[e] = n, t);
};
function qs(e) {
	return e.kind === "per_interval" ? `per_interval ${N(e.interval ?? "")}` : e.kind === "on_event" ? `on_event ${N(e.event ?? "")}` : e.kind;
}
var Js = function(e) {
	let t = "artifact_definition " + e.id + " {\n";
	e.name && (t += "  name \"" + s(e.name) + "\"\n"), e.description && (t += "  description \"" + s(e.description) + "\"\n");
	let n = e.contentContract;
	if (n.fields.length > 0 || n.structure || n.media.length > 0) {
		if (t += "  content_contract {\n", n.fields.length > 0) {
			t += "    fields {\n";
			for (let e of n.fields) t += "      " + e.name + " : " + N(e.type) + (e.optional ? " optional" : "") + (e.description ? " \"" + s(e.description) + "\"" : "") + "\n";
			t += "    }\n";
		}
		if (n.structure && (t += "    structure \"" + s(n.structure) + "\"\n"), n.media.length > 0) {
			t += "    media {\n";
			for (let e of n.media) {
				let n = "      " + e.field + " { ";
				e.kinds.length > 0 && (n += "kinds { " + e.kinds.join(" ") + " } "), e.role && (n += "role \"" + s(e.role) + "\" "), t += n + "}\n";
			}
			t += "    }\n";
		}
		t += "  }\n";
	}
	e.producedWhen.kind && (t += "  produced_when " + qs(e.producedWhen) + "\n"), e.retention && (t += "  retention \"" + s(e.retention) + "\"\n");
	let r = e.sourceRefs && e.sourceRefs.length > 0 ? e.sourceRefs : e.source ? [e.source] : [];
	for (let e of r) t += E(e, "  ", s);
	return t += w(e.refs, "  ", s), t += k(e.correspondences, "  ", s, N), t += Vs("reference", e.referenceIds, "  "), t += "}\n", t;
}, Ys = function(e, t) {
	let n = {
		id: e,
		of: "",
		producedAt: "",
		by: "",
		content: {},
		links: [],
		referenceIds: []
	}, o = r(t), s = 0;
	for (; s < o.length;) {
		let e = o[s++];
		if (s >= o.length) break;
		e === "of" ? n.of = a(o[s++]) : e === "produced_at" ? n.producedAt = a(o[s++]) : e === "by" ? n.by = a(o[s++]) : e === "content" ? n.content = cs(i(o[s++])) : e === "links" ? n.links = Bs(o[s++]) : e === "reference" ? n.referenceIds = Hs(o[s++]) : s = y(o, s, e);
	}
	return (t) => (t.artifactInstances[e] = n, t);
}, Xs = function(e) {
	let t = "artifact_instance " + e.id + " {\n";
	e.of && (t += "  of " + e.of + "\n"), e.producedAt && (t += "  produced_at " + N(e.producedAt) + "\n"), e.by && (t += "  by " + N(e.by) + "\n");
	let n = Object.keys(e.content);
	return n.length > 0 && (t += "  content { " + n.map((t) => t + " : " + be(e.content[t])).join(" ") + " }\n"), t += Vs("links", e.links, "  "), t += Vs("reference", e.referenceIds, "  "), t += "}\n", t;
}, Zs = {
	keyword: "artifact_definition",
	field: "artifactDefinitions",
	takesID: !0,
	parse: Ks,
	dump: Js
}, Qs = {
	keyword: "artifact_instance",
	field: "artifactInstances",
	takesID: !0,
	parse: Ys,
	dump: Xs
}, $s = F;
function ec(e, t) {
	let n = e[t] ?? "";
	if (n.startsWith("{")) return {
		selector: {
			kind: "refs",
			expression: "",
			refs: $s(n)
		},
		next: t + 1
	};
	if (n.startsWith("applicable_to(")) {
		let r = (e) => (e.match(/\(/g) || []).length - (e.match(/\)/g) || []).length, i = n, a = r(n), o = t + 1;
		for (; a > 0 && o < e.length;) i += " " + e[o], a += r(e[o]), o++;
		return {
			selector: {
				kind: "applicable_to",
				expression: i.slice(14, i.endsWith(")") ? -1 : void 0).trim(),
				refs: []
			},
			next: o
		};
	}
	return {
		selector: {
			kind: a(n),
			expression: "",
			refs: []
		},
		next: t + 1
	};
}
function tc(e) {
	let t = [], n = se(e), r = 0;
	for (; r < n.length;) {
		let e = n[r++];
		if (e === "every") t.push({
			kind: "timer",
			every: a(n[r++] ?? ""),
			signal: "",
			aspect: ""
		});
		else if (e === "on") {
			let e = n[r++] ?? "", i = a(n[r++] ?? "");
			e === "signal" ? t.push({
				kind: "signal",
				every: "",
				signal: i,
				aspect: ""
			}) : e === "change" ? t.push({
				kind: "change",
				every: "",
				signal: "",
				aspect: i
			}) : t.push({
				kind: e,
				every: "",
				signal: "",
				aspect: i
			});
		}
	}
	return t;
}
function nc(e) {
	let t = {
		requirements: {
			kind: "",
			expression: "",
			refs: []
		},
		promises: {
			kind: "",
			expression: "",
			refs: []
		}
	}, n = se(e), r = 0;
	for (; r < n.length;) {
		let e = n[r++];
		if (e === "requirements" || e === "promises") {
			let i = ec(n, r);
			t[e] = i.selector, r = i.next;
		}
	}
	return t;
}
function rc(e) {
	let t = [], n = se(e), r = 0;
	for (; r < n.length;) {
		let e = n[r++];
		n[r] === "->" ? (r++, t.push({
			stream: e,
			target: a(n[r++] ?? "")
		})) : t.push({
			stream: e,
			target: ""
		});
	}
	return t;
}
function ic(e) {
	let t = [], n = se(e), r = 0;
	for (; r < n.length;) {
		let e = n[r++];
		e === "notify" ? t.push({
			action: "notify",
			role: a(n[r++] ?? "")
		}) : t.push({
			action: e,
			role: ""
		});
	}
	return t;
}
function ac(e) {
	let t = [], n = r(e), o = 0;
	for (; o < n.length;) {
		if (n[o++] !== "on") continue;
		let e = P(a(n[o++] ?? ""));
		if (o < n.length && n[o].startsWith("{")) {
			t.push({
				outcome: e,
				actions: ic(i(n[o++]))
			});
			continue;
		}
		let r = [];
		for (; o < n.length && n[o] !== "on";) {
			let e = P(n[o++].replace(/^;+|;+$/g, ""));
			e !== "" && (e === "notify" ? r.push({
				action: "notify",
				role: a(n[o++] ?? "")
			}) : r.push({
				action: e,
				role: ""
			}));
		}
		t.push({
			outcome: e,
			actions: r
		});
	}
	return t;
}
var oc = function(e, t) {
	let n = {
		id: e,
		over: [],
		triggers: [],
		evaluate: {
			requirements: {
				kind: "",
				expression: "",
				refs: []
			},
			promises: {
				kind: "",
				expression: "",
				refs: []
			}
		},
		emit: [],
		escalate: [],
		referenceIds: []
	};
	return v(t, (e, t) => {
		if (e === "over") n.over = $s(t());
		else if (e === "triggers") n.triggers = tc(i(t()));
		else if (e === "evaluate") n.evaluate = nc(i(t()));
		else if (e === "emit") n.emit = rc(i(t()));
		else if (e === "escalate") n.escalate = ac(i(t()));
		else if (e === "reference") n.referenceIds = $s(t());
		else return !1;
		return !0;
	}, {
		construct: "monitor",
		id: e
	}), (t) => (t.monitors[e] = n, t);
};
function sc(e) {
	return e.kind === "timer" ? "every " + N(e.every) : e.kind === "signal" ? "on signal " + N(e.signal) : e.kind === "change" ? "on change " + N(e.aspect) : "on " + N(e.kind);
}
function cc(e) {
	return e.kind === "applicable_to" ? "applicable_to(" + e.expression + ")" : e.kind === "refs" ? "{ " + e.refs.map(N).join(" ") + " }" : N(e.kind);
}
function lc(e) {
	let t = e.actions.map((e) => e.action === "notify" ? "notify " + N(e.role) : N(e.action)).join(" ");
	return "on " + N(e.outcome) + " { " + t + " }";
}
var uc = {
	keyword: "monitor",
	field: "monitors",
	takesID: !0,
	parse: oc,
	dump: function(e) {
		let t = "monitor " + e.id + " {\n";
		e.over.length > 0 && (t += "  over { " + e.over.map(N).join(" ") + " }\n"), e.triggers.length > 0 && (t += "  triggers { " + e.triggers.map(sc).join(" ") + " }\n");
		let n = e.evaluate.requirements, r = e.evaluate.promises;
		return (n.kind || r.kind) && (t += "  evaluate {", n.kind && (t += " requirements " + cc(n)), r.kind && (t += " promises " + cc(r)), t += " }\n"), e.emit.length > 0 && (t += "  emit { " + e.emit.map((e) => e.stream + " -> " + N(e.target)).join(" ") + " }\n"), e.escalate.length > 0 && (t += "  escalate { " + e.escalate.map(lc).join(" ") + " }\n"), e.referenceIds.length > 0 && (t += "  reference { " + e.referenceIds.map(N).join(" ") + " }\n"), t += "}\n", t;
	}
}, dc = [
	"identity",
	"composition",
	"promises_as_verified",
	"live_compliance_status",
	"artifacts",
	"sustainability"
], fc = [
	"public",
	"restricted",
	"authority"
], pc = [
	"model",
	"batch",
	"item"
];
//#endregion
//#region src/ser-des/config/passport.ts
function mc(e, t) {
	return F(t).map((t) => {
		let n = t.indexOf(".");
		return n === -1 ? {
			access: e,
			contentClass: t,
			ref: ""
		} : {
			access: e,
			contentClass: t.slice(0, n),
			ref: t.slice(n + 1)
		};
	});
}
var hc = function(e, t) {
	let n = {
		id: e,
		upi: {
			pattern: "",
			level: ""
		},
		carriers: [],
		entries: [],
		referenceIds: []
	};
	return v(t, (t, r) => {
		if (t === "upi") v(i(r()), (e, t) => {
			if (e === "pattern") n.upi.pattern = a(t());
			else if (e === "level") n.upi.level = a(t());
			else return !1;
			return !0;
		}, {
			construct: "passport.upi",
			id: e
		});
		else if (t === "identifier") n.upi.pattern = a(r());
		else if (t === "carrier") {
			let t = {
				kind: "",
				payload: ""
			};
			v(i(r()), (e, n) => {
				if (e === "kind") t.kind = a(n());
				else if (e === "payload") t.payload = a(n());
				else return !1;
				return !0;
			}, {
				construct: "passport.carrier",
				id: e
			}), n.carriers.push(t);
		} else if (t === "reference") n.referenceIds = F(r());
		else {
			let i = r();
			if (fc.includes(t)) n.entries.push(...mc(t, i));
			else if (i.startsWith("{")) throw Error(`Parsing error: passport. ID ${e}: unknown access class "${t}" — access classes are ${fc.join(" | ")} (fail-closed: an unknown access class is never served)`);
		}
		return !0;
	}, {
		construct: "passport",
		id: e
	}), (t) => (t.passports[e] = n, t);
};
function gc(e) {
	return N(e.ref === "" ? e.contentClass : e.contentClass + "." + e.ref);
}
var _c = {
	keyword: "passport",
	field: "passports",
	takesID: !0,
	parse: hc,
	dump: function(e) {
		let t = "passport " + e.id + " {\n";
		(e.upi.pattern !== "" || e.upi.level !== "") && (t += "  upi {", e.upi.pattern !== "" && (t += " pattern " + N(e.upi.pattern)), e.upi.level !== "" && (t += " level " + N(e.upi.level)), t += " }\n");
		for (let n of e.carriers) t += "  carrier { kind " + N(n.kind) + " payload " + N(n.payload) + " }\n";
		let n = [...fc, ...[...new Set(e.entries.map((e) => e.access))].filter((e) => !fc.includes(e))];
		for (let r of n) {
			let n = e.entries.filter((e) => e.access === r);
			n.length > 0 && (t += "  " + r + " { " + n.map(gc).join(" ") + " }\n");
		}
		return e.referenceIds.length > 0 && (t += "  reference { " + e.referenceIds.map(N).join(" ") + " }\n"), t += "}\n", t;
	}
}, vc = {
	keyword: "invariant",
	field: "invariants",
	takesID: !0,
	parse: function(e, t) {
		let n = {
			id: e,
			name: "",
			statement: "",
			severity: "",
			appliesTo: [],
			source: "",
			enforcement: {
				aspirational: !1,
				claims: []
			}
		};
		return v(t, (e, t) => {
			if (e === "name") n.name = a(t());
			else if (e === "statement") n.statement = a(t());
			else if (e === "severity") n.severity = a(t());
			else if (e === "applies_to") n.appliesTo.push(...F(t()));
			else if (e === "source") n.source = a(t());
			else if (e === "enforcement") {
				let e = t();
				!e.startsWith("{") && a(e) === "aspirational" ? n.enforcement.aspirational = !0 : n.enforcement.claims.push(...F(e));
			} else return !1;
			return !0;
		}, {
			construct: "invariant",
			id: e
		}), (t) => (t.invariants[e] = n, t);
	},
	dump: function(e) {
		let t = "invariant " + e.id + " {\n";
		return e.name !== "" && (t += "  name \"" + s(e.name) + "\"\n"), e.statement !== "" && (t += "  statement \"" + s(e.statement) + "\"\n"), e.severity !== "" && (t += "  severity " + N(e.severity) + "\n"), e.appliesTo.length > 0 && (t += "  applies_to { " + e.appliesTo.map(N).join(" ") + " }\n"), e.source !== "" && (t += "  source \"" + s(e.source) + "\"\n"), e.enforcement.aspirational && (t += "  enforcement aspirational\n"), e.enforcement.claims.length > 0 && (t += "  enforcement { " + e.enforcement.claims.map(N).join(" ") + " }\n"), t += "}\n", t;
	}
};
//#endregion
//#region src/ser-des/config/testSequence.ts
function yc(e, t, n) {
	v(e, (e, n) => {
		if (e === "test") t.test = a(n());
		else if (e === "phase") t.phase = a(n());
		else if (e === "role") t.role = a(n());
		else if (e === "depends_on") t.dependsOn = Number(a(n()));
		else return !1;
		return !0;
	}, {
		construct: "test_sequence.step",
		id: n
	});
}
var bc = {
	keyword: "test_sequence",
	field: "testSequences",
	takesID: !0,
	parse: function(e, t) {
		let n = {
			id: e,
			name: "",
			description: "",
			steps: [],
			sampleApplicability: "",
			sourceRefs: []
		}, o = r(t), s = 0;
		for (; s < o.length;) {
			let t = o[s++];
			if (s >= o.length) throw Error(`Parsing error: test_sequence. ID ${e}: Expecting value for ${t}`);
			if (t === "name") n.name = a(o[s++]);
			else if (t === "description") n.description = a(o[s++]);
			else if (t === "sample_applicability") n.sampleApplicability = a(o[s++]);
			else if (t === "ref") {
				let e = S(o, s, a, i);
				T(n, e.ref) || (n.refs = [...n.refs ?? [], e.ref]), s = e.next;
			} else if (t === "corresponds") {
				let e = D(o, s, a);
				n.correspondences = [...n.correspondences ?? [], e.corr], s = e.next;
			} else if (t === "source") n.sourceRefs.push(I(i(o[s++])));
			else if (t === "step") {
				let t = {
					order: null,
					test: "",
					phase: "",
					role: "",
					dependsOn: null
				}, r = o[s++];
				r.startsWith("{") || (t.order = Number(a(r)), r = s < o.length && o[s].startsWith("{") ? o[s++] : ""), r.startsWith("{") && yc(i(r), t, e), n.steps.push(t);
			} else s++;
		}
		return (t) => (t.testSequences[e] = n, t);
	},
	dump: function(e) {
		let t = "test_sequence " + e.id + " {\n";
		e.name !== "" && (t += "  name \"" + s(e.name) + "\"\n"), e.description !== "" && (t += "  description \"" + s(e.description) + "\"\n");
		for (let n of e.steps) t += "  step" + (n.order === null ? "" : " " + n.order) + " {", n.test !== "" && (t += " test \"" + s(n.test) + "\""), n.phase !== "" && (t += " phase \"" + s(n.phase) + "\""), n.role !== "" && (t += " role " + N(n.role)), n.dependsOn !== null && (t += " depends_on " + n.dependsOn), t += " }\n";
		e.sampleApplicability !== "" && (t += "  sample_applicability " + N(e.sampleApplicability) + "\n");
		for (let n of e.refs ?? []) t += "  ref " + n.predicate + " \"" + s(n.target) + "\"" + (n.note ? " { note \"" + s(n.note) + "\" }" : "") + "\n";
		for (let n of e.sourceRefs) t += E(n, "  ", s);
		return t += k(e.correspondences, "  ", s, N), t += "}\n", t;
	}
}, xc = {
	keyword: "formulas_used",
	field: "formulasUsed",
	takesID: !0,
	parse: function(e, t) {
		let n = {
			id: e,
			name: "",
			description: "",
			formulas: [],
			sourceRefs: []
		};
		return v(t, (e, t, r) => {
			if (e === "name") n.name = a(t());
			else if (e === "description") n.description = a(t());
			else if (e === "formulas") n.formulas.push(...F(t()));
			else if (e === "ref") {
				let e = C(t, r, a, i);
				T(n, e) || (n.refs ??= []).push(e);
			} else if (e === "corresponds") (n.correspondences ??= []).push(O(t, r, a));
			else if (e === "source") n.sourceRefs.push(I(i(t())));
			else return !1;
			return !0;
		}, {
			construct: "formulas_used",
			id: e
		}), (t) => (t.formulasUsed[e] = n, t);
	},
	dump: function(e) {
		let t = "formulas_used " + e.id + " {\n";
		e.name !== "" && (t += "  name \"" + s(e.name) + "\"\n"), e.description !== "" && (t += "  description \"" + s(e.description) + "\"\n"), e.formulas.length > 0 && (t += "  formulas { " + e.formulas.map(N).join(" ") + " }\n");
		for (let n of e.refs ?? []) t += "  ref " + n.predicate + " \"" + s(n.target) + "\"" + (n.note ? " { note \"" + s(n.note) + "\" }" : "") + "\n";
		for (let n of e.sourceRefs) t += E(n, "  ", s);
		return t += k(e.correspondences, "  ", s, N), t += "}\n", t;
	}
}, Sc = function(e, t) {
	let n = {
		id: e,
		entries: []
	}, i = r(t), a = 0;
	for (; a < i.length;) {
		let t = i[a++];
		if (t !== "spell") throw Error(`Parsing error: text. ID ${e}: unknown facet "${t}" (a text block carries spell facets only)`);
		if (a >= i.length) throw Error(`Parsing error: text. ID ${e}: Expecting spelling code for spell`);
		let r = i[a++], s;
		if (i[a] === "via") {
			if (a++, a >= i.length) throw Error(`Parsing error: text. ID ${e}: Expecting conversion system code after via`);
			s = i[a++];
		}
		let c = i[a++];
		if (c === void 0 || c.length < 2 || c.charAt(0) !== "\"" || c.charAt(c.length - 1) !== "\"") throw Error(`Parsing error: text. ID ${e}: spell ${r} expects a quoted value — spell <code> [via <system-code>] "<value>"`);
		let l = {
			spelling: r,
			value: o(c.slice(1, -1))
		};
		s === void 0 ? n.entries.push(l) : n.entries.push({
			...l,
			via: s
		});
	}
	return (t) => {
		let r = t.texts[e];
		return r ? r.entries.push(...n.entries) : t.texts[e] = n, t;
	};
}, Cc = function(e) {
	let t = "text " + e.id + " {\n";
	for (let n of e.entries) t += "  spell " + n.spelling + (n.via ? " via " + n.via : "") + " \"" + s(n.value) + "\"\n";
	return t += "}\n", t;
};
//#endregion
//#region src/ser-des/config/quantityRegister.ts
function wc(e) {
	let t = {}, r = n(e);
	for (let e = 0; e + 1 < r.length; e += 2) {
		let n = P(r[e]), i = Number(r[e + 1]);
		n && !Number.isNaN(i) && (t[n] = i);
	}
	return t;
}
function Tc(e, t) {
	let n = Number(a(e));
	return Number.isNaN(n) ? t : n;
}
function Ec(e, t) {
	let r = {
		id: e,
		dimensions: {},
		siUnit: "",
		description: ""
	}, o = n(t), s = 0;
	for (; s < o.length;) {
		let e = o[s++];
		if (s >= o.length) break;
		if (e === "dimensions") r.dimensions = wc(i(o[s++]));
		else if (e === "si_unit") r.siUnit = a(o[s++]);
		else if (e === "description") r.description = a(o[s++]);
		else if (e === "corresponds") {
			let { corr: e, next: t } = D(o, s, a);
			(r.correspondences ??= []).push(e), s = t;
		} else i(o[s++]);
	}
	return r;
}
function Dc(e, t) {
	let r = {
		id: e,
		symbol: "",
		label: "",
		kind: "",
		factorToSI: 1,
		offsetToSI: 0,
		definition: ""
	}, o = n(t), s = 0;
	for (; s < o.length;) {
		let e = o[s++];
		if (s >= o.length) break;
		if (e === "symbol") r.symbol = a(o[s++]);
		else if (e === "label") r.label = a(o[s++]);
		else if (e === "kind") r.kind = a(o[s++]);
		else if (e === "factor") r.factorToSI = Tc(o[s++], 1);
		else if (e === "offset") r.offsetToSI = Tc(o[s++], 0);
		else if (e === "definition") r.definition = a(o[s++]);
		else if (e === "corresponds") {
			let { corr: e, next: t } = D(o, s, a);
			(r.correspondences ??= []).push(e), s = t;
		} else i(o[s++]);
	}
	return r;
}
var Oc = function(e, t) {
	let o = {
		id: e,
		kinds: [],
		units: [],
		referenceIds: []
	}, s = r(t), c = 0;
	for (; c < s.length;) {
		let e = s[c++];
		if (c >= s.length) break;
		e === "kind" ? o.kinds.push(Ec(P(s[c++]), i(s[c++]))) : e === "unit" ? o.units.push(Dc(P(s[c++]), i(s[c++]))) : e === "reference" ? o.referenceIds = n(a(s[c++])).map(a).filter((e) => e.length > 0) : i(s[c++]);
	}
	return (t) => (t.quantityRegisters[e] = o, t);
};
function kc(e) {
	let t = "";
	for (let n of e ?? []) if (t += " corresponds " + N(n.scheme) + " \"" + s(n.concept) + "\"", n.projections.length > 0) {
		t += " {";
		for (let e of n.projections) {
			t += " projection " + N(e.codec) + " {";
			for (let n of e.entries) t += " " + N(n.key) + " " + N(n.value);
			t += " }";
		}
		t += " }";
	}
	return t;
}
function Ac(e) {
	let t = Object.keys(e);
	return t.length === 0 ? "" : " dimensions { " + t.map((t) => t + " " + e[t]).join(" ") + " }";
}
var jc = {
	keyword: "quantity_register",
	field: "quantityRegisters",
	takesID: !0,
	parse: Oc,
	dump: function(e) {
		let t = "quantity_register " + e.id + " {\n";
		for (let n of e.kinds) {
			let e = "  kind " + n.id + " {" + Ac(n.dimensions);
			n.siUnit && (e += " si_unit \"" + s(n.siUnit) + "\""), n.description && (e += " description \"" + s(n.description) + "\""), e += kc(n.correspondences), t += e + " }\n";
		}
		for (let n of e.units) {
			let e = "  unit " + N(n.id) + " {";
			n.symbol && (e += " symbol \"" + s(n.symbol) + "\""), n.label && (e += " label \"" + s(n.label) + "\""), n.kind && (e += " kind " + n.kind), n.factorToSI !== 1 && (e += " factor " + n.factorToSI), n.offsetToSI !== 0 && (e += " offset " + n.offsetToSI), n.definition && (e += " definition \"" + s(n.definition) + "\""), e += kc(n.correspondences), t += e + " }\n";
		}
		return e.referenceIds.length > 0 && (t += "  reference { " + e.referenceIds.join(" ") + " }\n"), t += "}\n", t;
	}
}, Mc = {
	keyword: "dual",
	field: "duals",
	takesID: !0,
	parse: function(e, t) {
		let o = {
			id: e,
			attribute: "",
			referenceIds: []
		}, s = r(t), c = 0;
		for (; c < s.length;) {
			let e = s[c++];
			if (c >= s.length) break;
			e === "attribute" ? o.attribute = a(s[c++]) : e === "designed" ? o.designed = ve(i(s[c++])) : e === "exhibited" ? o.exhibited = ve(i(s[c++])) : e === "reference" ? o.referenceIds = n(a(s[c++])).map(a).filter((e) => e.length > 0) : i(s[c++]);
		}
		return (t) => (t.duals[e] = o, t);
	},
	dump: function(e) {
		let t = "dual " + e.id + " {\n";
		return e.attribute && (t += "  attribute " + e.attribute + "\n"), e.designed && (t += "  designed " + xe(e.designed) + "\n"), e.exhibited && (t += "  exhibited " + xe(e.exhibited) + "\n"), e.referenceIds.length > 0 && (t += "  reference { " + e.referenceIds.join(" ") + " }\n"), t += "}\n", t;
	}
};
//#endregion
//#region src/ser-des/config/trustRef.ts
function Nc(e, t, n) {
	let r = {
		org: n(e()),
		kid: ""
	};
	return t() === "key" && (e(), r.kid = n(e())), r;
}
function Pc(e, t, n) {
	let r = `${t}trust_ref ${n(e.org)}`;
	return e.kid !== "" && (r += ` key ${n(e.kid)}`), r + "\n";
}
var Fc = {
	keyword: "dataspace",
	field: "dataspaces",
	takesID: !0,
	parse: function(e, t) {
		let n = {
			id: e,
			name: "",
			description: "",
			participantClasses: [],
			artifactClasses: [],
			policies: [],
			defaultPolicy: "",
			trustAnchors: [],
			compatibleWith: [],
			source: null,
			sourceRefs: []
		};
		return v(t, (e, t, r) => {
			if (e === "name") n.name = x(t);
			else if (e === "description") n.description = x(t);
			else if (e === "participant_class") {
				let e = {
					id: a(t()),
					label: "",
					description: ""
				}, o = r();
				o && o.startsWith("{") && v(i(t()), (t, n) => {
					if (t === "label") e.label = x(n);
					else if (t === "description") e.description = x(n);
					else return !1;
					return !0;
				}, {
					construct: "dataspace.participant_class",
					id: e.id
				}), n.participantClasses.push(e);
			} else if (e === "artifact_class") {
				let e = {
					id: a(t()),
					label: "",
					description: "",
					element: "",
					policy: ""
				}, o = r();
				o && o.startsWith("{") && v(i(t()), (t, n) => {
					if (t === "label") e.label = x(n);
					else if (t === "description") e.description = x(n);
					else if (t === "element") e.element = a(n());
					else if (t === "policy") e.policy = a(n());
					else return !1;
					return !0;
				}, {
					construct: "dataspace.artifact_class",
					id: e.id
				}), n.artifactClasses.push(e);
			} else if (e === "policies") n.policies = F(t());
			else if (e === "default_policy") n.defaultPolicy = a(t());
			else if (e === "trust_anchor") {
				let e = {
					id: a(t()),
					trustRef: null,
					role: "",
					description: ""
				}, o = r();
				o && o.startsWith("{") && v(i(t()), (t, n, r) => {
					if (t === "trust_ref") e.trustRef = Nc(n, r, a);
					else if (t === "role") e.role = a(n());
					else if (t === "description") e.description = x(n);
					else return !1;
					return !0;
				}, {
					construct: "dataspace.trust_anchor",
					id: e.id
				}), n.trustAnchors.push(e);
			} else if (e === "compatible_with") n.compatibleWith = F(t());
			else if (e === "source") {
				let e = I(i(t()));
				n.sourceRefs.push(e), n.source ||= e;
			} else if (e === "ref") {
				let e = C(t, r, a, i);
				T(n, e) || (n.refs ??= []).push(e);
			} else if (e === "corresponds") (n.correspondences ??= []).push(O(t, r, a));
			else return !1;
			return !0;
		}, {
			construct: "dataspace",
			id: e
		}), (t) => (t.dataspaces[e] = n, t);
	},
	dump: function(e) {
		let t = "dataspace " + e.id + " {\n";
		e.name && (t += "  name \"" + s(e.name) + "\"\n"), e.description && (t += "  description \"" + s(e.description) + "\"\n");
		for (let n of e.participantClasses) t += "  participant_class " + N(n.id) + " {\n", n.label && (t += "    label \"" + s(n.label) + "\"\n"), n.description && (t += "    description \"" + s(n.description) + "\"\n"), t += "  }\n";
		for (let n of e.artifactClasses) t += "  artifact_class " + N(n.id) + " {\n", n.label && (t += "    label \"" + s(n.label) + "\"\n"), n.description && (t += "    description \"" + s(n.description) + "\"\n"), n.element && (t += "    element " + N(n.element) + "\n"), n.policy && (t += "    policy " + N(n.policy) + "\n"), t += "  }\n";
		e.policies.length > 0 && (t += "  policies { " + e.policies.map(N).join(" ") + " }\n"), e.defaultPolicy && (t += "  default_policy " + N(e.defaultPolicy) + "\n");
		for (let n of e.trustAnchors) t += "  trust_anchor " + N(n.id) + " {\n", n.trustRef && (t += Pc(n.trustRef, "    ", N)), n.role && (t += "    role " + N(n.role) + "\n"), n.description && (t += "    description \"" + s(n.description) + "\"\n"), t += "  }\n";
		e.compatibleWith.length > 0 && (t += "  compatible_with { " + e.compatibleWith.map(N).join(" ") + " }\n");
		let n = e.sourceRefs && e.sourceRefs.length > 0 ? e.sourceRefs : e.source ? [e.source] : [];
		for (let e of n) t += E(e, "  ", s);
		return t += w(e.refs, "  ", s), t += k(e.correspondences, "  ", s, N), t += "}\n", t;
	}
}, Ic = [
	"permission",
	"obligation",
	"prohibition"
], Lc = {
	keyword: "policy",
	field: "policies",
	takesID: !0,
	parse: function(e, t) {
		let n = {
			id: e,
			name: "",
			description: "",
			governs: [],
			defaultPosture: null,
			rules: [],
			source: null,
			sourceRefs: []
		};
		return v(t, (t, r, o) => {
			if (t === "name") n.name = x(r);
			else if (t === "description") n.description = x(r);
			else if (t === "governs") n.governs = F(r());
			else if (t === "default_posture") {
				let t = a(r());
				if (t !== "true" && t !== "false") throw Error(`Parsing error: policy. ID ${e}: default_posture is true | false, got "${t}"`);
				n.defaultPosture = t === "true";
			} else if (t === "rule") {
				let e = {
					id: a(r()),
					kind: "",
					action: "",
					artifact: "",
					constraints: []
				}, t = o();
				t && t.startsWith("{") && v(i(r()), (t, n) => {
					if (t === "kind") {
						let t = a(n());
						if (!Ic.includes(t)) throw Error(`Parsing error: policy.rule. ID ${e.id}: unknown rule kind "${t}" — rule kinds are ${Ic.join(" | ")} (fail-closed: a misspelt kind never parses into a rule that says nothing)`);
						e.kind = t;
					} else if (t === "action") e.action = a(n());
					else if (t === "artifact") e.artifact = a(n());
					else if (t === "constraint") e.constraints.push(x(n));
					else return !1;
					return !0;
				}, {
					construct: "policy.rule",
					id: e.id
				}), n.rules.push(e);
			} else if (t === "source") {
				let e = I(i(r()));
				n.sourceRefs.push(e), n.source ||= e;
			} else if (t === "ref") {
				let e = C(r, o, a, i);
				T(n, e) || (n.refs ??= []).push(e);
			} else if (t === "corresponds") (n.correspondences ??= []).push(O(r, o, a));
			else return !1;
			return !0;
		}, {
			construct: "policy",
			id: e
		}), (t) => (t.policies[e] = n, t);
	},
	dump: function(e) {
		let t = "policy " + e.id + " {\n";
		e.name && (t += "  name \"" + s(e.name) + "\"\n"), e.description && (t += "  description \"" + s(e.description) + "\"\n"), e.defaultPosture !== null && (t += "  default_posture " + (e.defaultPosture ? "true" : "false") + "\n"), e.governs.length > 0 && (t += "  governs { " + e.governs.map(N).join(" ") + " }\n");
		for (let n of e.rules) {
			t += "  rule " + N(n.id) + " {\n", n.kind && (t += "    kind " + n.kind + "\n"), n.action && (t += "    action " + N(n.action) + "\n"), n.artifact && (t += "    artifact " + N(n.artifact) + "\n");
			for (let e of n.constraints) t += "    constraint \"" + s(e) + "\"\n";
			t += "  }\n";
		}
		let n = e.sourceRefs && e.sourceRefs.length > 0 ? e.sourceRefs : e.source ? [e.source] : [];
		for (let e of n) t += E(e, "  ", s);
		return t += w(e.refs, "  ", s), t += k(e.correspondences, "  ", s, N), t += "}\n", t;
	}
}, Rc = {
	keyword: "dimension",
	field: "dimensions",
	takesID: !0,
	parse: function(e, t) {
		let n = io(e, i(t));
		return (t) => (t.dimensions[e] = n, t);
	},
	dump: function(e) {
		return oo(e, "");
	}
}, zc = (e, t) => {
	let n = {
		id: e,
		label: "",
		clause: "",
		definition: "",
		parent: ""
	};
	return v(t, (e, t) => {
		if (e === "label") n.label = a(t());
		else if (e === "clause") n.clause = a(t());
		else if (e === "definition") n.definition = a(t());
		else if (e === "parent") n.parent = a(t());
		else return !1;
		return !0;
	}, {
		construct: "activity_archetype",
		id: e
	}), (t) => (t.activityArchetypes[e] = n, t);
}, Bc = function(e) {
	let t = "activity_archetype " + e.id + " {\n";
	return e.label && (t += "  label \"" + s(e.label) + "\"\n"), e.clause && (t += "  clause \"" + s(e.clause) + "\"\n"), e.definition && (t += "  definition \"" + s(e.definition) + "\"\n"), e.parent && (t += "  parent " + N(e.parent) + "\n"), t += "}\n", t;
};
//#endregion
//#region src/ser-des/config/participantKind.ts
function Vc(e) {
	let t = {
		delegates_to: "",
		clause: "",
		note: ""
	};
	return v(e, (e, n) => {
		if (e === "delegates_to") t.delegates_to = a(n());
		else if (e === "clause") t.clause = a(n());
		else if (e === "note") t.note = a(n());
		else return !1;
		return !0;
	}, {
		construct: "participant_kind competence",
		id: ""
	}), t;
}
function Hc(e) {
	let t = {
		decided_by: "",
		on_recommendation_of: "",
		procedure: "",
		clause: ""
	};
	return v(e, (e, n) => {
		if (e === "decided_by") t.decided_by = a(n());
		else if (e === "on_recommendation_of") t.on_recommendation_of = a(n());
		else if (e === "procedure") t.procedure = a(n());
		else if (e === "clause") t.clause = a(n());
		else return !1;
		return !0;
	}, {
		construct: "participant_kind approval",
		id: ""
	}), t;
}
function Uc(e, t) {
	let n = {
		id: e,
		label: "",
		term: "",
		definition: "",
		data_flag: "",
		acceptance: "",
		acceptance_note: ""
	};
	return v(t, (e, t) => {
		if (e === "label") n.label = a(t());
		else if (e === "term") n.term = a(t());
		else if (e === "definition") n.definition = a(t());
		else if (e === "data_flag") n.data_flag = a(t());
		else if (e === "acceptance") n.acceptance = a(t());
		else if (e === "acceptance_note") n.acceptance_note = a(t());
		else return !1;
		return !0;
	}, {
		construct: "participant_kind subkind",
		id: e
	}), n;
}
var Wc = (e, t) => {
	let n = {
		id: e,
		label: "",
		term: "",
		clause: "",
		definition: "",
		member: "",
		competence: null,
		approval: null,
		approved_by: "",
		designated_by: "",
		declaration: "",
		admission: "",
		becomes: "",
		procedure: "",
		subkinds: [],
		source: {
			doc: "",
			clause: ""
		}
	};
	return v(t, (t, r, o) => {
		if (t === "label") n.label = a(r());
		else if (t === "term") n.term = a(r());
		else if (t === "clause") n.clause = a(r());
		else if (t === "definition") n.definition = a(r());
		else if (t === "member") n.member = a(r());
		else if (t === "competence") n.competence = Vc(i(r()));
		else if (t === "approval") n.approval = Hc(i(r()));
		else if (t === "approved_by") n.approved_by = a(r());
		else if (t === "designated_by") n.designated_by = a(r());
		else if (t === "declaration") n.declaration = a(r());
		else if (t === "admission") n.admission = a(r());
		else if (t === "becomes") n.becomes = a(r());
		else if (t === "procedure") n.procedure = a(r());
		else if (t === "subkind") {
			let t = a(r()), s = o();
			if (s === void 0 || !s.startsWith("{")) throw Error(`Parsing error: participant_kind. ID ${e}: subkind ${t} is missing its block`);
			n.subkinds.push(Uc(t, i(r())));
		} else if (t === "source") n.source = I(i(r()));
		else return !1;
		return !0;
	}, {
		construct: "participant_kind",
		id: e
	}), (t) => (t.participantKinds[e] = n, t);
};
function Gc(e) {
	let t = "  competence {\n";
	return e.delegates_to && (t += "    delegates_to " + N(e.delegates_to) + "\n"), e.clause && (t += "    clause \"" + s(e.clause) + "\"\n"), e.note && (t += "    note \"" + s(e.note) + "\"\n"), t += "  }\n", t;
}
function Kc(e) {
	let t = "  approval {\n";
	return e.decided_by && (t += "    decided_by " + N(e.decided_by) + "\n"), e.on_recommendation_of && (t += "    on_recommendation_of " + N(e.on_recommendation_of) + "\n"), e.procedure && (t += "    procedure \"" + s(e.procedure) + "\"\n"), e.clause && (t += "    clause \"" + s(e.clause) + "\"\n"), t += "  }\n", t;
}
function qc(e) {
	let t = "  subkind " + N(e.id) + " {\n";
	return e.label && (t += "    label \"" + s(e.label) + "\"\n"), e.term && (t += "    term \"" + s(e.term) + "\"\n"), e.definition && (t += "    definition \"" + s(e.definition) + "\"\n"), e.data_flag && (t += "    data_flag \"" + s(e.data_flag) + "\"\n"), e.acceptance && (t += "    acceptance " + N(e.acceptance) + "\n"), e.acceptance_note && (t += "    acceptance_note \"" + s(e.acceptance_note) + "\"\n"), t += "  }\n", t;
}
var Jc = function(e) {
	let t = "participant_kind " + e.id + " {\n";
	e.label && (t += "  label \"" + s(e.label) + "\"\n"), e.term && (t += "  term \"" + s(e.term) + "\"\n"), e.clause && (t += "  clause \"" + s(e.clause) + "\"\n"), e.definition && (t += "  definition \"" + s(e.definition) + "\"\n"), e.member && (t += "  member " + N(e.member) + "\n"), e.competence && (t += Gc(e.competence)), e.approval && (t += Kc(e.approval)), e.approved_by && (t += "  approved_by " + N(e.approved_by) + "\n"), e.designated_by && (t += "  designated_by " + N(e.designated_by) + "\n"), e.declaration && (t += "  declaration " + N(e.declaration) + "\n"), e.admission && (t += "  admission \"" + s(e.admission) + "\"\n"), e.becomes && (t += "  becomes " + N(e.becomes) + "\n"), e.procedure && (t += "  procedure \"" + s(e.procedure) + "\"\n");
	for (let n of e.subkinds) t += qc(n);
	return (e.source.doc || e.source.clause) && (t += "  source {\n", e.source.doc && (t += "    doc \"" + s(e.source.doc) + "\"\n"), e.source.clause && (t += "    clause \"" + s(e.source.clause) + "\"\n"), t += "  }\n"), t += "}\n", t;
}, Yc = (e, t) => {
	let n = {
		id: e,
		label: "",
		term: "",
		clause: "",
		mandate: "",
		sub_committee_of: "",
		independent_of: "",
		source: {
			doc: "",
			clause: ""
		}
	};
	return v(t, (e, t) => {
		if (e === "label") n.label = a(t());
		else if (e === "term") n.term = a(t());
		else if (e === "clause") n.clause = a(t());
		else if (e === "mandate") n.mandate = a(t());
		else if (e === "sub_committee_of") n.sub_committee_of = a(t());
		else if (e === "independent_of") n.independent_of = a(t());
		else if (e === "source") n.source = I(i(t()));
		else return !1;
		return !0;
	}, {
		construct: "governance_organ",
		id: e
	}), (t) => (t.governanceOrgans[e] = n, t);
}, Xc = function(e) {
	let t = "governance_organ " + e.id + " {\n";
	return e.label && (t += "  label \"" + s(e.label) + "\"\n"), e.term && (t += "  term \"" + s(e.term) + "\"\n"), e.clause && (t += "  clause \"" + s(e.clause) + "\"\n"), e.mandate && (t += "  mandate \"" + s(e.mandate) + "\"\n"), e.sub_committee_of && (t += "  sub_committee_of " + N(e.sub_committee_of) + "\n"), e.independent_of && (t += "  independent_of " + N(e.independent_of) + "\n"), (e.source.doc || e.source.clause) && (t += "  source {\n", e.source.doc && (t += "    doc \"" + s(e.source.doc) + "\"\n"), e.source.clause && (t += "    clause \"" + s(e.source.clause) + "\"\n"), t += "  }\n"), t += "}\n", t;
};
//#endregion
//#region src/ser-des/config/declaration.ts
function Zc(e, t) {
	let n = {
		id: e,
		clause: "",
		description: ""
	};
	return v(t, (e, t) => {
		if (e === "clause") n.clause = a(t());
		else if (e === "description") n.description = a(t());
		else return !1;
		return !0;
	}, {
		construct: "declaration_kind content",
		id: e
	}), n;
}
var Qc = (e, t) => {
	let n = {
		id: e,
		label: "",
		holder: "",
		clause: "",
		procedure: "",
		definition: "",
		scope_model: "",
		scheme_a_obligation: "",
		content: [],
		source: {
			doc: "",
			clause: ""
		}
	};
	return v(t, (t, r, o) => {
		if (t === "label") n.label = a(r());
		else if (t === "holder") n.holder = a(r());
		else if (t === "clause") n.clause = a(r());
		else if (t === "procedure") n.procedure = a(r());
		else if (t === "definition") n.definition = a(r());
		else if (t === "scope_model") n.scope_model = a(r());
		else if (t === "scheme_a_obligation") n.scheme_a_obligation = a(r());
		else if (t === "content") {
			let t = a(r()), s = o();
			if (s === void 0 || !s.startsWith("{")) throw Error(`Parsing error: declaration_kind. ID ${e}: content ${t} is missing its block`);
			n.content.push(Zc(t, i(r())));
		} else if (t === "source") n.source = I(i(r()));
		else return !1;
		return !0;
	}, {
		construct: "declaration_kind",
		id: e
	}), (t) => (t.declarationKinds[e] = n, t);
};
function $c(e) {
	let t = "  content " + N(e.id) + " {\n";
	return e.clause && (t += "    clause \"" + s(e.clause) + "\"\n"), e.description && (t += "    description \"" + s(e.description) + "\"\n"), t += "  }\n", t;
}
function el(e) {
	let t = "  source {\n";
	return e.doc && (t += "    doc \"" + s(e.doc) + "\"\n"), e.clause && (t += "    clause \"" + s(e.clause) + "\"\n"), t += "  }\n", t;
}
var tl = function(e) {
	let t = "declaration_kind " + e.id + " {\n";
	e.label && (t += "  label \"" + s(e.label) + "\"\n"), e.holder && (t += "  holder " + N(e.holder) + "\n"), e.clause && (t += "  clause \"" + s(e.clause) + "\"\n"), e.procedure && (t += "  procedure \"" + s(e.procedure) + "\"\n"), e.definition && (t += "  definition \"" + s(e.definition) + "\"\n"), e.scope_model && (t += "  scope_model " + N(e.scope_model) + "\n"), e.scheme_a_obligation && (t += "  scheme_a_obligation \"" + s(e.scheme_a_obligation) + "\"\n");
	for (let n of e.content) t += $c(n);
	return (e.source.doc || e.source.clause) && (t += el(e.source)), t += "}\n", t;
}, nl = (e, t) => {
	let n = {
		id: e,
		description: ""
	};
	return v(t, (e, t) => {
		if (e === "description") n.description = a(t());
		else return !1;
		return !0;
	}, {
		construct: "declaration_status",
		id: e
	}), (t) => (t.declarationStatuses[e] = n, t);
}, rl = function(e) {
	let t = "declaration_status " + e.id + " {\n";
	return e.description && (t += "  description \"" + s(e.description) + "\"\n"), t += "}\n", t;
}, il = (e, t) => {
	let n = {
		id: e,
		clause: "",
		statement: "",
		holder: "",
		declaration: "",
		blocks: [],
		blocks_note: "",
		scope_checked: [],
		source: {
			doc: "",
			clause: ""
		}
	};
	return v(t, (e, t) => {
		if (e === "clause") n.clause = a(t());
		else if (e === "statement") n.statement = a(t());
		else if (e === "holder") n.holder = a(t());
		else if (e === "declaration") n.declaration = a(t());
		else if (e === "blocks") n.blocks = r(i(t())).filter((e) => e.length > 0);
		else if (e === "blocks_note") n.blocks_note = a(t());
		else if (e === "scope_checked") n.scope_checked = r(i(t())).filter((e) => e.length > 0);
		else if (e === "source") n.source = I(i(t()));
		else return !1;
		return !0;
	}, {
		construct: "declaration_gate",
		id: e
	}), (t) => (t.declarationGates[e] = n, t);
}, al = function(e) {
	let t = "declaration_gate " + e.id + " {\n";
	return e.clause && (t += "  clause \"" + s(e.clause) + "\"\n"), e.statement && (t += "  statement \"" + s(e.statement) + "\"\n"), e.holder && (t += "  holder " + N(e.holder) + "\n"), e.declaration && (t += "  declaration " + N(e.declaration) + "\n"), e.blocks.length > 0 && (t += "  blocks { " + e.blocks.map(N).join(" ") + " }\n"), e.blocks_note && (t += "  blocks_note \"" + s(e.blocks_note) + "\"\n"), e.scope_checked.length > 0 && (t += "  scope_checked { " + e.scope_checked.map(N).join(" ") + " }\n"), (e.source.doc || e.source.clause) && (t += el(e.source)), t += "}\n", t;
};
//#endregion
//#region src/ser-des/config/scheme.ts
function ol(e) {
	let t = {
		method: "",
		clause: "",
		basis: [],
		note: ""
	};
	return v(e, (e, n) => {
		if (e === "method") t.method = a(n());
		else if (e === "clause") t.clause = a(n());
		else if (e === "basis") t.basis = r(i(n())).filter((e) => e.length > 0);
		else if (e === "note") t.note = a(n());
		else return !1;
		return !0;
	}, {
		construct: "scheme_definition demonstration",
		id: ""
	}), t;
}
var sl = (e, t) => {
	let n = {
		id: e,
		label: "",
		term: "",
		clause: "",
		definition: "",
		demonstration: null,
		source: {
			doc: "",
			clause: ""
		}
	};
	return v(t, (e, t) => {
		if (e === "label") n.label = a(t());
		else if (e === "term") n.term = a(t());
		else if (e === "clause") n.clause = a(t());
		else if (e === "definition") n.definition = a(t());
		else if (e === "demonstration") n.demonstration = ol(i(t()));
		else if (e === "source") n.source = I(i(t()));
		else return !1;
		return !0;
	}, {
		construct: "scheme_definition",
		id: e
	}), (t) => (t.schemeDefinitions[e] = n, t);
};
function cl(e) {
	let t = "  source {\n";
	return e.doc && (t += "    doc \"" + s(e.doc) + "\"\n"), e.clause && (t += "    clause \"" + s(e.clause) + "\"\n"), t += "  }\n", t;
}
var ll = function(e) {
	let t = "scheme_definition " + e.id + " {\n";
	if (e.label && (t += "  label \"" + s(e.label) + "\"\n"), e.term && (t += "  term \"" + s(e.term) + "\"\n"), e.clause && (t += "  clause \"" + s(e.clause) + "\"\n"), e.definition && (t += "  definition \"" + s(e.definition) + "\"\n"), e.demonstration) {
		let n = e.demonstration;
		t += "  demonstration {\n", n.method && (t += "    method " + N(n.method) + "\n"), n.clause && (t += "    clause \"" + s(n.clause) + "\"\n"), n.basis.length > 0 && (t += "    basis { " + n.basis.map(N).join(" ") + " }\n"), n.note && (t += "    note \"" + s(n.note) + "\"\n"), t += "  }\n";
	}
	return (e.source.doc || e.source.clause) && (t += cl(e.source)), t += "}\n", t;
};
function ul(e) {
	let t = {
		action: "",
		automatic: !1,
		clause: "",
		conditions_ref: "",
		description: ""
	};
	return v(e, (e, n) => {
		if (e === "action") t.action = a(n());
		else if (e === "automatic") t.automatic = n() === "true";
		else if (e === "clause") t.clause = a(n());
		else if (e === "conditions_ref") t.conditions_ref = a(n());
		else if (e === "description") t.description = a(n());
		else return !1;
		return !0;
	}, {
		construct: "scheme_lifecycle entry",
		id: ""
	}), t;
}
function dl(e) {
	let t = {
		clause: "",
		decided_by: "",
		on_proposal_of: "",
		description: ""
	};
	return v(e, (e, n) => {
		if (e === "clause") t.clause = a(n());
		else if (e === "decided_by") t.decided_by = a(n());
		else if (e === "on_proposal_of") t.on_proposal_of = a(n());
		else if (e === "description") t.description = a(n());
		else return !1;
		return !0;
	}, {
		construct: "scheme_lifecycle transition",
		id: ""
	}), t;
}
function fl(e, t) {
	let n = {
		id: e,
		kind: "",
		action: "",
		windowYears: 0,
		windowMonths: 0,
		clause: "",
		deferrable: !1,
		deferral_note: "",
		description: ""
	};
	return v(t, (e, t) => {
		if (e === "kind") n.kind = a(t());
		else if (e === "action") n.action = a(t());
		else if (e === "window") {
			let e = r(i(t()));
			for (let t = 0; t + 1 < e.length; t += 2) e[t] === "years" ? n.windowYears = parseInt(a(e[t + 1]), 10) || 0 : e[t] === "months" && (n.windowMonths = parseInt(a(e[t + 1]), 10) || 0);
		} else if (e === "clause") n.clause = a(t());
		else if (e === "deferrable") n.deferrable = t() === "true";
		else if (e === "deferral_note") n.deferral_note = a(t());
		else if (e === "description") n.description = a(t());
		else return !1;
		return !0;
	}, {
		construct: "scheme_lifecycle trigger",
		id: e
	}), n;
}
var pl = (e, t) => {
	let n = {
		id: e,
		applies_to: "",
		initial: "",
		entry: null,
		transitions: [],
		triggers: [],
		source: {
			doc: "",
			clause: ""
		}
	};
	return v(t, (t, r, o) => {
		if (t === "applies_to") n.applies_to = a(r());
		else if (t === "initial") n.initial = a(r());
		else if (t === "entry") n.entry = ul(i(r()));
		else if (t === "transition") {
			let t = a(r()), s = o();
			if (s === void 0 || s !== "->" && s !== "→") throw Error(`Parsing error: scheme_lifecycle. ID ${e}: transition ${t} is missing its '->'`);
			r();
			let c = a(r()), l = "";
			o() === "action" && (r(), l = a(r()));
			let u = o();
			if (u === void 0 || !u.startsWith("{")) throw Error(`Parsing error: scheme_lifecycle. ID ${e}: transition ${t} -> ${c} is missing its block`);
			let d = dl(i(r()));
			n.transitions.push({
				from: t,
				to: c,
				action: l,
				...d
			});
		} else if (t === "trigger") {
			let t = a(r()), s = o();
			if (s === void 0 || !s.startsWith("{")) throw Error(`Parsing error: scheme_lifecycle. ID ${e}: trigger ${t} is missing its block`);
			n.triggers.push(fl(t, i(r())));
		} else if (t === "source") n.source = I(i(r()));
		else return !1;
		return !0;
	}, {
		construct: "scheme_lifecycle",
		id: e
	}), (t) => (t.schemeLifecycles[e] = n, t);
}, ml = function(e) {
	let t = "scheme_lifecycle " + e.id + " {\n";
	if (e.applies_to && (t += "  applies_to " + N(e.applies_to) + "\n"), e.initial && (t += "  initial " + N(e.initial) + "\n"), e.entry) {
		let n = e.entry;
		t += "  entry {\n", n.action && (t += "    action " + N(n.action) + "\n"), t += "    automatic " + (n.automatic ? "true" : "false") + "\n", n.clause && (t += "    clause \"" + s(n.clause) + "\"\n"), n.conditions_ref && (t += "    conditions_ref " + N(n.conditions_ref) + "\n"), n.description && (t += "    description \"" + s(n.description) + "\"\n"), t += "  }\n";
	}
	for (let n of e.transitions) t += "  transition " + N(n.from) + " -> " + N(n.to), n.action && (t += " action " + N(n.action)), t += " {\n", n.clause && (t += "    clause \"" + s(n.clause) + "\"\n"), n.decided_by && (t += "    decided_by " + N(n.decided_by) + "\n"), n.on_proposal_of && (t += "    on_proposal_of " + N(n.on_proposal_of) + "\n"), n.description && (t += "    description \"" + s(n.description) + "\"\n"), t += "  }\n";
	for (let n of e.triggers) {
		if (t += "  trigger " + N(n.id) + " {\n", n.kind && (t += "    kind " + N(n.kind) + "\n"), n.action && (t += "    action " + N(n.action) + "\n"), n.windowYears > 0 || n.windowMonths > 0) {
			let e = "    window {";
			n.windowYears > 0 && (e += " years " + n.windowYears), n.windowMonths > 0 && (e += " months " + n.windowMonths), t += e + " }\n";
		}
		n.clause && (t += "    clause \"" + s(n.clause) + "\"\n"), n.deferrable && (t += "    deferrable true\n"), n.deferral_note && (t += "    deferral_note \"" + s(n.deferral_note) + "\"\n"), n.description && (t += "    description \"" + s(n.description) + "\"\n"), t += "  }\n";
	}
	return (e.source.doc || e.source.clause) && (t += cl(e.source)), t += "}\n", t;
};
//#endregion
//#region src/ser-des/config/frameworkDocument.ts
function hl(e) {
	let t = "  source {\n";
	return e.doc && (t += "    doc \"" + s(e.doc) + "\"\n"), e.clause && (t += "    clause \"" + s(e.clause) + "\"\n"), t += "  }\n", t;
}
var gl = (e, t) => {
	let n = {
		id: e,
		rank: 0,
		doc: "",
		title: "",
		approved_by: "",
		clause: "",
		note: "",
		source: {
			doc: "",
			clause: ""
		}
	};
	return v(t, (e, t) => {
		if (e === "rank") n.rank = parseInt(a(t()), 10) || 0;
		else if (e === "doc") n.doc = a(t());
		else if (e === "title") n.title = a(t());
		else if (e === "approved_by") n.approved_by = a(t());
		else if (e === "clause") n.clause = a(t());
		else if (e === "note") n.note = a(t());
		else if (e === "source") n.source = I(i(t()));
		else return !1;
		return !0;
	}, {
		construct: "framework_document",
		id: e
	}), (t) => (t.frameworkDocuments[e] = n, t);
}, _l = function(e) {
	let t = "framework_document " + e.id + " {\n";
	return e.rank > 0 && (t += "  rank " + e.rank + "\n"), e.doc && (t += "  doc \"" + s(e.doc) + "\"\n"), e.title && (t += "  title \"" + s(e.title) + "\"\n"), e.approved_by && (t += "  approved_by " + N(e.approved_by) + "\n"), e.clause && (t += "  clause \"" + s(e.clause) + "\"\n"), e.note && (t += "  note \"" + s(e.note) + "\"\n"), (e.source.doc || e.source.clause) && (t += hl(e.source)), t += "}\n", t;
}, vl = (e, t) => {
	let n = {
		id: e,
		clause: "",
		statement: "",
		source: {
			doc: "",
			clause: ""
		}
	};
	return v(t, (e, t) => {
		if (e === "clause") n.clause = a(t());
		else if (e === "statement") n.statement = a(t());
		else if (e === "source") n.source = I(i(t()));
		else return !1;
		return !0;
	}, {
		construct: "document_precedence",
		id: e
	}), (t) => (t.documentPrecedences[e] = n, t);
}, yl = function(e) {
	let t = "document_precedence " + e.id + " {\n";
	return e.clause && (t += "  clause \"" + s(e.clause) + "\"\n"), e.statement && (t += "  statement \"" + s(e.statement) + "\"\n"), (e.source.doc || e.source.clause) && (t += hl(e.source)), t += "}\n", t;
};
function bl(e, t) {
	let n = {
		id: e,
		clause: "",
		description: ""
	};
	return v(t, (e, t) => {
		if (e === "clause") n.clause = a(t());
		else if (e === "description") n.description = a(t());
		else return !1;
		return !0;
	}, {
		construct: "auto_inclusion condition",
		id: e
	}), n;
}
var xl = (e, t) => {
	let n = {
		id: e,
		clause: "",
		statement: "",
		conditions: [],
		note: "",
		source: {
			doc: "",
			clause: ""
		}
	};
	return v(t, (t, r, o) => {
		if (t === "clause") n.clause = a(r());
		else if (t === "statement") n.statement = a(r());
		else if (t === "condition") {
			let t = a(r()), s = o();
			if (s === void 0 || !s.startsWith("{")) throw Error(`Parsing error: auto_inclusion. ID ${e}: condition ${t} is missing its block`);
			n.conditions.push(bl(t, i(r())));
		} else if (t === "note") n.note = a(r());
		else if (t === "source") n.source = I(i(r()));
		else return !1;
		return !0;
	}, {
		construct: "auto_inclusion",
		id: e
	}), (t) => (t.autoInclusions[e] = n, t);
}, Sl = function(e) {
	let t = "auto_inclusion " + e.id + " {\n";
	e.clause && (t += "  clause \"" + s(e.clause) + "\"\n"), e.statement && (t += "  statement \"" + s(e.statement) + "\"\n");
	for (let n of e.conditions) t += "  condition " + N(n.id) + " {\n", n.clause && (t += "    clause \"" + s(n.clause) + "\"\n"), n.description && (t += "    description \"" + s(n.description) + "\"\n"), t += "  }\n";
	return e.note && (t += "  note \"" + s(e.note) + "\"\n"), (e.source.doc || e.source.clause) && (t += hl(e.source)), t += "}\n", t;
};
//#endregion
//#region src/ser-des/config/decisionRule.ts
function Cl(e) {
	let t = {
		threshold: 0,
		base: "",
		clause: "",
		description: ""
	};
	return v(e, (e, n) => {
		if (e === "threshold") t.threshold = parseFloat(a(n())) || 0;
		else if (e === "base") t.base = a(n());
		else if (e === "clause") t.clause = a(n());
		else if (e === "description") t.description = a(n());
		else return !1;
		return !0;
	}, {
		construct: "decision_rule voting rule",
		id: ""
	}), t;
}
function wl(e) {
	let t = {
		in_meeting: 0,
		by_correspondence: "",
		description: ""
	};
	return v(e, (e, n) => {
		if (e === "in_meeting") t.in_meeting = parseFloat(a(n())) || 0;
		else if (e === "by_correspondence") t.by_correspondence = a(n());
		else if (e === "description") t.description = a(n());
		else return !1;
		return !0;
	}, {
		construct: "decision_rule other_proposals",
		id: ""
	}), t;
}
function Tl(e) {
	let t = {
		in_meeting: null,
		by_correspondence: null,
		other_proposals: null,
		proxies_max: 0,
		abstentions: "",
		reason_on_against_or_abstain: !1
	};
	return v(e, (e, n) => {
		if (e === "in_meeting") t.in_meeting = Cl(i(n()));
		else if (e === "by_correspondence") t.by_correspondence = Cl(i(n()));
		else if (e === "other_proposals") t.other_proposals = wl(i(n()));
		else if (e === "proxies_max") t.proxies_max = parseInt(a(n()), 10) || 0;
		else if (e === "abstentions") t.abstentions = a(n());
		else if (e === "reason_on_against_or_abstain") t.reason_on_against_or_abstain = n() === "true";
		else return !1;
		return !0;
	}, {
		construct: "decision_rule voting",
		id: ""
	}), t;
}
function El(e, t) {
	let n = {
		id: e,
		clause: "",
		description: ""
	};
	return v(t, (e, t) => {
		if (e === "clause") n.clause = a(t());
		else if (e === "description") n.description = a(t());
		else return !1;
		return !0;
	}, {
		construct: "decision_rule legacy_kind",
		id: e
	}), n;
}
function Dl(e) {
	return r(i(e)).filter((e) => e.length > 0);
}
var Ol = (e, t) => {
	let n = {
		id: e,
		organ: "",
		kind: "",
		clause: "",
		description: "",
		on_recommendation_of: "",
		independent_of: "",
		decides: [],
		voting: null,
		tasks: [],
		scope: [],
		principle: "",
		legacy_kinds: [],
		income: "",
		no_entrance_fees_for: [],
		source: {
			doc: "",
			clause: ""
		}
	};
	return v(t, (t, r, o) => {
		if (t === "organ") n.organ = a(r());
		else if (t === "kind") n.kind = a(r());
		else if (t === "clause") n.clause = a(r());
		else if (t === "description") n.description = a(r());
		else if (t === "on_recommendation_of") n.on_recommendation_of = a(r());
		else if (t === "independent_of") n.independent_of = a(r());
		else if (t === "decides") n.decides = Dl(r());
		else if (t === "voting") n.voting = Tl(i(r()));
		else if (t === "tasks") n.tasks = Dl(r());
		else if (t === "scope") n.scope = Dl(r());
		else if (t === "principle") n.principle = a(r());
		else if (t === "legacy_kind") {
			let t = a(r()), s = o();
			if (s === void 0 || !s.startsWith("{")) throw Error(`Parsing error: decision_rule. ID ${e}: legacy_kind ${t} is missing its block`);
			n.legacy_kinds.push(El(t, i(r())));
		} else if (t === "income") n.income = a(r());
		else if (t === "no_entrance_fees_for") n.no_entrance_fees_for = Dl(r());
		else if (t === "source") n.source = I(i(r()));
		else return !1;
		return !0;
	}, {
		construct: "decision_rule",
		id: e
	}), (t) => (t.decisionRules[e] = n, t);
};
function kl(e, t) {
	let n = "    " + e + " {\n";
	return t.threshold > 0 && (n += "      threshold " + t.threshold + "\n"), t.base && (n += "      base " + N(t.base) + "\n"), t.clause && (n += "      clause \"" + s(t.clause) + "\"\n"), t.description && (n += "      description \"" + s(t.description) + "\"\n"), n += "    }\n", n;
}
function Al(e) {
	let t = "  voting {\n";
	if (e.in_meeting && (t += kl("in_meeting", e.in_meeting)), e.by_correspondence && (t += kl("by_correspondence", e.by_correspondence)), e.other_proposals) {
		let n = e.other_proposals;
		t += "    other_proposals {\n", n.in_meeting > 0 && (t += "      in_meeting " + n.in_meeting + "\n"), n.by_correspondence && (t += "      by_correspondence " + N(n.by_correspondence) + "\n"), n.description && (t += "      description \"" + s(n.description) + "\"\n"), t += "    }\n";
	}
	return e.proxies_max > 0 && (t += "    proxies_max " + e.proxies_max + "\n"), e.abstentions && (t += "    abstentions " + N(e.abstentions) + "\n"), e.reason_on_against_or_abstain && (t += "    reason_on_against_or_abstain true\n"), t += "  }\n", t;
}
function jl(e, t, n) {
	return n + e + " { " + t.map(N).join(" ") + " }\n";
}
var Ml = function(e) {
	let t = "decision_rule " + e.id + " {\n";
	e.organ && (t += "  organ " + N(e.organ) + "\n"), e.kind && (t += "  kind " + N(e.kind) + "\n"), e.clause && (t += "  clause \"" + s(e.clause) + "\"\n"), e.description && (t += "  description \"" + s(e.description) + "\"\n"), e.on_recommendation_of && (t += "  on_recommendation_of " + N(e.on_recommendation_of) + "\n"), e.independent_of && (t += "  independent_of " + N(e.independent_of) + "\n"), e.decides.length > 0 && (t += jl("decides", e.decides, "  ")), e.voting && (t += Al(e.voting)), e.tasks.length > 0 && (t += jl("tasks", e.tasks, "  ")), e.scope.length > 0 && (t += jl("scope", e.scope, "  ")), e.principle && (t += "  principle " + N(e.principle) + "\n");
	for (let n of e.legacy_kinds) t += "  legacy_kind " + N(n.id) + " {\n", n.clause && (t += "    clause \"" + s(n.clause) + "\"\n"), n.description && (t += "    description \"" + s(n.description) + "\"\n"), t += "  }\n";
	return e.income && (t += "  income " + N(e.income) + "\n"), e.no_entrance_fees_for.length > 0 && (t += jl("no_entrance_fees_for", e.no_entrance_fees_for, "  ")), (e.source.doc || e.source.clause) && (t += "  source {\n", e.source.doc && (t += "    doc \"" + s(e.source.doc) + "\"\n"), e.source.clause && (t += "    clause \"" + s(e.source.clause) + "\"\n"), t += "  }\n"), t += "}\n", t;
}, Nl = (e, t) => {
	let n = {
		id: e,
		document: "",
		title: "",
		edition: "",
		year: 0,
		namespace: "",
		sequence: [],
		registers: [],
		source: {
			doc: "",
			clause: ""
		}
	};
	return v(t, (t, r, o) => {
		if (t === "document") n.document = a(r());
		else if (t === "title") n.title = a(r());
		else if (t === "edition") n.edition = a(r());
		else if (t === "year") n.year = parseInt(a(r()), 10) || 0;
		else if (t === "namespace") n.namespace = a(r());
		else if (t === "sequence") n.sequence = Ct(i(r()));
		else if (t === "register") {
			let t = a(r()), s = o();
			if (s === void 0 || !s.startsWith("{")) throw Error(`Parsing error: document_module. ID ${e}: register ${t} is missing its block`);
			n.registers.push(wt(t, i(r())));
		} else if (t === "source") n.source = I(i(r()));
		else return !1;
		return !0;
	}, {
		construct: "document_module",
		id: e
	}), (t) => (t.documentModules[e] = n, t);
}, Pl = function(e) {
	let t = "document_module " + e.id + " {\n";
	e.document && (t += "  document \"" + s(e.document) + "\"\n"), e.title && (t += "  title \"" + s(e.title) + "\"\n"), e.edition && (t += "  edition \"" + s(e.edition) + "\"\n"), e.year && (t += "  year " + e.year + "\n"), e.namespace && (t += "  namespace " + N(e.namespace) + "\n");
	let n = Et(e.sequence);
	n && (t += "  " + n + "\n");
	for (let n of e.registers) t += Dt(n, "  ");
	return (e.source.doc || e.source.clause) && (t += "  source {\n", e.source.doc && (t += "    doc \"" + s(e.source.doc) + "\"\n"), e.source.clause && (t += "    clause \"" + s(e.source.clause) + "\"\n"), t += "  }\n"), t += "}\n", t;
}, Fl = ["informative"];
function Il(e, t) {
	let n = {
		id: "",
		title: "",
		edition: 0,
		year: 0,
		role: "",
		source: ""
	};
	return v(e, (e, r) => {
		if (e === "id") n.id = a(r());
		else if (e === "title") n.title = a(r());
		else if (e === "edition") n.edition = parseInt(a(r()), 10) || 0;
		else if (e === "year") n.year = parseInt(a(r()), 10) || 0;
		else if (e === "role") {
			let e = a(r());
			if (!Fl.includes(e)) throw Error(`Parsing error: informative_annex. ID ${t}: Unknown document role "${e}" (valid: ${Fl.join(", ")})`);
			n.role = e;
		} else if (e === "source") n.source = a(r());
		else return !1;
		return !0;
	}, {
		construct: "informative_annex document",
		id: t
	}), n;
}
function Ll(e, t) {
	let n = {
		id: e,
		clause: "",
		title: "",
		statement: "",
		dischargedBy: ""
	};
	return v(t, (e, t) => {
		if (e === "clause") n.clause = a(t());
		else if (e === "title") n.title = a(t());
		else if (e === "statement") n.statement = a(t());
		else if (e === "discharged_by") n.dischargedBy = a(t());
		else return !1;
		return !0;
	}, {
		construct: "informative_annex highlight",
		id: e
	}), n;
}
var Rl = (e, t) => {
	let n = {
		id: e,
		document: {
			id: "",
			title: "",
			edition: 0,
			year: 0,
			role: "",
			source: ""
		},
		appliesTo: "",
		appliedBy: "",
		scope: "",
		numberingCaution: "",
		highlights: []
	};
	return v(t, (t, r, o) => {
		if (t === "document") n.document = Il(i(r()), e);
		else if (t === "applies_to") n.appliesTo = a(r());
		else if (t === "applied_by") n.appliedBy = a(r());
		else if (t === "scope") n.scope = a(r());
		else if (t === "numbering_caution") n.numberingCaution = a(r());
		else if (t === "highlight") {
			let t = a(r()), s = o();
			if (s === void 0 || !s.startsWith("{")) throw Error(`Parsing error: informative_annex. ID ${e}: highlight ${t} is missing its block`);
			n.highlights.push(Ll(t, i(r())));
		} else return !1;
		return !0;
	}, {
		construct: "informative_annex",
		id: e
	}), (t) => (t.informativeAnnexes[e] = n, t);
}, zl = function(e) {
	let t = "informative_annex " + e.id + " {\n";
	t += "  document {\n", e.document.id && (t += "    id \"" + s(e.document.id) + "\"\n"), e.document.title && (t += "    title \"" + s(e.document.title) + "\"\n"), e.document.edition && (t += "    edition " + e.document.edition + "\n"), e.document.year && (t += "    year " + e.document.year + "\n"), e.document.role && (t += "    role " + N(e.document.role) + "\n"), e.document.source && (t += "    source \"" + s(e.document.source) + "\"\n"), t += "  }\n", e.appliesTo && (t += "  applies_to " + N(e.appliesTo) + "\n"), e.appliedBy && (t += "  applied_by \"" + s(e.appliedBy) + "\"\n"), e.scope && (t += "  scope \"" + s(e.scope) + "\"\n"), e.numberingCaution && (t += "  numbering_caution \"" + s(e.numberingCaution) + "\"\n");
	for (let n of e.highlights) t += "  highlight " + N(n.id) + " {\n", n.clause && (t += "    clause \"" + s(n.clause) + "\"\n"), n.title && (t += "    title \"" + s(n.title) + "\"\n"), n.statement && (t += "    statement \"" + s(n.statement) + "\"\n"), n.dischargedBy && (t += "    discharged_by \"" + s(n.dischargedBy) + "\"\n"), t += "  }\n";
	return t += "}\n", t;
}, Bl = ["normative", "informative"], Vl = (e, t) => {
	let n = {
		id: e,
		letter: "",
		title: "",
		obligation: "",
		summary: "",
		realization: "",
		source: {
			doc: "",
			clause: ""
		}
	};
	return v(t, (t, r) => {
		if (t === "letter") n.letter = a(r());
		else if (t === "title") n.title = a(r());
		else if (t === "obligation") {
			let t = a(r());
			if (!Bl.includes(t)) throw Error(`Parsing error: part_annex. ID ${e}: Unknown obligation "${t}" (valid: ${Bl.join(", ")})`);
			n.obligation = t;
		} else if (t === "summary") n.summary = a(r());
		else if (t === "realization") n.realization = a(r());
		else if (t === "source") n.source = I(i(r()));
		else return !1;
		return !0;
	}, {
		construct: "part_annex",
		id: e
	}), (t) => (t.partAnnexes[e] = n, t);
}, Hl = function(e) {
	let t = "part_annex " + e.id + " {\n";
	return e.letter && (t += "  letter \"" + s(e.letter) + "\"\n"), e.title && (t += "  title \"" + s(e.title) + "\"\n"), e.obligation && (t += "  obligation " + N(e.obligation) + "\n"), e.summary && (t += "  summary \"" + s(e.summary) + "\"\n"), e.realization && (t += "  realization \"" + s(e.realization) + "\"\n"), (e.source.doc || e.source.clause) && (t += "  source {\n", e.source.doc && (t += "    doc \"" + s(e.source.doc) + "\"\n"), e.source.clause && (t += "    clause \"" + s(e.source.clause) + "\"\n"), t += "  }\n"), t += "}\n", t;
};
//#endregion
//#region src/ser-des/config/storyline.ts
function Ul(e) {
	return e.startsWith("{") ? n(i(e)).filter((e) => e.length > 0).map(z) : z(e);
}
function Wl(e) {
	let t = {}, r = n(e), i = 0;
	for (; i < r.length;) {
		let e = r[i++];
		if (i >= r.length) break;
		t[P(e)] = Ul(r[i++]);
	}
	return t;
}
function Gl(e, t) {
	let n = "";
	for (let [r, i] of Object.entries(e)) n += Array.isArray(i) ? t + r + " { " + i.map(B).join(" ") + " }\n" : t + r + " " + B(i) + "\n";
	return n;
}
function Kl(e) {
	let t = [], r = n(e), o = 0;
	for (; o < r.length;) {
		let e = a(r[o++]);
		if (o >= r.length || !r[o].startsWith("{")) break;
		let s = {
			id: e,
			entries: []
		}, c = n(i(r[o++])), l = 0;
		for (; l < c.length;) {
			let e = a(c[l++]);
			if (l >= c.length || !c[l].startsWith("{")) break;
			s.entries.push({
				id: e,
				fields: Wl(i(c[l++]))
			});
		}
		t.push(s);
	}
	return t;
}
var ql = (e, t) => {
	let n = {
		id: e,
		standard: "",
		description: "",
		participants: []
	};
	return v(t, (e, t) => {
		if (e === "standard") n.standard = a(t());
		else if (e === "description") n.description = a(t());
		else if (e === "participants") n.participants = Kl(i(t()));
		else return !1;
		return !0;
	}, {
		construct: "demo_world",
		id: e
	}), (t) => (t.demoWorlds[e] = n, t);
}, Jl = function(e) {
	let t = "demo_world " + e.id + " {\n";
	if (e.standard && (t += "  standard " + N(e.standard) + "\n"), e.description && (t += "  description \"" + s(e.description) + "\"\n"), e.participants.length > 0) {
		t += "  participants {\n";
		for (let n of e.participants) {
			t += "    " + N(n.id) + " {\n";
			for (let e of n.entries) t += "      " + N(e.id) + " {\n", t += Gl(e.fields, "        "), t += "      }\n";
			t += "    }\n";
		}
		t += "  }\n";
	}
	return t += "}\n", t;
};
function Yl(e) {
	let t = [], r = n(e), o = 0;
	for (; o < r.length;) {
		let e = a(r[o++]);
		if (o >= r.length) break;
		let n = {
			kind: e,
			id: a(r[o++]),
			fields: {}
		};
		o < r.length && r[o].startsWith("{") && (n.fields = Wl(i(r[o++]))), t.push(n);
	}
	return t;
}
var Xl = (e, t) => {
	let r = {
		id: e,
		name: "",
		idPrefix: "",
		party: {
			laboratory: "",
			authority: ""
		},
		subject: [],
		records: [],
		notes: []
	};
	return v(t, (t, o, s) => {
		if (t === "name") r.name = a(o());
		else if (t === "id_prefix") r.idPrefix = a(o());
		else if (t === "party") {
			let e = n(i(o()));
			for (let t = 0; t + 1 < e.length; t += 2) e[t] === "laboratory" ? r.party.laboratory = a(e[t + 1]) : e[t] === "authority" && (r.party.authority = a(e[t + 1]));
		} else if (t === "subject") r.subject = Yl(i(o()));
		else if (t === "record") {
			let t = a(o()), n = s();
			if (n === void 0 || n.startsWith("{")) throw Error(`Parsing error: storyline. ID ${e}: record ${t} is missing its id and block`);
			let c = a(o()), l = s();
			if (l === void 0 || !l.startsWith("{")) throw Error(`Parsing error: storyline. ID ${e}: record ${t} ${c} is missing its block`);
			r.records.push({
				store: t,
				id: c,
				fields: Wl(i(o()))
			});
		} else if (t === "note") r.notes.push(a(o()));
		else return !1;
		return !0;
	}, {
		construct: "storyline",
		id: e
	}), (t) => (t.storylines[e] = r, t);
}, Zl = function(e) {
	let t = "storyline " + e.id + " {\n";
	if (e.name && (t += "  name \"" + s(e.name) + "\"\n"), e.idPrefix && (t += "  id_prefix " + N(e.idPrefix) + "\n"), (e.party.laboratory || e.party.authority) && (t += "  party {", e.party.laboratory && (t += " laboratory " + N(e.party.laboratory)), e.party.authority && (t += " authority " + N(e.party.authority)), t += " }\n"), e.subject.length > 0) {
		t += "  subject {\n";
		for (let n of e.subject) t += "    " + N(n.kind) + " " + N(n.id) + " {\n", t += Gl(n.fields, "      "), t += "    }\n";
		t += "  }\n";
	}
	for (let n of e.records) t += "  record " + N(n.store) + " " + N(n.id) + " {\n", t += Gl(n.fields, "    "), t += "  }\n";
	for (let n of e.notes) t += "  note \"" + s(n) + "\"\n";
	return t += "}\n", t;
};
//#endregion
//#region src/ser-des/config/index.ts
function J(e) {
	return e;
}
var Ql = [
	J({
		keyword: "role",
		field: "roles",
		takesID: !0,
		parse: yn,
		dump: bn
	}),
	J({
		keyword: "provision",
		field: "provisions",
		takesID: !0,
		parse: mn,
		resolve: hn,
		dump: gn
	}),
	J({
		keyword: "process",
		field: "processes",
		takesID: !0,
		parse: Re,
		resolve: ze,
		dump: Ke
	}),
	J({
		keyword: "process_model",
		field: "processModels",
		takesID: !0,
		parse: Tt,
		dump: Ot
	}),
	J({
		keyword: "workflow_config",
		field: "workflowConfigs",
		takesID: !0,
		parse: Mt,
		dump: Nt
	}),
	J({
		keyword: "workflow_stage",
		field: "workflowStages",
		takesID: !0,
		parse: It,
		dump: Lt
	}),
	J({
		keyword: "approval",
		field: "approvals",
		takesID: !0,
		parse: Je,
		resolve: Ye,
		dump: Xe
	}),
	J({
		keyword: "class",
		field: "dataclasses",
		takesID: !0,
		parse: et,
		resolve: nt,
		dump: it
	}),
	J({
		keyword: "enum",
		field: "enums",
		takesID: !0,
		parse: Ze,
		dump: st
	}),
	J({
		keyword: "data_registry",
		field: "regs",
		takesID: !0,
		parse: $e,
		resolve: rt,
		dump: ct
	}),
	J({
		keyword: "variable",
		field: "variables",
		takesID: !0,
		parse: lt,
		dump: ut
	}),
	J({
		keyword: "measurement",
		field: "variables",
		takesID: !0,
		parse: lt,
		dump: ut
	}),
	J({
		keyword: "exclusive_gateway",
		field: "gateways",
		takesID: !0,
		parse: bt,
		dump: xt
	}),
	J({
		keyword: "start",
		aliases: ["start_event"],
		field: "events",
		takesID: !0,
		parse: pt,
		dump: ht
	}),
	J({
		keyword: "end",
		aliases: ["end_event"],
		field: "events",
		takesID: !0,
		parse: dt,
		dump: ht
	}),
	J({
		keyword: "signalcatch",
		aliases: ["signal_catch_event"],
		field: "events",
		takesID: !0,
		parse: ft,
		dump: ht
	}),
	J({
		keyword: "timer",
		aliases: ["timer_event"],
		field: "events",
		takesID: !0,
		parse: mt,
		dump: ht
	}),
	J({
		keyword: "reference",
		field: "references",
		takesID: !0,
		parse: _n,
		dump: vn
	}),
	J({
		keyword: "canvas",
		aliases: ["subprocess"],
		field: "pages",
		takesID: !0,
		parse: xn,
		resolve: Dn,
		dump: kn
	}),
	J({
		keyword: "note",
		field: "notes",
		takesID: !0,
		parse: Nn,
		resolve: Pn,
		dump: Fn
	}),
	J({
		keyword: "table",
		field: "tables",
		takesID: !0,
		parse: Un,
		dump: qn
	}),
	J({
		keyword: "figure",
		field: "figures",
		takesID: !0,
		parse: Jn,
		dump: Yn
	}),
	J({
		keyword: "link",
		field: "links",
		takesID: !0,
		parse: Zn,
		dump: Qn
	}),
	J({
		keyword: "comment",
		field: "comments",
		takesID: !0,
		parse: $n,
		resolve: er,
		dump: tr
	}),
	J({
		keyword: "map_profile",
		field: "mapProfiles",
		takesID: !0,
		parse: sr,
		dump: cr
	}),
	J({
		keyword: "view_profile",
		aliases: ["view"],
		field: "viewProfiles",
		takesID: !0,
		parse: ur,
		dump: dr
	}),
	J({
		keyword: "term",
		field: "terms",
		takesID: !0,
		parse: Vi,
		dump: Hi
	}),
	J({
		keyword: "form",
		field: "forms",
		takesID: !0,
		parse: fr,
		dump: yr
	}),
	J({
		keyword: "certificate_template",
		field: "certificateTemplates",
		takesID: !0,
		parse: Rs,
		dump: zs
	}),
	J({
		keyword: "subform",
		field: "subforms",
		takesID: !0,
		parse: xr,
		dump: Cr
	}),
	J({
		keyword: "test_report_skeleton",
		field: "testReportSkeletons",
		takesID: !0,
		parse: un,
		dump: dn
	}),
	J({
		keyword: "test_report_checklist",
		field: "testReportChecklists",
		takesID: !0,
		parse: fn,
		dump: pn
	}),
	J({
		keyword: "symbol",
		field: "symbols",
		takesID: !0,
		parse: Tr,
		resolve: Er,
		dump: Dr
	}),
	J({
		keyword: "formula_note",
		field: "formulaNotes",
		takesID: !0,
		parse: kr,
		dump: Ar
	}),
	J({
		keyword: "calculation",
		field: "calculations",
		takesID: !0,
		parse: jr,
		resolve: zr,
		dump: Br
	}),
	J({
		keyword: "calculation_context",
		field: "calculationContexts",
		takesID: !0,
		parse: Os,
		dump: ks
	}),
	J({
		keyword: "evaluation_dimensions",
		field: "evaluationDimensions",
		takesID: !0,
		parse: Ms,
		dump: Ns
	}),
	J({
		keyword: "evaluation_profile",
		field: "evaluationProfiles",
		takesID: !0,
		parse: Ps,
		dump: Fs
	}),
	J({
		keyword: "verdict",
		field: "verdicts",
		takesID: !0,
		parse: Gi,
		dump: Ki
	}),
	J({
		keyword: "reference_material",
		field: "referenceMaterials",
		takesID: !0,
		parse: Yi,
		dump: Xi
	}),
	J({
		keyword: "test_point_set",
		field: "testPointSets",
		takesID: !0,
		parse: ga,
		dump: _a
	}),
	J({
		keyword: "common_test_condition",
		field: "commonTestConditions",
		takesID: !0,
		parse: va,
		dump: ya
	}),
	J({
		keyword: "competence_kind",
		field: "competenceKinds",
		takesID: !0,
		parse: vi,
		dump: yi
	}),
	J({
		keyword: "scheme_activity_kind",
		field: "schemeActivityKinds",
		takesID: !0,
		parse: ea,
		dump: ia
	}),
	J({
		keyword: "scheme_type",
		field: "schemeTypes",
		takesID: !0,
		parse: na,
		dump: aa
	}),
	J({
		keyword: "predicate",
		field: "predicates",
		takesID: !0,
		parse: oa,
		dump: sa
	}),
	J({
		keyword: "constraint",
		field: "constraints",
		takesID: !0,
		parse: la,
		dump: ua
	}),
	J({
		keyword: "discrepancy_record",
		field: "discrepancyRecords",
		takesID: !0,
		parse: fa,
		dump: pa
	}),
	J({
		keyword: "state_machine",
		field: "stateMachines",
		takesID: !0,
		parse: Hr,
		dump: Gr
	}),
	ka,
	Aa,
	ts,
	ns,
	rs,
	is,
	as,
	Ia,
	J({
		keyword: "conformance_test",
		field: "conformanceTests",
		takesID: !0,
		parse: Ii,
		dump: Li
	}),
	J({
		keyword: "verification_pathway",
		field: "verificationPathways",
		takesID: !0,
		parse: Gt,
		dump: Kt
	}),
	J({
		keyword: "lab_selection_criterion",
		field: "labSelectionCriteria",
		takesID: !0,
		parse: Qt,
		dump: $t
	}),
	J({
		keyword: "sample_selection_rule",
		field: "sampleSelectionRules",
		takesID: !0,
		parse: en,
		dump: tn
	}),
	J({
		keyword: "specimen_governance_rule",
		field: "specimenGovernanceRules",
		takesID: !0,
		parse: nn,
		dump: rn
	}),
	os,
	J({
		keyword: "identity_slot",
		field: "identitySlots",
		takesID: !0,
		parse: vs,
		dump: ys
	}),
	J({
		keyword: "aspect",
		field: "aspects",
		takesID: !0,
		parse: xs,
		dump: Ss
	}),
	J({
		keyword: "promise_set",
		field: "promiseSets",
		takesID: !0,
		parse: Cs,
		dump: ws
	}),
	J({
		keyword: "application_declaration",
		field: "applicationDeclarations",
		takesID: !0,
		parse: Es,
		dump: Ds
	}),
	hs,
	Zs,
	Qs,
	jc,
	Mc,
	J({
		keyword: "activity_archetype",
		field: "activityArchetypes",
		takesID: !0,
		parse: zc,
		dump: Bc
	}),
	J({
		keyword: "participant_kind",
		field: "participantKinds",
		takesID: !0,
		parse: Wc,
		dump: Jc
	}),
	J({
		keyword: "governance_organ",
		field: "governanceOrgans",
		takesID: !0,
		parse: Yc,
		dump: Xc
	}),
	J({
		keyword: "declaration_kind",
		field: "declarationKinds",
		takesID: !0,
		parse: Qc,
		dump: tl
	}),
	J({
		keyword: "declaration_status",
		field: "declarationStatuses",
		takesID: !0,
		parse: nl,
		dump: rl
	}),
	J({
		keyword: "declaration_gate",
		field: "declarationGates",
		takesID: !0,
		parse: il,
		dump: al
	}),
	J({
		keyword: "scheme_definition",
		field: "schemeDefinitions",
		takesID: !0,
		parse: sl,
		dump: ll
	}),
	J({
		keyword: "scheme_lifecycle",
		field: "schemeLifecycles",
		takesID: !0,
		parse: pl,
		dump: ml
	}),
	J({
		keyword: "framework_document",
		field: "frameworkDocuments",
		takesID: !0,
		parse: gl,
		dump: _l
	}),
	J({
		keyword: "document_precedence",
		field: "documentPrecedences",
		takesID: !0,
		parse: vl,
		dump: yl
	}),
	J({
		keyword: "auto_inclusion",
		field: "autoInclusions",
		takesID: !0,
		parse: xl,
		dump: Sl
	}),
	J({
		keyword: "decision_rule",
		field: "decisionRules",
		takesID: !0,
		parse: Ol,
		dump: Ml
	}),
	J({
		keyword: "document_module",
		field: "documentModules",
		takesID: !0,
		parse: Nl,
		dump: Pl
	}),
	J({
		keyword: "informative_annex",
		field: "informativeAnnexes",
		takesID: !0,
		parse: Rl,
		dump: zl
	}),
	J({
		keyword: "part_annex",
		field: "partAnnexes",
		takesID: !0,
		parse: Vl,
		dump: Hl
	}),
	J({
		keyword: "demo_world",
		field: "demoWorlds",
		takesID: !0,
		parse: ql,
		dump: Jl
	}),
	J({
		keyword: "storyline",
		field: "storylines",
		takesID: !0,
		parse: Xl,
		dump: Zl
	}),
	Ja,
	uc,
	_c,
	vc,
	bc,
	xc,
	J({
		keyword: "text",
		field: "texts",
		takesID: !0,
		parse: Sc,
		dump: Cc
	}),
	Fc,
	Lc,
	Rc
];
function $l(e) {
	let t = {};
	for (let n of e) {
		if (!n.field) continue;
		let e = {
			takesID: n.takesID,
			parse: n.parse,
			field: n.field
		};
		t[n.keyword] = e;
		for (let r of n.aliases ?? []) t[r] = e;
	}
	return t;
}
function eu(e) {
	let t = {};
	for (let n of e) n.field && (t[n.field] = { resolve: n.resolve ?? ((e, t) => t) });
	return t;
}
function tu(e) {
	let t = {};
	for (let n of e) n.field && (t[n.field] = n.dump);
	return t;
}
var nu = {
	package: { parse: Pa },
	root: { parse: (e) => (t) => (t.root = e.trim(), t) },
	metadata: { parse: m },
	version: { parse: () => (e) => e },
	...$l(Ql)
}, ru = eu(Ql), iu = tu(Ql), Y = (/* @__PURE__ */ e(((e, t) => {
	t.exports = {};
})))(), au = /^include\s+"([^"]+)"/gm, ou = /^[ \t]*(#|\/\/)/;
function su(e, t = /* @__PURE__ */ new Set()) {
	let n = (0, Y.resolve)(e);
	if (t.has(n)) throw Error(`Include cycle detected: ${n} (chain: ${[...t, n].map((e) => e.split("/").pop()).join(" → ")})`);
	if (t.add(n), !(0, Y.existsSync)(n)) throw Error(`Include file not found: ${n}`);
	let r = (0, Y.readFileSync)(n, "utf8"), i = (0, Y.dirname)(n);
	return r.replace(au, (e, n, a) => {
		let o = r.lastIndexOf("\n", a) + 1, s = r.slice(o, a);
		if (ou.test(s)) return e;
		let c = (0, Y.isAbsolute)(n) ? n : (0, Y.resolve)(i, n);
		return su(c.endsWith(".prl") || c.endsWith(".mmel") ? c : (0, Y.existsSync)(`${c}.prl`) ? `${c}.prl` : `${c}.mmel`, new Set(t));
	});
}
//#endregion
//#region src/validate.ts
function cu(e) {
	let t = [];
	for (let n of lu) t.push(...n.check(e));
	return t;
}
var lu = [
	{
		name: "empty-ids",
		check: uu
	},
	{
		name: "form-references",
		check: du
	},
	{
		name: "state-machine-cascades",
		check: fu
	}
];
function uu(e) {
	let t = [];
	for (let [n, r] of pu(e)) for (let e of r) (!e.id || e.id.trim() === "") && t.push({
		severity: "error",
		code: "empty-id",
		construct: n,
		message: `${n} has an empty id — every ${n} must declare a non-empty id`
	});
	return t;
}
function du(e) {
	let t = [], n = new Set(e.calculations.map((e) => e.id)), r = new Set(e.processes.map((e) => e.id));
	for (let t of e.conformanceTests ?? []) r.add(t.id);
	let i = new Set(e.subforms.map((e) => e.id));
	for (let a of e.forms) {
		a.conformanceProcessId && !r.has(a.conformanceProcessId) && t.push({
			severity: "error",
			code: "form-conformance-process-missing",
			construct: "form",
			message: `Form "${a.id}" references conformance process "${a.conformanceProcessId}" which does not exist`,
			id: a.id
		});
		for (let e of mu(a)) {
			let r = e.calculationId;
			r && !r.startsWith("ocl{") && !n.has(r) && t.push({
				severity: "error",
				code: "form-calculation-missing",
				construct: "form",
				message: `Form "${a.id}" field "${e.name}" references calculation "${e.calculationId}" which does not exist`,
				id: a.id
			}), e.subformRef && !i.has(e.subformRef.subformId) && t.push({
				severity: "error",
				code: "form-subform-missing",
				construct: "form",
				message: `Form "${a.id}" field "${e.name}" references subform "${e.subformRef.subformId}" which does not exist`,
				id: a.id
			});
		}
	}
	return t;
}
function fu(e) {
	let t = [];
	for (let n of e.stateMachines) {
		let e = new Set(n.states.map((e) => e.name));
		e.add("*");
		for (let r of n.transitions) r.from && !e.has(r.from) && t.push({
			severity: "warning",
			code: "state-machine-from-missing",
			construct: "state_machine",
			message: `State machine "${n.entityName}" transition from "${r.from}" is not in declared states`,
			id: n.entityName
		}), r.to && !e.has(r.to) && t.push({
			severity: "warning",
			code: "state-machine-to-missing",
			construct: "state_machine",
			message: `State machine "${n.entityName}" transition to "${r.to}" is not in declared states`,
			id: n.entityName
		});
	}
	return t;
}
function* pu(e) {
	for (let [t, n] of Object.entries(e)) Array.isArray(n) && n.length > 0 && typeof n[0]?.id == "string" && (yield [t, n]);
}
function* mu(e) {
	let t = [...e.fields];
	for (; t.length > 0;) {
		let e = t.pop();
		yield e, e.fields && e.fields.length > 0 && t.push(...e.fields);
	}
}
//#endregion
//#region src/ser-des/package.ts
var hu = [
	"model",
	"entities",
	"specification",
	"execution",
	"evaluation",
	"framework"
];
function gu(e) {
	let t = [];
	if (!(0, Y.existsSync)(e)) return t;
	for (let n of (0, Y.readdirSync)(e).sort()) {
		let r = (0, Y.join)(e, n);
		(0, Y.statSync)(r).isDirectory() ? t.push(...gu(r)) : (n.endsWith(".prl") || n.endsWith(".mmel")) && t.push(r);
	}
	return t;
}
function _u(e) {
	let t = (0, Y.resolve)(e), n = [], r = (0, Y.join)(t, "package.primmel");
	(0, Y.existsSync)(r) && n.push({
		path: r,
		role: "manifest"
	});
	let i = [];
	for (let e of hu) i.push(...gu((0, Y.join)(t, e)));
	for (let e of (0, Y.readdirSync)(t).sort()) {
		let n = (0, Y.join)(t, e);
		(0, Y.statSync)(n).isFile() && (e.endsWith(".prl") || e.endsWith(".mmel")) && e !== "package.primmel" && e !== ".primmel-allowlist.prl" && i.push(n);
	}
	i.sort();
	for (let e of i) n.push({
		path: e,
		role: "content"
	});
	return n;
}
function vu(e, t = {}) {
	return Eu(e, t).standard;
}
function yu(e, t) {
	let n = /* @__PURE__ */ new Map(), r = [];
	for (let i of t) {
		let t = e.constructs[i.field]?.[i.id];
		if (!t) {
			r.push(i);
			continue;
		}
		let a = n.get(t.file);
		a ? a.push(i) : n.set(t.file, [i]);
	}
	return {
		byFile: n,
		unassigned: r
	};
}
function bu(e, t = {}) {
	let n = Eu(e, t, !0);
	if (!n.provenance) throw Error("loadPackageWithProvenance: provenance not collected");
	return {
		...n,
		provenance: n.provenance
	};
}
function xu(e) {
	let t = 0;
	for (let n = 0; n < e.length; n++) e.charAt(n) === "\n" && t++;
	return t;
}
function Su(e) {
	let t = [], n = 0, r = 1;
	for (let i of e) {
		if (i.role !== "content") continue;
		let e = su(i.path);
		t.push({
			path: i.path,
			text: e,
			start: n,
			lineStart: r
		}), n += e.length + 2, r += xu(e) + 2;
	}
	return t;
}
function Cu(e) {
	return e.map((e) => e.text).join("\n\n");
}
function wu(e, t, n) {
	let r = {}, i = 0;
	for (let a of e) {
		for (; i + 1 < t.length && a.start.offset >= t[i + 1].start;) i++;
		let e = t[i], o = (t) => ({
			line: t.line - e.lineStart + 1,
			col: t.col,
			offset: t.offset - e.start
		}), s = {
			file: e.path,
			...n === void 0 ? {} : { package: n },
			span: {
				start: o(a.start),
				end: o(a.end)
			}
		};
		(r[a.field] ??= {})[a.id] = s;
	}
	return r;
}
function Tu(e) {
	let t = (0, Y.join)((0, Y.resolve)(e), "package.primmel");
	if (!(0, Y.existsSync)(t)) throw Error(`loadPackage: no package.primmel found in ${(0, Y.resolve)(e)}`);
	let n = (0, Y.readFileSync)(t, "utf8"), r = { packageManifest: null };
	Pa(n)(r);
	let i = r.packageManifest;
	if (!i || !i.id) throw Error(`loadPackage: ${t} is not a valid package manifest`);
	return i;
}
function Eu(e, t = {}, n = !1) {
	let r = _u(e);
	if (r.length === 0) throw Error(`loadPackage: no package files found in ${(0, Y.resolve)(e)}`);
	let i = null;
	r.some((e) => e.role === "manifest") && (i = Tu(e));
	let a = Su(r);
	if (i && t.resolvePackage && Ou(i).length > 0) return Fu(e, t, i, n);
	let o = n ? {
		...t,
		withProvenance: !0
	} : t, s = u(Cu(a), nu, o);
	if (i) {
		s.packageManifest = i;
		let e = ku(i);
		e && s.issues.push(e);
	}
	let c = {
		standard: p(s, ru),
		issues: s.issues
	};
	if (n) {
		let e = r.find((e) => e.role === "manifest")?.path;
		c.provenance = {
			...e === void 0 ? {} : { manifest: e },
			constructs: wu(s.constructs ?? [], a, i?.id)
		};
	}
	return c;
}
function Du(e, t = {}) {
	return Eu(e, t);
}
var X = class extends Error {
	rule;
	constructor(e, t) {
		super(t), this.rule = e, this.name = "CompositionError";
	}
};
function Ou(e) {
	let t = [];
	for (let n of [...e.uses ?? [], ...e.extends ? [e.extends] : []]) t.includes(n) || t.push(n);
	return t;
}
function ku(e) {
	return e.extends ? {
		severity: "warning",
		code: "extends-deprecated",
		construct: "package",
		id: e.id,
		message: `package "${e.id}": 'extends ${e.extends}' is deprecated — declare 'uses { ${e.extends} }' instead (extends is treated as a single-entry uses)`
	} : null;
}
var Au = /* @__PURE__ */ "approvals.roles.processes.processModels.pages.gateways.regs.references.provisions.dataclasses.events.enums.variables.notes.tables.figures.links.mapProfiles.viewProfiles.terms.forms.subforms.symbols.formulaNotes.calculations.verdicts.referenceMaterials.testPointSets.commonTestConditions.competenceKinds.schemeActivityKinds.schemeTypes.constraints.discrepancyRecords.stateMachines.conformanceTests.conformanceClasses.requirements.requirementClasses.instruments.attributeDefinitions.capabilities.behaviors.conditionSets.subjects.identitySlots.aspects.promiseSets.applicationDeclarations.calculationContexts.evaluationDimensions.evaluationProfiles.certificateTemplates.workflowConfigs.workflowStages.verificationPathways.labSelectionCriteria.sampleSelectionRules.specimenGovernanceRules.testReportSkeletons.testReportChecklists.instances.quantityRegisters.duals.invariants.testSequences.formulasUsed.texts.participantKinds.governanceOrgans.declarationKinds.declarationStatuses.declarationGates.schemeDefinitions.schemeLifecycles.frameworkDocuments.documentPrecedences.autoInclusions.decisionRules.documentModules.informativeAnnexes.partAnnexes.demoWorlds.storylines.comments.predicates.artifactDefinitions.artifactInstances.activityArchetypes.connectorProfiles.monitors.passports.dataspaces.policies.dimensions".split("."), ju = /* @__PURE__ */ new Set(["workflowConfigs", "testReportChecklists"]);
function Mu(e) {
	return typeof e == "object" && !!e && !Array.isArray(e);
}
function Nu(e, t) {
	if (Array.isArray(e) && Array.isArray(t)) {
		let n = (e) => Mu(e) && typeof e.id == "string", r = [...e, ...t];
		if (r.length > 0 && r.every(n)) {
			let e = [], t = /* @__PURE__ */ new Map();
			for (let n of r) t.has(n.id) ? t.set(n.id, Nu(t.get(n.id), n)) : (e.push(n.id), t.set(n.id, n));
			return e.map((e) => t.get(e));
		}
		let i = [...e];
		for (let e of t) i.includes(e) || i.push(e);
		return i;
	}
	if (Mu(e) && Mu(t)) {
		let n = { ...e };
		for (let [e, r] of Object.entries(t)) e !== "overlay" && r != null && (n[e] = e in n ? Nu(n[e], r) : r);
		return n;
	}
	return t;
}
function Pu(e, t) {
	let n = Su(_u(e));
	return {
		ctx: u(Cu(n), nu, t),
		chunks: n
	};
}
function Fu(e, t, n, r = !1) {
	let i = t.resolvePackage, a = n.id, o = /* @__PURE__ */ new Map([[a, (0, Y.resolve)(e)]]), s = /* @__PURE__ */ new Map([[a, n]]), c = [], l = /* @__PURE__ */ new Map(), u = [], d = (e) => {
		l.set(e, 1), u.push(e);
		for (let t of Ou(s.get(e))) {
			let n = l.get(t) ?? 0;
			if (n === 1) throw new X("uses-cycle", `uses cycle: ${[...u.slice(u.indexOf(t)), t].join(" → ")} — package composition must be acyclic (uses-cycle)`);
			if (n !== 2) {
				if (!o.has(t)) {
					let n = i(t);
					if (!n) throw new X("uses-resolves", `package "${e}" uses "${t}", which the package locator cannot resolve (uses-resolves)`);
					let r = Tu(n);
					if (r.id !== t) throw new X("uses-resolves", `package "${e}" uses "${t}", but the located package (${(0, Y.resolve)(n)}) declares id "${r.id}" (uses-resolves)`);
					if (o.set(t, n), s.set(t, r), r.kind === "product_reference") {
						l.set(t, 2);
						continue;
					}
				}
				d(t);
			}
		}
		u.pop(), l.set(e, 2), c.push(e);
	};
	d(a);
	let f = r ? {
		...t,
		withProvenance: !0
	} : t, m = /* @__PURE__ */ new Map(), h = /* @__PURE__ */ new Map();
	for (let e of c) {
		let t = Pu(o.get(e), f);
		m.set(e, t.ctx), h.set(e, t.chunks);
	}
	let g = /* @__PURE__ */ new Map();
	for (let e of Au) g.set(e, /* @__PURE__ */ new Map());
	let _ = m.get(c[0]);
	for (let e of Au) for (let t of Object.keys(_[e])) g.get(e).set(t, c[0]);
	let v = /* @__PURE__ */ new Map(), y = (e, t) => {
		for (let n of Object.values(t.documentModules)) n.namespace !== "" && !v.has(n.namespace) && v.set(n.namespace, e);
		for (let n of Object.keys(t.requirementClasses)) v.has(n) || v.set(n, e);
	}, b = (e, t) => {
		if (v.size !== 0) for (let n of ["requirementClasses", "requirements"]) {
			let r = n === "requirementClasses" ? "requirement class" : "requirement";
			for (let i of Object.keys(t[n])) for (let [t, n] of v) if (i.startsWith(t + "/")) throw new X("namespace-pin-violation", `package "${e}" declares ${r} "${i}" under the requirement namespace "${t}" owned by package "${n}" — a layer-owned namespace is single-sourced: a downstream package may reference its provisions, never declare scopes or requirements at or under it (namespace-pin-violation)`);
		}
	};
	y(c[0], _);
	for (let e of c.slice(1)) {
		let t = m.get(e);
		b(e, t);
		for (let n of Au) {
			let r = _[n], i = g.get(n);
			for (let [a, o] of Object.entries(t[n])) {
				let t = i.get(a);
				if (t !== void 0) {
					if (!(typeof o == "object" && o && o.overlay === !0 && (n === "terms" || ju.has(n)))) throw new X("uses-no-redefine", `package "${e}" redefines ${String(n)} id "${a}" already declared by package "${t}" — an overlay may reference upstream ids, never redefine them (uses-no-redefine)`);
					if (ju.has(n)) {
						if (n === "testReportChecklists") {
							let t = new Set((r[a].entries ?? []).map((e) => e.id));
							for (let n of o.entries ?? []) t.has(n.id) || _.issues.push({
								severity: "error",
								code: "orphan-overlay-entry",
								construct: "test_report_checklist",
								id: a,
								message: `package "${e}" overlay test_report_checklist "${a}" declares entry "${n.id}", which no upstream package's checklist carries — an overlay adds rec-bound strings to an upstream entry, never a fresh entry (orphan-overlay-entry)`
							});
						}
						r[a] = Nu(r[a], o), i.set(a, e);
						continue;
					}
				}
				r[a] = o, i.set(a, e);
			}
		}
		_.issues.push(...t.issues), !_.metadata && t.metadata && (_.metadata = t.metadata), y(e, t);
	}
	for (let e of c) {
		let t = s.get(e);
		for (let n of t.requires ?? []) if (!c.some((t) => t !== e && (t === n || (s.get(t).provides ?? []).includes(n)))) throw new X("requires-satisfied", `package "${e}" requires "${n}", which no package in the composition provides (requires-satisfied)`);
	}
	let x = [];
	c.forEach((e, t) => {
		let n = s.get(e), r = c.slice(t + 1);
		for (let t of n.provides ?? []) {
			let n = r.some((e) => (s.get(e).requires ?? []).includes(t)), i = r.some((n) => (s.get(n).waives ?? []).some((n) => n === t || n === `${e}:${t}`));
			!n && !i && x.push({
				severity: "warning",
				code: "provides-unconsumed",
				construct: "package",
				id: `${e}:${t}`,
				message: `package "${e}" provides "${t}", which no downstream package requires or waives (provides-consumed-or-waived)`
			});
		}
	});
	for (let e of s.values()) {
		let t = ku(e);
		t && x.push(t);
	}
	_.packageManifest = n;
	let S = {
		standard: p(_, ru),
		issues: [..._.issues, ...x],
		composition: {
			root: a,
			order: c
		}
	};
	if (r) {
		let t = {};
		for (let e of c) {
			let n = wu(m.get(e).constructs ?? [], h.get(e), e);
			for (let [e, r] of Object.entries(n)) {
				let n = t[e] ??= {};
				for (let [e, t] of Object.entries(r)) n[e] = t;
			}
		}
		S.provenance = {
			manifest: (0, Y.join)((0, Y.resolve)(e), "package.primmel"),
			constructs: t
		};
	}
	return S;
}
//#endregion
//#region src/ser-des/prm.ts
var Iu = /* @__PURE__ */ new Set(["MMEL_MAP", "Primmel_MAP"]), Lu = /* @__PURE__ */ new Set([
	"full",
	"minimal",
	"partial",
	"none"
]);
function Z(e) {
	throw Error(`.prm parse error: ${e}`);
}
function Ru(e, t) {
	let n = {
		description: "",
		justification: "",
		coverage: ""
	};
	if (e == null) return n;
	(typeof e != "object" || Array.isArray(e)) && Z(`${t}: pair metadata must be an object`);
	let r = e;
	return r.description !== void 0 && (typeof r.description != "string" && Z(`${t}: "description" must be a string`), n.description = r.description), r.justification !== void 0 && (typeof r.justification != "string" && Z(`${t}: "justification" must be a string`), n.justification = r.justification), r.coverage !== void 0 && ((typeof r.coverage != "string" || !Lu.has(r.coverage)) && Z(`${t}: "coverage" must be one of full | minimal | partial | none`), n.coverage = r.coverage), n;
}
function zu(e) {
	let t;
	try {
		t = JSON.parse(e);
	} catch (e) {
		Z(`invalid JSON — ${e.message}`);
	}
	(typeof t != "object" || !t || Array.isArray(t)) && Z("top level must be an object");
	let n = t, r = typeof n["@type"] == "string" ? n["@type"] : "";
	Iu.has(r) || Z(`"@type" must be MMEL_MAP or Primmel_MAP (got "${r}")`);
	let i = {
		context: typeof n["@context"] == "string" ? n["@context"] : "",
		type: r,
		id: typeof n.id == "string" ? n.id : "",
		mapSet: {}
	}, a = n.mapSet ?? {};
	(typeof a != "object" || !a || Array.isArray(a)) && Z("\"mapSet\" must be an object keyed by target namespace");
	for (let [e, t] of Object.entries(a)) {
		(typeof t != "object" || !t || Array.isArray(t)) && Z(`mapSet."${e}": entry must be an object`);
		let n = t, r = {
			id: typeof n.id == "string" ? n.id : e,
			mappings: {},
			coverage: {}
		}, a = n.coverage ?? {};
		(typeof a != "object" || !a || Array.isArray(a)) && Z(`mapSet."${e}".coverage: must be an object`);
		for (let [t, n] of Object.entries(a)) (typeof n != "string" || !Lu.has(n)) && Z(`mapSet."${e}".coverage."${t}": must be one of full | minimal | partial | none`), r.coverage[t] = n;
		let o = n.mappings ?? {};
		(typeof o != "object" || !o || Array.isArray(o)) && Z(`mapSet."${e}".mappings: must be an object`);
		for (let [t, n] of Object.entries(o)) {
			(typeof n != "object" || !n || Array.isArray(n)) && Z(`mapSet."${e}".mappings."${t}": must be an object`);
			let i = {};
			for (let [r, a] of Object.entries(n)) i[r] = Ru(a, `mapSet."${e}".mappings."${t}"."${r}"`);
			r.mappings[t] = i;
		}
		i.mapSet[e] = r;
	}
	return i;
}
function Bu(e) {
	let t = {};
	e.context && (t["@context"] = e.context), t["@type"] = e.type || "Primmel_MAP", t.id = e.id;
	let n = {};
	for (let [t, r] of Object.entries(e.mapSet)) {
		let e = {};
		for (let [t, n] of Object.entries(r.mappings)) {
			let r = {};
			for (let [e, t] of Object.entries(n)) {
				let n = {
					description: t.description,
					justification: t.justification
				};
				t.coverage && (n.coverage = t.coverage), r[e] = n;
			}
			e[t] = r;
		}
		let i = {
			id: r.id,
			mappings: e
		};
		Object.keys(r.coverage ?? {}).length > 0 && (i.coverage = r.coverage), n[t] = i;
	}
	return t.mapSet = n, JSON.stringify(t, null, 2) + "\n";
}
function Vu(e) {
	let t = [];
	for (let [n, r] of Object.entries(e.mapSet)) {
		let e = {};
		for (let [t, n] of Object.entries(r.mappings)) e[t] = Object.entries(n).map(([e, t]) => ({
			target: e,
			description: t.description,
			justification: t.justification,
			coverage: t.coverage
		}));
		t.push({
			namespace: n,
			description: "",
			mappings: e,
			coverage: { ...r.coverage ?? {} }
		});
	}
	return t;
}
function Hu(e, t) {
	let n = {
		context: "",
		type: "Primmel_MAP",
		id: e,
		mapSet: {}
	};
	for (let e of t) {
		let t = {
			id: e.namespace,
			mappings: {},
			coverage: { ...e.coverage ?? {} }
		};
		for (let [n, r] of Object.entries(e.mappings)) {
			let e = {};
			for (let t of r) e[t.target] = {
				description: t.description,
				justification: t.justification,
				coverage: t.coverage
			};
			t.mappings[n] = e;
		}
		n.mapSet[e.namespace] = t;
	}
	return n;
}
//#endregion
//#region src/type-expr.ts
var Uu = [
	"integer",
	"float",
	"double",
	"string",
	"text",
	"boolean",
	"date",
	"datetime",
	"duration",
	"period",
	"enum",
	"reference",
	"object",
	"any"
], Wu = /^[A-Za-z_][A-Za-z0-9_-]*$/;
function Gu(e) {
	let t = 0;
	for (let n = 0; n < e.length; n++) {
		let r = e[n];
		if (r === "<") t++;
		else if (r === ">") t--;
		else if (r === "," && t === 0) return [e.slice(0, n), e.slice(n + 1)];
	}
	return null;
}
function Ku(e) {
	let t = e.trim();
	if (t === "QuantityValue") return { kind: "quantity" };
	if (Uu.includes(t)) return {
		kind: "primitive",
		name: t
	};
	let n = /^reference\(([^)]+)\)$/.exec(t);
	if (n) {
		let e = n[1].trim();
		return Wu.test(e) ? {
			kind: "reference",
			target: e
		} : null;
	}
	if (t.startsWith("map<") && t.endsWith(">")) {
		let e = Gu(t.slice(4, -1));
		if (!e) return null;
		let n = e[0].trim(), r = null;
		n === "string" ? r = {
			kind: "primitive",
			name: "string"
		} : Wu.test(n) && (r = {
			kind: "reference",
			target: n
		});
		let i = Ku(e[1]);
		return !r || !i ? null : {
			kind: "map",
			key: r,
			value: i
		};
	}
	return null;
}
function qu(e) {
	let t = Ku(e);
	return t !== null && t.kind === "map";
}
//#endregion
//#region src/mapping-coverage.ts
function Ju(e, t) {
	let n = e.indexOf("#");
	if (n >= 0) {
		let t = e.slice(0, n), r = e.slice(n + 1);
		return {
			namespace: t,
			id: r,
			qualified: t + "#" + r
		};
	}
	return {
		namespace: t,
		id: e,
		qualified: t + "#" + e
	};
}
function Yu(e, t) {
	let n = [];
	for (let [r, i] of Object.entries(e.mappings)) for (let a of i) n.push({
		source: r,
		sourceModel: t,
		target: Ju(a.target, e.namespace).qualified,
		targetModel: e.namespace,
		description: a.description,
		justification: a.justification,
		assertedCoverage: a.coverage
	});
	return n;
}
function Xu(e, t = {}) {
	let n = t.modelId ?? e.packageManifest?.id ?? e.meta?.namespace ?? "", r = [...e.mapProfiles ?? []], i = t.prm ? Array.isArray(t.prm) ? t.prm : [t.prm] : [];
	for (let e of i) r.push(...Vu(e));
	return r.flatMap((e) => Yu(e, n));
}
function Zu(e, t = {}) {
	let n = t.idPrefix ?? "", r = (e.processes ?? []).filter((e) => !n || e.id.startsWith(n)), i = new Set(r.map((e) => e.id)), a = /* @__PURE__ */ new Map();
	for (let e of r) a.set(e.id, {
		id: e.id.slice(n.length),
		composition: e.childComposition === "gateway" ? "gateway" : "all",
		children: []
	});
	let o = [];
	for (let e of r) {
		let t = a.get(e.id);
		e.parent && i.has(e.parent) ? a.get(e.parent).children.push(t) : o.push(t);
	}
	return o;
}
function Qu(e, t) {
	return t.length === 0 ? "none" : t.every((e) => e === "full") ? "full" : e === "gateway" && t.some((e) => e === "full" || e === "minimal") ? "minimal" : t.some((e) => e !== "none") ? "partial" : "none";
}
function $u(e, t, n, r, i = {}) {
	let a = Array.isArray(t) ? t : Zu(t), o = n.filter((e) => e.targetModel === r), s = /* @__PURE__ */ new Map();
	for (let e of o) {
		let t = Ju(e.target, r).id;
		(s.get(t) ?? s.set(t, []).get(t)).push(e.source);
	}
	let c = /* @__PURE__ */ new Map(), l = /* @__PURE__ */ new Map(), u = (e, t) => {
		let n = s.has(e.id), r = n ? e.id : t, i = e.children.map((e) => u(e, r)), a;
		return r === null ? a = e.children.length === 0 ? "none" : Qu(e.composition, i) : (a = "full", !n && t !== null && l.set(e.id, t)), c.set(e.id, a), a;
	};
	for (let e of a) u(e, null);
	let d = [], f = /* @__PURE__ */ new Map(), p = (e) => {
		f.set(e.id, e), d.push({
			id: e.id,
			coverage: c.get(e.id) ?? "none",
			directlyMapped: s.has(e.id),
			mappedBy: s.get(e.id) ?? [],
			inheritedFrom: l.get(e.id) ?? null
		}), e.children.forEach(p);
	};
	a.forEach(p);
	let m = {
		full: 0,
		minimal: 0,
		partial: 0,
		none: 0
	};
	for (let e of d) m[e.coverage]++;
	let h = [], g = /* @__PURE__ */ new Set();
	for (let e of o) {
		let t = Ju(e.target, r).id;
		f.has(t) ? g.add(e.source) : h.push({
			source: e.source,
			target: e.target
		});
	}
	let _ = (e.processes ?? []).map((e) => e.id).filter((e) => !g.has(e)).filter((e) => i.unmappedAliases !== "exclude" || !e.includes("#")), v = [], y = /* @__PURE__ */ new Set(), b = (e) => {
		let t = `${e.kind}|${e.sourceModel}|${e.source}|${e.target}`;
		y.has(t) || (y.add(t), v.push(e));
	};
	for (let e of o) {
		let t = Ju(e.target, r).id, n = f.get(t);
		if (!n) continue;
		let i = (e, t) => {
			for (let n of e.children) t.push(n), i(n, t);
		}, a = [];
		i(n, a);
		for (let t of a) (s.get(t.id) ?? []).includes(e.source) || b({
			kind: "inherited",
			sourceModel: e.sourceModel,
			source: e.source,
			targetModel: r,
			target: `${r}#${t.id}`,
			via: [e.target],
			rationale: `${e.source} ⇒ ${e.target} covers ${r}#${t.id} by inheritance — propose the pair explicitly for confirmation`,
			asserted: !1
		});
	}
	for (let e of d) {
		let t = f.get(e.id);
		if (e.directlyMapped || e.coverage !== "full" || t.children.length === 0) continue;
		let n = /* @__PURE__ */ new Set(), a = (e) => {
			for (let t of s.get(e.id) ?? []) n.add(t);
			e.children.forEach(a);
		};
		t.children.forEach(a);
		for (let a of n) b({
			kind: "closure",
			sourceModel: o.find((e) => e.source === a)?.sourceModel ?? i.implementationId ?? "",
			source: a,
			targetModel: r,
			target: `${r}#${e.id}`,
			via: t.children.map((e) => `${r}#${e.id}`),
			rationale: `all children of ${r}#${e.id} are covered — closure candidate: confirm and assert a direct mapping`,
			asserted: !1
		});
	}
	return {
		implementation: i.implementationId ?? e.packageManifest?.id ?? e.meta?.namespace ?? "",
		reference: i.referenceId ?? (Array.isArray(t) ? r : t.packageManifest?.id ?? t.meta?.namespace ?? ""),
		targetNamespace: r,
		components: d,
		unmappedImplementation: _,
		unresolvedMappings: h,
		proposals: v,
		summary: m
	};
}
function ed(e) {
	let t = [], n = /* @__PURE__ */ new Set();
	for (let r of e) for (let i of r.mappings) for (let r of e) if (r.modelId === i.targetModel) for (let e of r.mappings) {
		if (i.target !== `${r.modelId}#${e.source}`) continue;
		let a = `${i.sourceModel}|${i.source}|${e.target}`;
		n.has(a) || (n.add(a), t.push({
			kind: "transitive",
			sourceModel: i.sourceModel,
			source: i.source,
			targetModel: e.targetModel,
			target: e.target,
			via: [i.target],
			rationale: `${i.sourceModel}#${i.source} ⇒ ${i.target} and ${r.modelId}#${e.source} ⇒ ${e.target} — transitive candidate through the shared component; confirm to assert`,
			asserted: !1
		}));
	}
	return t;
}
function td(e) {
	let t = /* @__PURE__ */ new Map();
	for (let n of e) for (let e of n.mappings) {
		let r = `${n.modelId}→${e.targetModel}`, i = t.get(r) ?? {
			from: n.modelId,
			to: e.targetModel,
			pairs: 0
		};
		i.pairs++, t.set(r, i);
	}
	return [...t.values()];
}
function nd(e) {
	if (e && typeof e == "object") {
		for (let t of Object.values(e)) nd(t);
		Object.freeze(e);
	}
	return e;
}
function rd(e, t, n = null) {
	let r = new Set(t.visibleElements ?? []), i = r.size > 0, a = i ? [...r] : (e.processes ?? []).map((e) => e.id), o = null;
	if (n) {
		let e = n.components.filter((e) => !i || r.has(e.id) || e.mappedBy.some((e) => r.has(e))), t = {
			full: 0,
			minimal: 0,
			partial: 0,
			none: 0
		};
		for (let n of e) t[n.coverage]++;
		o = {
			...n,
			components: e,
			unmappedImplementation: n.unmappedImplementation.filter((e) => !i || r.has(e)),
			proposals: n.proposals.filter((e) => !i || r.has(e.source)),
			summary: t
		};
	}
	return nd({
		id: t.id,
		against: t.against ?? "",
		elements: a,
		coverage: o
	});
}
function id(e) {
	let t = /* @__PURE__ */ new Set(), n = (e) => {
		for (let n of e ?? []) t.add(n.id);
	};
	n(e.processes), n(e.provisions), n(e.regs), n(e.approvals), n(e.requirements), n(e.conformanceTests), n(e.forms), n(e.symbols), n(e.tables), n(e.dataclasses), n(e.terms), n(e.notes), n(e.roles), n(e.subjects), n(e.instruments), n(e.behaviors);
	for (let n of e.subjects ?? []) {
		for (let e of Object.keys(n.is?.designParameters ?? {})) t.add(e);
		for (let e of Object.keys(n.has?.attributes ?? {})) t.add(e);
		for (let e of Object.keys(n.has?.characteristics ?? {})) t.add(e);
		for (let e of n.does?.behaviors ?? []) t.add(e);
		for (let e of n.is?.endpoints ?? []) t.add(e.id);
		for (let e of n.is?.promises ?? []) e.id && t.add(e.id);
	}
	return t;
}
//#endregion
//#region src/model-diff.ts
var ad = [
	"foundations",
	"primary",
	"secondary",
	"tertiary",
	"cross-cutting"
], od = {
	terms: "foundations",
	references: "foundations",
	roles: "foundations",
	quantityRegisters: "foundations",
	enums: "foundations",
	variables: "foundations",
	figures: "foundations",
	activityArchetypes: "foundations",
	schemeActivityKinds: "foundations",
	schemeTypes: "foundations",
	connectorProfiles: "foundations",
	subjects: "primary",
	identitySlots: "primary",
	aspects: "primary",
	promiseSets: "primary",
	applicationDeclarations: "secondary",
	calculationContexts: "secondary",
	evaluationDimensions: "secondary",
	evaluationProfiles: "secondary",
	certificateTemplates: "secondary",
	workflowConfigs: "tertiary",
	workflowStages: "tertiary",
	verificationPathways: "tertiary",
	labSelectionCriteria: "tertiary",
	sampleSelectionRules: "tertiary",
	specimenGovernanceRules: "tertiary",
	testReportSkeletons: "tertiary",
	testReportChecklists: "tertiary",
	instruments: "primary",
	attributeDefinitions: "primary",
	capabilities: "primary",
	behaviors: "primary",
	conditionSets: "primary",
	instances: "primary",
	duals: "primary",
	artifactDefinitions: "primary",
	artifactInstances: "primary",
	requirements: "secondary",
	requirementClasses: "secondary",
	conformanceTests: "secondary",
	conformanceClasses: "secondary",
	forms: "secondary",
	subforms: "secondary",
	symbols: "secondary",
	formulaNotes: "tertiary",
	calculations: "secondary",
	verdicts: "secondary",
	tables: "secondary",
	testPointSets: "secondary",
	commonTestConditions: "tertiary",
	referenceMaterials: "secondary",
	processes: "tertiary",
	processModels: "tertiary",
	documentModules: "tertiary",
	pages: "tertiary",
	dataclasses: "tertiary",
	regs: "tertiary",
	gateways: "tertiary",
	events: "tertiary",
	approvals: "tertiary",
	stateMachines: "tertiary",
	monitors: "tertiary",
	passports: "tertiary",
	viewProfiles: "tertiary",
	provisions: "tertiary",
	notes: "cross-cutting",
	informativeAnnexes: "cross-cutting",
	partAnnexes: "cross-cutting",
	demoWorlds: "tertiary",
	storylines: "tertiary",
	invariants: "cross-cutting",
	testSequences: "cross-cutting",
	formulasUsed: "cross-cutting",
	links: "cross-cutting",
	texts: "cross-cutting"
};
function Q(e) {
	let t = [], n = (e) => {
		if (e === void 0) return "null";
		if (typeof e != "object" || !e) return JSON.stringify(e) ?? "null";
		if (Array.isArray(e)) return "[" + e.map(n).join(",") + "]";
		if (t.includes(e)) return "\"[Circular]\"";
		t.push(e);
		let r = "{" + Object.keys(e).filter((e) => !e.startsWith("_")).sort().map((t) => JSON.stringify(t) + ":" + n(e[t])).join(",") + "}";
		return t.pop(), r;
	};
	return n(e);
}
var sd = /#([^#]*)$/;
function cd(e, t, n = "") {
	let r = e ?? "", i = n ?? "", a = sd.exec(r);
	a && (r = r.slice(0, a.index), i ||= a[1]);
	let o = r.lastIndexOf(":"), s = r, c = "";
	if (o >= 0) {
		let e = r.slice(o + 1);
		/^\d+$/.test(e) && (s = r.slice(0, o), c = e);
	}
	return {
		basis: s,
		edition: c,
		clause: t ?? "",
		fragment: i
	};
}
var ld = [
	"source",
	"sourceRef",
	"sourceRefs"
], ud = {
	requirements: {
		statement: [
			"name",
			"statement",
			"guidance"
		],
		anchor: ["bindsTo"],
		binding: ["subjects", "channel"],
		limit: ["limit", "acceptanceCriteria"],
		applicability: ["applicability"]
	},
	conformanceTests: {
		statement: [
			"name",
			"purpose",
			"method",
			"guidance"
		],
		anchor: ["targets", "bindsTo"],
		binding: ["testSubject", "conditionsToEnforce"],
		limit: [
			"acceptanceCriteria",
			"acceptanceCriteriaType",
			"acceptanceCriteriaDescription",
			"acceptancePassIf",
			"acceptance",
			"preconditions"
		],
		applicability: ["applicability"]
	},
	calculations: {
		statement: [
			"name",
			"label",
			"description"
		],
		binding: [
			"inputs",
			"output",
			"params"
		],
		limit: [
			"expression",
			"ruleType",
			"lookup",
			"profile"
		]
	}
}, dd = [
	"name",
	"label",
	"title",
	"description",
	"definition",
	"statement",
	"purpose",
	"text"
], fd = [
	"parent",
	"bindsTo",
	"targets",
	"conformanceProcessId",
	"conformanceProcessIds"
];
function pd(e) {
	let t = {}, n = (e, n) => {
		n && typeof n == "object" && (n.doc || n.clause) && (t[e] ??= []).push(cd(n.doc ?? "", n.clause ?? "", n.fragment));
	};
	n("source", e.source), n("sourceRef", e.sourceRef);
	for (let t of e.sourceRefs ?? []) n("sourceRefs", t);
	let r = e.reference;
	typeof r == "string" && r.startsWith("urn:") && n("reference", {
		doc: r,
		clause: ""
	});
	let i = (e) => {
		let t = /* @__PURE__ */ new Set();
		return e.filter((e) => {
			let n = md(e);
			return !t.has(n) && (t.add(n), !0);
		});
	};
	for (let [e, n] of Object.entries(t)) t[e] = i(n);
	return {
		edges: i(Object.values(t).flat()),
		channels: t
	};
}
function md(e) {
	return Q({
		basis: e.basis,
		clause: e.clause,
		fragment: e.fragment
	});
}
function hd(e, t) {
	let n = String(t.id ?? t.entityName ?? ""), r = od[e] ?? "cross-cutting", { edges: i, channels: a } = pd(t), o = new Set(ld);
	typeof t.reference == "string" && t.reference.startsWith("urn:") && o.add("reference");
	let s = {}, c = {}, l = ud[e], u = (e) => {
		let n = {};
		for (let r of e) t[r] !== void 0 && (n[r] = t[r], o.add(r), s[r] = t[r]);
		return n;
	};
	if (l) for (let [e, t] of Object.entries(l)) {
		let n = u(t ?? []);
		Object.keys(n).length > 0 && (c[e] = Q(n));
	}
	else if (e === "texts") {
		o.add("entries");
		let e = t.entries ?? [];
		for (let t of e) if (t && typeof t.spelling == "string") {
			let e = {
				value: t.value,
				via: t.via
			};
			c[`spelling:${t.spelling}`] = Q(e), s[`spelling:${t.spelling}`] = e;
		}
	} else {
		let e = u(dd);
		Object.keys(e).length > 0 && (c.statement = Q(e));
		let t = u(fd);
		Object.keys(t).length > 0 && (c.anchor = Q(t));
	}
	if (i.length > 0) {
		c.provenance = Q(i.map((e) => ({
			basis: e.basis,
			clause: e.clause,
			fragment: e.fragment
		})));
		for (let [e, t] of Object.entries(a)) s[e] = t.map((e) => ({
			basis: e.basis,
			clause: e.clause,
			fragment: e.fragment
		}));
	}
	let d = {};
	for (let [e, n] of Object.entries(t)) !o.has(e) && e !== "id" && (d[e] = n, s[e] = n);
	return c.structure = Q(d), {
		key: `${e}:${n}`,
		id: n,
		kind: e,
		tier: r,
		aspects: c,
		fields: s,
		provenance: i
	};
}
function gd(e, t) {
	let n = /* @__PURE__ */ new Map();
	for (let r of Object.keys(od)) {
		let i = e[r];
		if (Array.isArray(i)) {
			for (let e of i) if (e && typeof e == "object" && ("id" in e || "entityName" in e)) {
				let i = hd(r, e);
				n.has(i.key) && t?.push(i.key), n.set(i.key, i);
			}
		}
	}
	return n;
}
function _d(e, t) {
	return `${e}#${t}`;
}
function $(e) {
	return e?.version ?? "";
}
function vd(e) {
	let t = [...new Set(e)].sort();
	return t.filter((e) => !t.some((t) => t !== e && e.startsWith(t + ".")));
}
function yd(e, t, n) {
	let r = n.mappingsA ?? Xu(e), i = n.mappingsB ?? Xu(t), a = (e) => `${e.sourceModel}#${e.source}⇒${e.target}`, o = new Map(r.map((e) => [a(e), e])), s = new Map(i.map((e) => [a(e), e])), c = [], l = [], u = [];
	for (let [e, t] of s) o.has(e) || c.push(t);
	for (let [e, t] of o) {
		let n = s.get(e);
		if (!n) {
			l.push(t);
			continue;
		}
		let r = [];
		t.description !== n.description && r.push("description"), t.justification !== n.justification && r.push("justification"), r.length > 0 && u.push({
			source: t.source,
			sourceModel: t.sourceModel,
			target: t.target,
			aspects: r
		});
	}
	let d = /* @__PURE__ */ new Set([...r.map((e) => e.targetModel), ...i.map((e) => e.targetModel)]), f = [], p = [];
	for (let a of [...d].sort()) {
		let o = (e) => {
			let t = n.references?.[a];
			if (t) return t;
			let r = Zu(e, { idPrefix: `${a}#` });
			return r.length > 0 ? r : null;
		}, s = o(e), c = o(t);
		if (!s && !c) {
			p.push(a);
			continue;
		}
		let l = /* @__PURE__ */ new Map();
		if (s) {
			let t = $u(e, s, r, a);
			for (let e of t.components) l.set(e.id, { from: e.coverage });
		}
		if (c) {
			let e = $u(t, c, i, a);
			for (let t of e.components) {
				let e = l.get(t.id) ?? {};
				e.to = t.coverage, l.set(t.id, e);
			}
		}
		for (let [e, t] of [...l.entries()].sort()) {
			let n = t.from ?? "absent", r = t.to ?? "absent";
			n !== r && f.push({
				namespace: a,
				component: e,
				from: n,
				to: r
			});
		}
	}
	return {
		added: c,
		removed: l,
		changed: u,
		coverageDelta: f,
		namespacesSkipped: p
	};
}
function bd(e, t) {
	let n = [];
	for (let [t, r] of e) {
		let e = /* @__PURE__ */ new Set([...t.provenance.map((e) => e.basis), ...r.provenance.map((e) => e.basis)]);
		for (let i of [...e].sort()) {
			let e = (e) => vd(e.provenance.filter((e) => e.basis === i).map((e) => e.clause)).filter((e) => e.length > 0), a = e(t), o = e(r), s = a.filter((e) => !o.includes(e)), c = o.filter((e) => !a.includes(e));
			if (s.length === 0 && c.length === 0) continue;
			let l = {
				key: t.key,
				id: t.id,
				kind: t.kind,
				tier: t.tier
			};
			if (s.length === 1 && c.length > 1) for (let e of c) n.push({
				doc: i,
				from: s[0],
				to: e,
				kind: "renumbered",
				citedBy: l
			});
			else if (c.length === 1 && s.length > 1) for (let e of s) n.push({
				doc: i,
				from: e,
				to: c[0],
				kind: "renumbered",
				citedBy: l
			});
			else {
				let e = Math.min(s.length, c.length);
				for (let t = 0; t < e; t++) n.push({
					doc: i,
					from: s[t],
					to: c[t],
					kind: "renumbered",
					citedBy: l
				});
				for (let t of s.slice(e)) n.push({
					doc: i,
					from: t,
					to: "",
					kind: "decited",
					citedBy: l
				});
				for (let t of c.slice(e)) n.push({
					doc: i,
					from: "",
					to: t,
					kind: "recited",
					citedBy: l
				});
			}
		}
	}
	let r = (e) => {
		if (e.kind !== "renumbered" || !t.sentencesA || !t.sentencesB) return "unavailable";
		let n = t.sentencesA.get(_d(e.doc, e.from)), r = t.sentencesB.get(_d(e.doc, e.to));
		return n === void 0 || r === void 0 ? "unavailable" : n.replace(/\s+/g, " ").trim() === r.replace(/\s+/g, " ").trim() ? "same" : "differed";
	}, i = /* @__PURE__ */ new Map();
	for (let e of n) {
		let t = r(e), n = `${e.doc}|${e.from}|${e.to}|${e.kind}|${t}`, a = i.get(n);
		a || (a = {
			doc: e.doc,
			from: e.from,
			to: e.to,
			kind: e.kind,
			text: t,
			citedBy: []
		}, i.set(n, a)), a.citedBy.some((t) => t.key === e.citedBy.key) || a.citedBy.push(e.citedBy);
	}
	return [...i.values()].sort((e, t) => `${e.doc} ${e.from} ${e.to}`.localeCompare(`${t.doc} ${t.from} ${t.to}`));
}
function xd(e, t, n) {
	return e.kind !== "texts" || !n.startsWith("spelling:") ? n : n in e.aspects ? n in t.aspects ? `${n} (changed)` : `${n} (removed)` : `${n} (added)`;
}
var Sd = (e) => typeof e == "object" && !!e && !Array.isArray(e);
function Cd(e, t, n, r) {
	if (Sd(t) && Sd(n)) {
		let i = [.../* @__PURE__ */ new Set([...Object.keys(t), ...Object.keys(n)])].sort();
		for (let a of i) Cd(`${e}.${a}`, t[a], n[a], r);
		return;
	}
	Q(t) !== Q(n) && r.push(e);
}
function wd(e, t) {
	let n = [.../* @__PURE__ */ new Set([...Object.keys(e.fields), ...Object.keys(t.fields)])].sort(), r = [];
	for (let i of n) Cd(i, e.fields[i], t.fields[i], r);
	let i = [
		"source",
		"sourceRef",
		"sourceRefs",
		"reference"
	], a = /* @__PURE__ */ new Set();
	return r.filter((n) => {
		if (!i.includes(n)) return !0;
		let r = Q(e.fields[n]) + " → " + Q(t.fields[n]);
		return !a.has(r) && (a.add(r), !0);
	});
}
function Td(e, t, n = {}) {
	let r = [], i = [], a = gd(e, r), o = gd(t, i), s = [], c = [], l = [], u = [], d = [], f = 0, p = Object.fromEntries(ad.map((e) => [e, {
		added: 0,
		removed: 0,
		changed: 0,
		moved: 0,
		unchanged: 0
	}]));
	for (let [e, t] of o) a.has(e) || (s.push({
		key: e,
		id: t.id,
		kind: t.kind,
		tier: t.tier
	}), p[t.tier].added++);
	for (let [e, t] of a) {
		let n = o.get(e);
		if (!n) {
			c.push({
				key: e,
				id: t.id,
				kind: t.kind,
				tier: t.tier
			}), p[t.tier].removed++;
			continue;
		}
		d.push([t, n]);
		let r = [.../* @__PURE__ */ new Set([...Object.keys(t.aspects), ...Object.keys(n.aspects)])].filter((e) => (t.aspects[e] ?? "<absent>") !== (n.aspects[e] ?? "<absent>"));
		r.length === 0 ? (f++, p[t.tier].unchanged++) : r.every((e) => e === "anchor") ? (u.push({
			key: e,
			id: t.id,
			kind: t.kind,
			tier: t.tier,
			from: t.aspects.anchor ?? "",
			to: n.aspects.anchor ?? ""
		}), p[t.tier].moved++) : (l.push({
			key: e,
			id: t.id,
			kind: t.kind,
			tier: t.tier,
			aspects: r.map((e) => xd(t, n, e)).sort(),
			fields: wd(t, n)
		}), p[t.tier].changed++);
	}
	let m = yd(e, t, n), h = bd(d, n), g = s.length === 0 && c.length === 0 && l.length === 0 && u.length === 0 && m.added.length === 0 && m.removed.length === 0 && m.changed.length === 0 && m.coverageDelta.length === 0 && h.length === 0, _ = e.packageManifest, v = t.packageManifest, y = n.aLabel ?? (_?.id ? `${_.id}@${$(_) || "?"}` : "a"), b = n.bLabel ?? (v?.id ? `${v.id}@${$(v) || "?"}` : "b"), x = !!_?.id && _.id === v?.id && $(_) !== $(v), S = (e, t) => `${e}: duplicate element ${t} — the last declaration wins (a data error the duplicate-id linter owns); this side under-reports`, C = [...r.map((e) => S(y, e)), ...i.map((e) => S(b, e))];
	return {
		aLabel: y,
		bLabel: b,
		editionComparison: x,
		aVersion: $(_),
		bVersion: $(v),
		added: s.sort((e, t) => e.key.localeCompare(t.key)),
		removed: c.sort((e, t) => e.key.localeCompare(t.key)),
		changed: l.sort((e, t) => e.key.localeCompare(t.key)),
		moved: u.sort((e, t) => e.key.localeCompare(t.key)),
		unchanged: f,
		byTier: p,
		mappings: m,
		clauseDrift: h,
		warnings: C,
		empty: g
	};
}
function Ed(e) {
	return `[${e.tier}/${e.kind}] ${e.id}`;
}
function Dd(e, t) {
	try {
		let n = e ? JSON.parse(e) : {}, r = t ? JSON.parse(t) : {}, i = [.../* @__PURE__ */ new Set([...Object.keys(n), ...Object.keys(r)])].sort().filter((e) => Q(n[e]) !== Q(r[e])).map((e) => `${e}: ${Q(n[e])} → ${Q(r[e])}`);
		if (i.length > 0) return i;
	} catch {}
	return [`from ${e}`, `to   ${t}`];
}
function Od(e) {
	let t = [], n = e.editionComparison ? `edition comparison — ${e.aLabel} → ${e.bLabel}` : `model diff — ${e.aLabel} → ${e.bLabel}`;
	t.push(`primmel diff: ${n}`), t.push(""), t.push(`elements: +${e.added.length} -${e.removed.length} ~${e.changed.length} >${e.moved.length} (${e.unchanged} unchanged)`), t.push(""), t.push("by tier:    added  removed  changed  moved  unchanged");
	for (let n of ad) {
		let r = e.byTier[n];
		t.push(`  ${n.padEnd(13)} ${String(r.added).padStart(5)} ${String(r.removed).padStart(8)} ${String(r.changed).padStart(8)} ${String(r.moved).padStart(6)} ${String(r.unchanged).padStart(9)}`);
	}
	if (e.added.length > 0) {
		t.push("", "added:");
		for (let n of e.added) t.push(`  + ${Ed(n)}`);
	}
	if (e.removed.length > 0) {
		t.push("", "removed:");
		for (let n of e.removed) t.push(`  - ${Ed(n)}`);
	}
	if (e.changed.length > 0) {
		t.push("", "changed:");
		for (let n of e.changed) t.push(`  ~ ${Ed(n)} — ${n.aspects.join(", ")} (fields: ${n.fields.join(", ")})`);
	}
	if (e.moved.length > 0) {
		t.push("", "moved (re-anchored):");
		for (let n of e.moved) {
			t.push(`  > ${Ed(n)}`);
			for (let e of Dd(n.from, n.to)) t.push(`      ${e}`);
		}
	}
	if (e.warnings.length > 0) {
		t.push("", "warnings:");
		for (let n of e.warnings) t.push(`  ${n}`);
	}
	let r = e.mappings;
	t.push(""), t.push(`mappings: +${r.added.length} -${r.removed.length} ~${r.changed.length} pairs` + (r.coverageDelta.length > 0 ? `, ${r.coverageDelta.length} coverage deltas` : "") + (r.namespacesSkipped.length > 0 ? ` (coverage silent for ${r.namespacesSkipped.join(", ")} — no reference tree)` : ""));
	for (let e of r.added) t.push(`  + ${e.sourceModel}#${e.source} ⇒ ${e.target}`);
	for (let e of r.removed) t.push(`  - ${e.sourceModel}#${e.source} ⇒ ${e.target}`);
	for (let e of r.changed) t.push(`  ~ ${e.sourceModel}#${e.source} ⇒ ${e.target} — ${e.aspects.join(", ")}`);
	for (let e of r.coverageDelta) t.push(`  coverage ${e.namespace}#${e.component}: ${e.from} → ${e.to}`);
	if (t.push(""), e.clauseDrift.length === 0) t.push("clause drift: none");
	else {
		t.push("clause drift:"), t.push(`  ${"doc".padEnd(26)} ${"clause (old)".padEnd(13)} ${"clause (new)".padEnd(13)} ${"kind".padEnd(10)} ${"text".padEnd(11)} cited by`);
		for (let n of e.clauseDrift) {
			let e = n.citedBy.map((e) => e.id).join(", ");
			t.push(`  ${n.doc.padEnd(26)} ${(n.from || "—").padEnd(13)} ${(n.to || "—").padEnd(13)} ${n.kind.padEnd(10)} ${n.text.padEnd(11)} ${e}`);
		}
	}
	return t.join("\n");
}
//#endregion
//#region src/ser-des/index.ts
function kd(e, t = {}) {
	return p(u(e, nu, t), ru);
}
function Ad(e, t = {}) {
	let n = u(e, nu, t);
	return {
		standard: p(n, ru),
		issues: n.issues
	};
}
function jd(e, t = {}) {
	return kd(su(e), t);
}
function Md(e, t = {}) {
	return Ad(su(e), t);
}
function Nd(e) {
	return qe(e, iu);
}
function Pd(e) {
	return cu(e);
}
//#endregion
export { X as CompositionError, Ra as ENDPOINT_ACCESS_SCOPES, La as ENDPOINT_OPERATION_KINDS, fc as PASSPORT_ACCESS_CLASSES, dc as PASSPORT_CONTENT_CLASSES, pc as PASSPORT_UPI_LEVELS, Uu as PRIMITIVE_TYPES, od as TIER_BY_FIELD, ad as TIER_ORDER, rd as applyView, Zu as buildProcessTree, Q as canonical, _d as clauseTextKey, Xu as collectMappings, id as componentIds, $u as computeCoverage, Td as diffStandards, ed as discoverTransitive, Nd as dump, Fa as dumpPackage, Bu as dumpPrm, Ou as effectiveUses, gd as elementIndex, Od as formatDiffReport, yu as groupBySourceFile, qu as isWellFormedMapType, kd as load, jd as loadFile, Md as loadFileWithIssues, vu as loadPackage, Du as loadPackageWithIssues, bu as loadPackageWithProvenance, zu as loadPrm, Ad as loadWithIssues, Hu as mapProfilesToPrm, Yu as mappingsFromProfile, cd as normalizeSourceRef, _u as packageFiles, Ju as parseTargetRef, Ku as parseTypeExpression, Vu as prmToMapProfiles, Tu as readPackageManifest, td as repoMap, Pd as validate };
